import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Habit } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const DAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

function getWeekDates(): string[] {
  const today = new Date();
  const dow = today.getDay();
  const diff = dow === 0 ? -6 : 1 - dow;
  const monday = new Date(today);
  monday.setDate(today.getDate() + diff);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    return d.toDateString();
  });
}

interface HabitRowProps {
  habit: Habit;
  onToggleDay: (habitId: string, day: string) => void;
  onDelete: (id: string) => void;
  isLast: boolean;
}

export default function HabitRow({ habit, onToggleDay, onDelete, isLast }: HabitRowProps) {
  const { colors } = useTheme();
  const weekDates = getWeekDates();
  const today = new Date().toDateString();
  const completed = weekDates.filter(d => habit.completedDays.includes(d)).length;
  const progress = completed / 7;

  return (
    <View style={[styles.container, { borderBottomColor: colors.border }, isLast && { borderBottomWidth: 0 }]}>
      <View style={styles.header}>
        <View style={styles.titleRow}>
          <View style={[styles.dot, { backgroundColor: habit.color }]} />
          <Text style={[styles.title, { color: colors.foreground }]}>{habit.title}</Text>
        </View>
        <View style={styles.headerRight}>
          <Text style={[styles.progress, { color: colors.mutedForeground }]}>{completed}/7</Text>
          <TouchableOpacity
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onDelete(habit.id); }}
            activeOpacity={0.6}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Feather name="trash-2" size={14} color={colors.mutedForeground} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.grid}>
        {weekDates.map((date, idx) => {
          const done = habit.completedDays.includes(date);
          const isToday = date === today;
          return (
            <View key={date} style={styles.dayCol}>
              <Text style={[
                styles.dayLabel,
                { color: isToday ? colors.foreground : colors.mutedForeground },
                isToday && { fontFamily: "Inter_700Bold", fontWeight: "700" },
              ]}>
                {DAYS[idx]}
              </Text>
              <TouchableOpacity
                onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); onToggleDay(habit.id, date); }}
                style={[
                  styles.dayBox,
                  {
                    borderColor: done ? habit.color : isToday ? colors.foreground : colors.border,
                    backgroundColor: done ? habit.color : "transparent",
                  },
                ]}
                activeOpacity={0.7}
              >
                {done && <Feather name="check" size={11} color="#fff" />}
              </TouchableOpacity>
            </View>
          );
        })}
      </View>

      <View style={[styles.trackContainer, { backgroundColor: colors.border }]}>
        <View style={[styles.trackFill, { width: `${progress * 100}%` as any, backgroundColor: habit.color }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: 12,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  title: { fontSize: 15, fontFamily: "Inter_500Medium", fontWeight: "500" },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 12 },
  progress: { fontSize: 13, fontFamily: "Inter_400Regular" },
  grid: { flexDirection: "row", justifyContent: "space-between" },
  dayCol: { alignItems: "center", gap: 5 },
  dayLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  dayBox: {
    width: 36,
    height: 36,
    borderRadius: 6,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
  },
  trackContainer: { height: 3, borderRadius: 2, overflow: "hidden" },
  trackFill: { height: "100%", borderRadius: 2 },
});
