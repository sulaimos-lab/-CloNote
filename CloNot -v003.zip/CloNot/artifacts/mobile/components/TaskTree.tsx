import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";

import React, { useRef, useState } from "react";
import {
  Animated,
  Image,
  Modal,
  PanResponder,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from "react-native";
import { CategoryDef, PRIORITY_CONFIG, Priority, Task, useTasks } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const INDENT         = 22;
const MAX_INDENT     = 4;
const SWIPE_THRESHOLD = 64;

function countDesc(id: string, getChildren: (pid: string | undefined) => Task[]): number {
  const ch = getChildren(id);
  return ch.reduce((a, c) => a + 1 + countDesc(c.id, getChildren), 0);
}
function countDoneDesc(id: string, getChildren: (pid: string | undefined) => Task[]): number {
  const ch = getChildren(id);
  return ch.reduce((a, c) => a + (c.completed ? 1 : 0) + countDoneDesc(c.id, getChildren), 0);
}

/* ─── Image viewer modal ──────────────────────────────────────── */
function ImageViewer({ uri, visible, onClose }: { uri: string; visible: boolean; onClose: () => void }) {
  const { width, height } = useWindowDimensions();
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <TouchableOpacity style={[styles.imgModalBg, { width, height }]} activeOpacity={1} onPress={onClose}>
        <Image source={{ uri }} style={[styles.imgModalFull, { width, height: height * 0.75 }]} resizeMode="contain" />
        <TouchableOpacity style={styles.imgModalClose} onPress={onClose} activeOpacity={0.8}>
          <Feather name="x" size={20} color="#fff" />
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

/* ─── Inline quick-add ────────────────────────────────────────── */
interface InlineAddProps {
  parentId: string;
  parentCategory: string;
  indentPx: number;
  onDone: () => void;
}

function InlineAdd({ parentId, parentCategory, indentPx, onDone }: InlineAddProps) {
  const { colors } = useTheme();
  const { addTask } = useTasks();
  const [text, setText] = useState("");
  const inputRef = useRef<TextInput>(null);

  const commit = () => {
    const t = text.trim();
    if (!t) { onDone(); return; }
    addTask({ title: t, category: parentCategory, priority: "normal", completed: false, parentId });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setText("");
    setTimeout(() => inputRef.current?.focus(), 40);
  };

  return (
    <View style={[
      styles.inlineRow,
      { marginLeft: indentPx + INDENT, borderBottomColor: colors.border, backgroundColor: colors.surface + "80" },
    ]}>
      <View style={[styles.inlineBullet, { backgroundColor: colors.mutedForeground }]} />
      <View style={[styles.inlineCheck, { borderColor: colors.border }]} />
      <TextInput
        ref={inputRef}
        value={text}
        onChangeText={setText}
        placeholder="Новая подзадача..."
        placeholderTextColor={colors.mutedForeground}
        style={[styles.inlineInput, { color: colors.foreground }]}
        autoFocus
        returnKeyType="done"
        onSubmitEditing={() => { commit(); onDone(); }}
        blurOnSubmit={false}
        maxLength={200}
      />
      {text.trim().length > 0 && (
        <TouchableOpacity onPress={() => { commit(); onDone(); }} style={[styles.inlineSave, { backgroundColor: colors.foreground }]} activeOpacity={0.8}>
          <Feather name="check" size={13} color={colors.background} />
        </TouchableOpacity>
      )}
      <TouchableOpacity onPress={onDone} style={styles.inlineCancel} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <Feather name="x" size={15} color={colors.mutedForeground} />
      </TouchableOpacity>
    </View>
  );
}

/* ─── Task node ───────────────────────────────────────────────── */
interface TaskNodeProps {
  task: Task;
  level: number;
  isLast: boolean;
  categories: CategoryDef[];
}

function TaskNode({ task, level, isLast, categories }: TaskNodeProps) {
  const { colors } = useTheme();
  const { toggleTask, deleteTask, getChildren } = useTasks();
  const [expanded,    setExpanded]    = useState(level < 2);
  const [addingChild, setAddingChild] = useState(false);
  const [swiped,      setSwiped]      = useState(false);
  const [imgVisible,  setImgVisible]  = useState(false);

  const scaleAnim    = useRef(new Animated.Value(1)).current;
  const checkScale   = useRef(new Animated.Value(task.completed ? 1 : 0)).current;
  const checkOpacity = useRef(new Animated.Value(task.completed ? 1 : 0)).current;
  const translateX   = useRef(new Animated.Value(0)).current;
  const swipeTriggered = useRef(false);

  const children    = getChildren(task.id);
  const hasChildren = children.length > 0 || addingChild;
  const totalDesc   = countDesc(task.id, getChildren);
  const doneDesc    = countDoneDesc(task.id, getChildren);

  const catDef   = categories.find(c => c.id === task.category);
  const indentPx = Math.min(level, MAX_INDENT) * INDENT;
  const priority: Priority = task.priority ?? "normal";
  const priCfg   = PRIORITY_CONFIG[priority];

  const springBack = () =>
    Animated.spring(translateX, { toValue: 0, friction: 7, tension: 140, useNativeDriver: true }).start();

  const panResponder = useRef(PanResponder.create({
    onMoveShouldSetPanResponder: (_, g) =>
      Math.abs(g.dx) > 8 && Math.abs(g.dx) > Math.abs(g.dy) * 1.5,
    onPanResponderGrant: () => { swipeTriggered.current = false; },
    onPanResponderMove: (_, g) => {
      translateX.setValue(g.dx);
      if (!swipeTriggered.current && Math.abs(g.dx) >= SWIPE_THRESHOLD) {
        Haptics.selectionAsync();
        swipeTriggered.current = true;
      }
    },
    onPanResponderRelease: (_, g) => {
      if (g.dx > SWIPE_THRESHOLD) {
        Animated.sequence([
          Animated.timing(translateX, { toValue: 80, duration: 80, useNativeDriver: true }),
          Animated.timing(translateX, { toValue: 0, duration: 200, useNativeDriver: true }),
        ]).start();
        const completing = !task.completed;
        Haptics.impactAsync(completing ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light);
        Animated.parallel([
          Animated.spring(checkScale,   { toValue: completing ? 1 : 0, friction: 4, tension: 120, useNativeDriver: true }),
          Animated.timing(checkOpacity, { toValue: completing ? 1 : 0, duration: 150, useNativeDriver: true }),
        ]).start();
        toggleTask(task.id);
      } else if (g.dx < -SWIPE_THRESHOLD) {
        Animated.timing(translateX, { toValue: -400, duration: 220, useNativeDriver: true }).start(() => {
          deleteTask(task.id);
          setSwiped(true);
        });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      } else {
        springBack();
      }
    },
    onPanResponderTerminate: () => springBack(),
  })).current;

  const handleToggle = () => {
    const completing = !task.completed;
    Haptics.impactAsync(completing ? Haptics.ImpactFeedbackStyle.Medium : Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(scaleAnim, { toValue: completing ? 1.03 : 0.98, duration: 80, useNativeDriver: true }),
      Animated.spring(scaleAnim, { toValue: 1, friction: 4, tension: 120, useNativeDriver: true }),
    ]).start();
    Animated.parallel([
      Animated.spring(checkScale,   { toValue: completing ? 1 : 0, friction: 4, tension: 120, useNativeDriver: true }),
      Animated.timing(checkOpacity, { toValue: completing ? 1 : 0, duration: 150, useNativeDriver: true }),
    ]).start();
    toggleTask(task.id);
  };

  const formatDate = (d?: string) =>
    d ? new Date(d).toLocaleDateString("ru-RU", { day: "numeric", month: "short" }) : null;

  const isOverdue = task.dueDate && !task.completed && new Date(task.dueDate) < new Date();

  const leftBgOpacity  = translateX.interpolate({ inputRange: [0, SWIPE_THRESHOLD * 0.5], outputRange: [0, 1], extrapolate: "clamp" });
  const rightBgOpacity = translateX.interpolate({ inputRange: [-SWIPE_THRESHOLD * 0.5, 0], outputRange: [1, 0], extrapolate: "clamp" });

  if (swiped) return null;

  return (
    <View>
      {/* Swipe backgrounds */}
      <Animated.View style={[styles.swipeBgLeft, { marginLeft: indentPx, opacity: leftBgOpacity }]} pointerEvents="none">
        <Feather name="check-circle" size={18} color="#fff" />
        <Text style={styles.swipeBgText}>{task.completed ? "Не выполнено" : "Готово"}</Text>
      </Animated.View>
      <Animated.View style={[styles.swipeBgRight, { marginLeft: indentPx, opacity: rightBgOpacity }]} pointerEvents="none">
        <Text style={styles.swipeBgText}>В корзину</Text>
        <Feather name="trash-2" size={18} color="#fff" />
      </Animated.View>

      {/* Row */}
      <Animated.View
        style={[{ transform: [{ translateX }, { scale: scaleAnim }] }]}
        {...(Platform.OS !== "web" ? panResponder.panHandlers : {})}
      >
        <View style={[
          styles.row,
          { marginLeft: indentPx, borderBottomColor: colors.border, backgroundColor: colors.background },
          isLast && !hasChildren && !task.imageUri && { borderBottomWidth: 0 },
        ]}>
          {/* Chevron */}
          <TouchableOpacity
            onPress={children.length > 0 ? () => { Haptics.selectionAsync(); setExpanded(v => !v); } : () => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setExpanded(true); setAddingChild(true); }}
            style={styles.chevronBtn}
            activeOpacity={0.5}
            hitSlop={{ top: 10, bottom: 10, left: 8, right: 8 }}
          >
            {children.length > 0 ? (
              <Feather name={expanded ? "chevron-down" : "chevron-right"} size={15} color={colors.mutedForeground} />
            ) : (
              <View style={styles.chevronPlaceholder} />
            )}
          </TouchableOpacity>

          {/* Emoji */}
          <Text style={styles.catEmoji}>{level === 0 ? (catDef?.emoji ?? "📁") : "·"}</Text>

          {/* Checkbox */}
          <TouchableOpacity onPress={handleToggle} style={styles.checkBtn} activeOpacity={0.6} hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}>
            <View style={[
              styles.checkbox,
              task.completed
                ? { backgroundColor: colors.foreground, borderColor: colors.foreground }
                : { borderColor: priority === "high" ? priCfg.color : colors.mutedForeground },
            ]}>
              <Animated.View style={{ opacity: checkOpacity, transform: [{ scale: checkScale }] }}>
                <Feather name="check" size={10} color={colors.background} />
              </Animated.View>
            </View>
          </TouchableOpacity>

          {/* Text — tap to edit */}
          <TouchableOpacity
            style={styles.textBlock}
            activeOpacity={0.6}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              router.push({ pathname: "/edit-task", params: { id: task.id } });
            }}
            hitSlop={{ top: 4, bottom: 4, left: 0, right: 0 }}
          >
            <View style={styles.titleRow}>
              {priority !== "low" && !task.completed && (
                <View style={[styles.priorityDot, { backgroundColor: priCfg.color }]} />
              )}
              <Text
                style={[
                  styles.title,
                  { color: task.completed ? colors.mutedForeground : colors.foreground },
                  { fontSize: level === 0 ? 15 : 14 },
                  task.completed && styles.strikethrough,
                  level === 0 && styles.titleRoot,
                ]}
                numberOfLines={2}
              >
                {task.title}
              </Text>
              <Feather name="edit-2" size={11} color={colors.mutedForeground} style={{ opacity: 0.5 }} />
            </View>
            {(task.dueDate || totalDesc > 0) && (
              <View style={styles.metaRow}>
                {task.dueDate && (
                  <Text style={[styles.metaText, { color: isOverdue ? "#E03E3E" : colors.mutedForeground }]}>
                    {isOverdue ? "⚠ " : ""}{formatDate(task.dueDate)}
                  </Text>
                )}
                {totalDesc > 0 && (
                  <Text style={[styles.metaText, { color: colors.mutedForeground }]}>{doneDesc}/{totalDesc} подзадач</Text>
                )}
              </View>
            )}
          </TouchableOpacity>

          {/* Thumbnail */}
          {task.imageUri && (
            <TouchableOpacity onPress={() => setImgVisible(true)} activeOpacity={0.85} style={styles.thumbWrap}>
              <Image source={{ uri: task.imageUri }} style={styles.thumb} resizeMode="cover" />
              <View style={[styles.thumbOverlay, { backgroundColor: colors.foreground + "22" }]}>
                <Feather name="maximize-2" size={10} color="#fff" />
              </View>
            </TouchableOpacity>
          )}

          {/* Actions */}
          <View style={styles.actions}>
            <TouchableOpacity
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setExpanded(true); setAddingChild(true); }}
              style={styles.actionBtn} activeOpacity={0.5} hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}
            >
              <Feather name="plus" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); deleteTask(task.id); }}
              style={styles.actionBtn} activeOpacity={0.5} hitSlop={{ top: 8, bottom: 8, left: 4, right: 4 }}
            >
              <Feather name="trash-2" size={13} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Image strip (if attached) */}
        {task.imageUri && (
          <TouchableOpacity
            onPress={() => setImgVisible(true)}
            activeOpacity={0.9}
            style={[styles.imageStrip, { marginLeft: indentPx, borderBottomColor: colors.border, borderColor: colors.border }]}
          >
            <Image source={{ uri: task.imageUri }} style={styles.imageStripImg} resizeMode="cover" />
            <View style={[styles.imageStripOverlay, { backgroundColor: colors.background + "cc" }]}>
              <Feather name="maximize-2" size={14} color={colors.mutedForeground} />
              <Text style={[styles.imageStripText, { color: colors.mutedForeground }]}>Нажми для просмотра</Text>
            </View>
          </TouchableOpacity>
        )}
      </Animated.View>

      {/* Image viewer */}
      {task.imageUri && (
        <ImageViewer uri={task.imageUri} visible={imgVisible} onClose={() => setImgVisible(false)} />
      )}

      {/* Children + inline add */}
      {(children.length > 0 || addingChild) && expanded && (
        <View>
          {children.map((child, idx) => (
            <TaskNode
              key={child.id}
              task={child}
              level={level + 1}
              isLast={idx === children.length - 1 && !addingChild}
              categories={categories}
            />
          ))}
          {addingChild && (
            <InlineAdd
              parentId={task.id}
              parentCategory={task.category}
              indentPx={Math.min(level + 1, MAX_INDENT) * INDENT}
              onDone={() => setAddingChild(false)}
            />
          )}
        </View>
      )}
    </View>
  );
}

/* ─── Tree root ───────────────────────────────────────────────── */
interface TaskTreeProps {
  tasks: Task[];
  categories: CategoryDef[];
}

export default function TaskTree({ tasks, categories }: TaskTreeProps) {
  return (
    <View>
      {tasks.map((task, idx) => (
        <TaskNode key={task.id} task={task} level={0} isLast={idx === tasks.length - 1} categories={categories} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  swipeBgLeft: {
    position: "absolute", top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: "#2D9E6B", flexDirection: "row",
    alignItems: "center", paddingHorizontal: 16, gap: 8, zIndex: 0,
  },
  swipeBgRight: {
    position: "absolute", top: 0, bottom: 0, left: 0, right: 0,
    backgroundColor: "#E03E3E", flexDirection: "row",
    alignItems: "center", justifyContent: "flex-end",
    paddingHorizontal: 16, gap: 8, zIndex: 0,
  },
  swipeBgText: { color: "#fff", fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  row: {
    flexDirection: "row", alignItems: "center",
    paddingVertical: 9, paddingRight: 8,
    borderBottomWidth: StyleSheet.hairlineWidth, gap: 6, zIndex: 1,
  },
  chevronBtn: { width: 20, alignItems: "center", justifyContent: "center" },
  chevronPlaceholder: { width: 15 },
  catEmoji: { fontSize: 16, width: 22, textAlign: "center" },
  checkBtn: { padding: 2 },
  checkbox: { width: 18, height: 18, borderRadius: 4, borderWidth: 1.5, alignItems: "center", justifyContent: "center" },
  textBlock: { flex: 1, gap: 2 },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  priorityDot: { width: 6, height: 6, borderRadius: 3 },
  title: {
    fontFamily: Platform.OS === "ios" ? "System" : "Inter_400Regular",
    fontWeight: "400", lineHeight: 21, flex: 1,
  },
  titleRoot: {
    fontFamily: Platform.OS === "ios" ? "System" : "Inter_500Medium",
    fontWeight: "500",
  },
  strikethrough: { textDecorationLine: "line-through" },
  metaRow: { flexDirection: "row", gap: 10 },
  metaText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  /* Thumbnail in row */
  thumbWrap: { width: 38, height: 38, borderRadius: 6, overflow: "hidden" },
  thumb: { width: 38, height: 38 },
  thumbOverlay: {
    position: "absolute", top: 0, left: 0, right: 0, bottom: 0,
    alignItems: "center", justifyContent: "center",
  },
  /* Image strip below row */
  imageStrip: {
    height: 120, borderBottomWidth: StyleSheet.hairlineWidth,
    overflow: "hidden", position: "relative",
  },
  imageStripImg: { width: "100%", height: "100%" },
  imageStripOverlay: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    flexDirection: "row", alignItems: "center", gap: 6,
    padding: 8,
  },
  imageStripText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  actions: { flexDirection: "row", alignItems: "center" },
  actionBtn: { padding: 6 },
  /* Inline add */
  inlineRow: {
    flexDirection: "row", alignItems: "center",
    paddingVertical: 7, paddingRight: 8,
    borderBottomWidth: StyleSheet.hairlineWidth, gap: 6,
  },
  inlineBullet: { width: 4, height: 4, borderRadius: 2, marginHorizontal: 9 },
  inlineCheck: { width: 18, height: 18, borderRadius: 4, borderWidth: 1.5, marginRight: 2 },
  inlineInput: {
    flex: 1, fontSize: 14,
    fontFamily: Platform.OS === "ios" ? "System" : "Inter_400Regular",
    padding: 0,
  },
  inlineSave: { width: 26, height: 26, borderRadius: 5, alignItems: "center", justifyContent: "center" },
  inlineCancel: { padding: 4 },
  /* Image viewer modal */
  imgModalBg: { backgroundColor: "rgba(0,0,0,0.92)", alignItems: "center", justifyContent: "center" },
  imgModalFull: {},
  imgModalClose: {
    position: "absolute", top: 56, right: 20,
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center", justifyContent: "center",
  },
});
