import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import { Animated, Platform, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { Category, Task } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const CATEGORY_CONFIG: Record<Category, { icon: string; label: string; colorKey: string; lightKey: string }> = {
  work: { icon: "briefcase", label: "Работа", colorKey: "categoryWork", lightKey: "categoryWorkLight" },
  home: { icon: "home", label: "Дом", colorKey: "categoryHome", lightKey: "categoryHomeLight" },
  habits: { icon: "repeat", label: "Привычки", colorKey: "categoryHabits", lightKey: "categoryHabitsLight" },
  personal: { icon: "heart", label: "Личное", colorKey: "categoryPersonal", lightKey: "categoryPersonalLight" },
  shopping: { icon: "shopping-cart", label: "Покупки", colorKey: "categoryShopping", lightKey: "categoryShoppingLight" },
};

interface TaskCardProps {
  task: Task;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
}

export default function TaskCard({ task, onToggle, onDelete }: TaskCardProps) {
  const { colors } = useTheme();
  const cfg = CATEGORY_CONFIG[task.category];
  const catColor = colors[cfg.colorKey as keyof typeof colors] as string;
  const catLight = colors[cfg.lightKey as keyof typeof colors] as string;

  const scale = React.useRef(new Animated.Value(1)).current;

  const handleToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.sequence([
      Animated.timing(scale, { toValue: 0.96, duration: 80, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 80, useNativeDriver: true }),
    ]).start();
    onToggle(task.id);
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return null;
    const d = new Date(dateStr);
    return d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" });
  };

  return (
    <Animated.View style={[styles.container, { backgroundColor: colors.card, borderColor: colors.border, transform: [{ scale }] }]}>
      <TouchableOpacity style={styles.checkbox} onPress={handleToggle} activeOpacity={0.7}>
        <View style={[styles.checkCircle, task.completed && { backgroundColor: catColor, borderColor: catColor }, !task.completed && { borderColor: colors.border }]}>
          {task.completed && <Feather name="check" size={12} color="#fff" />}
        </View>
      </TouchableOpacity>
      <View style={styles.content}>
        <Text style={[styles.title, { color: colors.foreground }, task.completed && { color: colors.mutedForeground, textDecorationLine: "line-through" }]} numberOfLines={2}>
          {task.title}
        </Text>
        <View style={styles.meta}>
          <View style={[styles.categoryBadge, { backgroundColor: catLight }]}>
            <Feather name={cfg.icon as any} size={10} color={catColor} />
            <Text style={[styles.categoryLabel, { color: catColor }]}>{cfg.label}</Text>
          </View>
          {task.dueDate && (
            <Text style={[styles.date, { color: colors.mutedForeground }]}>
              {formatDate(task.dueDate)}
            </Text>
          )}
        </View>
      </View>
      <TouchableOpacity style={styles.deleteBtn} onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onDelete(task.id); }} activeOpacity={0.6}>
        <Feather name="trash-2" size={15} color={colors.mutedForeground} />
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 14,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 14,
    marginBottom: 10,
    gap: 12,
  },
  checkbox: {
    padding: 2,
  },
  checkCircle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    alignItems: "center",
    justifyContent: "center",
  },
  content: {
    flex: 1,
    gap: 6,
  },
  title: {
    fontSize: 15,
    fontFamily: Platform.OS === "ios" ? "System" : "Inter_500Medium",
    fontWeight: "500",
    lineHeight: 20,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  categoryBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
  },
  categoryLabel: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    fontWeight: "600",
  },
  date: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
  },
  deleteBtn: {
    padding: 4,
  },
});
