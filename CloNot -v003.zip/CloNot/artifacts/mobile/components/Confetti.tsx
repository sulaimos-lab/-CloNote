import React, { useEffect, useRef } from "react";
import { Animated, Dimensions, StyleSheet, View } from "react-native";

const { width: W, height: H } = Dimensions.get("window");

const COLORS = ["#E03E3E","#D9730D","#DFAB01","#0F7B6C","#2383E2","#9065B0","#6940A5","#37352F","#4F46E5","#10B981"];
const COUNT = 22;

interface Particle {
  x: Animated.Value;
  y: Animated.Value;
  opacity: Animated.Value;
  scale: Animated.Value;
  rotate: Animated.Value;
  color: string;
  size: number;
}

export default function Confetti({ visible }: { visible: boolean }) {
  const particles = useRef<Particle[]>(
    Array.from({ length: COUNT }, (_, i) => ({
      x: new Animated.Value(Math.random() * W),
      y: new Animated.Value(-20 - Math.random() * 80),
      opacity: new Animated.Value(0),
      scale: new Animated.Value(0),
      rotate: new Animated.Value(0),
      color: COLORS[i % COLORS.length],
      size: 7 + Math.random() * 7,
    }))
  ).current;

  useEffect(() => {
    if (!visible) return;
    const anims = particles.map((p, i) => {
      p.x.setValue(Math.random() * W);
      p.y.setValue(-20 - Math.random() * 60);
      p.opacity.setValue(0);
      p.scale.setValue(0);
      p.rotate.setValue(0);

      const delay = i * 55;
      return Animated.sequence([
        Animated.delay(delay),
        Animated.parallel([
          Animated.timing(p.opacity, { toValue: 1, duration: 120, useNativeDriver: true }),
          Animated.spring(p.scale,   { toValue: 1, friction: 4, tension: 80, useNativeDriver: true }),
          Animated.timing(p.y,       { toValue: H * 0.7 + Math.random() * 200, duration: 1800 + Math.random() * 600, useNativeDriver: true }),
          Animated.timing(p.rotate,  { toValue: 6 + Math.random() * 6, duration: 1800, useNativeDriver: true }),
          Animated.sequence([
            Animated.delay(1000 + Math.random() * 400),
            Animated.timing(p.opacity, { toValue: 0, duration: 600, useNativeDriver: true }),
          ]),
        ]),
      ]);
    });
    Animated.parallel(anims).start();
  }, [visible, particles]);

  if (!visible) return null;

  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {particles.map((p, i) => {
        const rotate = p.rotate.interpolate({ inputRange: [0, 12], outputRange: ["0deg", "720deg"] });
        return (
          <Animated.View
            key={i}
            style={[
              styles.particle,
              {
                width: p.size,
                height: p.size,
                backgroundColor: p.color,
                borderRadius: i % 3 === 0 ? p.size / 2 : 2,
                opacity: p.opacity,
                transform: [
                  { translateX: p.x },
                  { translateY: p.y },
                  { scale: p.scale },
                  { rotate },
                ],
              },
            ]}
          />
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  particle: { position: "absolute", top: 0, left: 0 },
});
