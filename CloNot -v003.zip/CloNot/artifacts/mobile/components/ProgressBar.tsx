import React, { useEffect, useRef, useState } from "react";
import { Animated, StyleSheet, Text, View } from "react-native";
import Svg, { Circle } from "react-native-svg";
import { useTheme } from "@/context/ThemeContext";

interface Props {
  completed: number;
  total: number;
}

const RING  = 52;
const STR   = 4;
const RAD   = (RING - STR) / 2;
const CIRCF = 2 * Math.PI * RAD;

export default function ProgressBar({ completed, total }: Props) {
  const { colors } = useTheme();

  const ratio   = total > 0 ? completed / total : 0;
  const pct     = Math.round(ratio * 100);
  const allDone = total > 0 && completed === total;
  const accent  = allDone ? "#2D9E6B" : colors.foreground;

  // Animate bar width (View-based, works everywhere)
  const barAnim = useRef(new Animated.Value(0)).current;
  // SVG ring: JS-driven value updated via state
  const [ringPct, setRingPct] = useState(0);

  useEffect(() => {
    // Animate bar
    Animated.timing(barAnim, { toValue: ratio, duration: 600, useNativeDriver: false }).start();
    // Drive SVG ring with JS intervals (works on web + native)
    let frame: ReturnType<typeof setInterval>;
    const start = Date.now();
    const duration = 700;
    const from = ringPct;
    frame = setInterval(() => {
      const t = Math.min((Date.now() - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setRingPct(from + (ratio - from) * eased);
      if (t >= 1) clearInterval(frame);
    }, 16);
    return () => clearInterval(frame);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ratio]);

  const barWidth = barAnim.interpolate({ inputRange: [0, 1], outputRange: ["0%", "100%"] });
  const dashOffset = CIRCF * (1 - ringPct);

  if (total === 0) return null;

  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {/* Ring */}
      <View style={styles.ringWrap}>
        <Svg width={RING} height={RING} style={{ transform: [{ rotate: "-90deg" }] }}>
          <Circle cx={RING / 2} cy={RING / 2} r={RAD} stroke={colors.border} strokeWidth={STR} fill="none" />
          <Circle
            cx={RING / 2} cy={RING / 2} r={RAD}
            stroke={accent} strokeWidth={STR} fill="none"
            strokeDasharray={CIRCF}
            strokeDashoffset={dashOffset}
            strokeLinecap="round"
          />
        </Svg>
        <View style={StyleSheet.absoluteFill as object} pointerEvents="none">
          <View style={styles.ringCenter}>
            <Text style={[styles.pctText, { color: accent }]}>{pct}%</Text>
          </View>
        </View>
      </View>

      {/* Right column */}
      <View style={styles.col}>
        <View style={styles.topRow}>
          <Text style={[styles.label, { color: colors.mutedForeground }]}>
            {allDone ? "🎉 Всё готово!" : "Выполнено сегодня"}
          </Text>
          <Text style={[styles.count, { color: colors.foreground }]}>
            {completed} / {total}
          </Text>
        </View>
        <View style={[styles.track, { backgroundColor: colors.border }]}>
          <Animated.View style={[styles.fill, { backgroundColor: accent, width: barWidth }]} />
        </View>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>
          {total - completed > 0
            ? `Осталось ${total - completed} ${pl(total - completed)}`
            : "Все задачи выполнены ✓"}
        </Text>
      </View>
    </View>
  );
}

function pl(n: number) {
  const m = n % 10, h = n % 100;
  if (m === 1 && h !== 11) return "задача";
  if (m >= 2 && m <= 4 && (h < 10 || h >= 20)) return "задачи";
  return "задач";
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row", alignItems: "center",
    borderRadius: 14, borderWidth: StyleSheet.hairlineWidth,
    padding: 14, gap: 14, marginBottom: 14,
  },
  ringWrap: { width: 52, height: 52, position: "relative" },
  ringCenter: { flex: 1, alignItems: "center", justifyContent: "center" },
  pctText: { fontSize: 13, fontFamily: "Inter_700Bold", fontWeight: "700" },
  col: { flex: 1, gap: 7 },
  topRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  label: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  count: { fontSize: 13, fontFamily: "Inter_700Bold", fontWeight: "700" },
  track: { height: 5, borderRadius: 3, overflow: "hidden" },
  fill: { height: "100%", borderRadius: 3 },
  sub: { fontSize: 11, fontFamily: "Inter_400Regular" },
});
