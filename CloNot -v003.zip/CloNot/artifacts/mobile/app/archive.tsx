import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import {
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { PRIORITY_CONFIG, useTasks } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

export default function ArchiveScreen() {
  const { colors } = useTheme();
  const { getArchivedTasks, restoreTask, purgeTask, purgeAll, categories } = useTasks();
  const insets = useSafeAreaInsets();
  const topInset    = Platform.OS === "web" ? 0 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const archived = getArchivedTasks();

  const handlePurgeAll = () => {
    Alert.alert(
      "Очистить корзину?",
      "Все задачи будут удалены навсегда. Это действие нельзя отменить.",
      [
        { text: "Отмена", style: "cancel" },
        { text: "Очистить", style: "destructive", onPress: () => {
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          purgeAll();
        }},
      ],
    );
  };

  const handlePurge = (id: string, title: string) => {
    Alert.alert(
      "Удалить навсегда?",
      `«${title}» будет удалена без возможности восстановления.`,
      [
        { text: "Отмена", style: "cancel" },
        { text: "Удалить", style: "destructive", onPress: () => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          purgeTask(id);
        }},
      ],
    );
  };

  const formatDate = (d?: string) =>
    d ? new Date(d).toLocaleDateString("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "";

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 16, borderBottomColor: colors.border, backgroundColor: colors.card }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="arrow-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Корзина</Text>
        {archived.length > 0 ? (
          <TouchableOpacity onPress={handlePurgeAll} style={styles.clearBtn} activeOpacity={0.7}>
            <Text style={[styles.clearText, { color: "#E03E3E" }]}>Очистить</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.clearBtn} />
        )}
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: bottomInset + 40 }]}
        showsVerticalScrollIndicator={false}
      >
        {archived.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>🗑️</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Корзина пуста</Text>
            <Text style={[styles.emptyDesc, { color: colors.mutedForeground }]}>
              Удалённые задачи появятся здесь.{"\n"}Их можно восстановить или удалить навсегда.
            </Text>
          </View>
        ) : (
          <>
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>
              {archived.length} {archived.length === 1 ? "задача" : archived.length < 5 ? "задачи" : "задач"} в корзине
            </Text>
            <View style={[styles.list, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
              {archived.map((task, idx) => {
                const catDef  = categories.find(c => c.id === task.category);
                const priCfg  = PRIORITY_CONFIG[task.priority ?? "normal"];
                const isLast  = idx === archived.length - 1;
                return (
                  <View
                    key={task.id}
                    style={[
                      styles.card,
                      { borderBottomColor: colors.border },
                      isLast && { borderBottomWidth: 0 },
                    ]}
                  >
                    {/* Task info */}
                    <View style={styles.cardLeft}>
                      <View style={styles.cardTop}>
                        <Text style={styles.cardEmoji}>{catDef?.emoji ?? "📁"}</Text>
                        <View style={[styles.priDot, { backgroundColor: priCfg.color }]} />
                        <Text style={[styles.cardTitle, { color: colors.mutedForeground }]} numberOfLines={2}>
                          {task.title}
                        </Text>
                      </View>
                      {task.archivedAt && (
                        <Text style={[styles.cardDate, { color: colors.mutedForeground }]}>
                          Удалено: {formatDate(task.archivedAt)}
                        </Text>
                      )}
                    </View>

                    {/* Actions */}
                    <View style={styles.cardActions}>
                      <TouchableOpacity
                        onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); restoreTask(task.id); }}
                        style={[styles.restoreBtn, { borderColor: colors.border, backgroundColor: colors.surface }]}
                        activeOpacity={0.7}
                      >
                        <Feather name="rotate-ccw" size={14} color={colors.foreground} />
                        <Text style={[styles.restoreText, { color: colors.foreground }]}>Вернуть</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handlePurge(task.id, task.title)}
                        style={styles.purgeBtn}
                        activeOpacity={0.7}
                        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                      >
                        <Feather name="trash-2" size={16} color="#E03E3E" />
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              })}
            </View>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 18, paddingBottom: 16, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { padding: 4, width: 40 },
  headerTitle: { fontSize: 17, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  clearBtn: { width: 70, alignItems: "flex-end" },
  clearText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  content: { paddingHorizontal: 20, paddingTop: 20, gap: 12 },
  hint: { fontSize: 12, fontFamily: "Inter_400Regular", marginBottom: 4 },
  list: { borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth },
  card: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    gap: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  cardLeft: { flex: 1, gap: 4 },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 7 },
  cardEmoji: { fontSize: 16 },
  priDot: { width: 6, height: 6, borderRadius: 3 },
  cardTitle: {
    flex: 1, fontSize: 14,
    fontFamily: "Inter_400Regular",
    textDecorationLine: "line-through",
  },
  cardDate: { fontSize: 11, fontFamily: "Inter_400Regular", paddingLeft: 4 },
  cardActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  restoreBtn: {
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 10, paddingVertical: 7,
    borderRadius: 7, borderWidth: 1,
  },
  restoreText: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  purgeBtn: { padding: 6 },
  empty: { paddingTop: 80, alignItems: "center", gap: 12 },
  emptyIcon: { fontSize: 48 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  emptyDesc: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
});
