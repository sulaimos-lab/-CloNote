import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import { ActivityIndicator, Alert, Modal, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { PaymentType, WagePayment, useWorkSchedule } from "@/context/WorkScheduleContext";
import { useTheme } from "@/context/ThemeContext";
import { dateKey, earnedForDay, formatMoney, hoursForDay, monthTitle, SHIFT_COLORS } from "@/utils/workSchedule";

const paymentColor: Record<PaymentType, string> = { advance: "#E07B39", salary: "#0F7B6C" };

export default function FinanceScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { templates, days, payments, isLoading, savePayment, deletePayment } = useWorkSchedule();
  const [month, setMonth] = useState(() => new Date());
  const [modalVisible, setModalVisible] = useState(false);
  const [type, setType] = useState<PaymentType>("advance");
  const [amountText, setAmountText] = useState("");
  const [paymentDate, setPaymentDate] = useState(dateKey(new Date()));
  const [note, setNote] = useState("");
  const [color, setColor] = useState(paymentColor.advance);
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;
  const prefix = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`;

  const monthEntries = useMemo(() => days.filter(day => day.date.startsWith(prefix) && day.templateId), [days, prefix]);
  const earned = monthEntries.reduce((sum, day) => sum + earnedForDay(day, templates.find(template => template.id === day.templateId)), 0);
  const hours = monthEntries.reduce((sum, day) => sum + hoursForDay(day, templates.find(item => item.id === day.templateId)), 0);
  const monthPayments = payments.filter(payment => payment.date.startsWith(prefix)).sort((a, b) => b.date.localeCompare(a.date));
  const advances = monthPayments.filter(payment => payment.type === "advance").reduce((sum, item) => sum + item.amount, 0);
  const salaries = monthPayments.filter(payment => payment.type === "salary").reduce((sum, item) => sum + item.amount, 0);
  const paid = advances + salaries;

  const changeMonth = (step: number) => setMonth(current => new Date(current.getFullYear(), current.getMonth() + step, 1));
  const openModal = () => {
    setType("advance");
    setAmountText("");
    setPaymentDate(month.getFullYear() === new Date().getFullYear() && month.getMonth() === new Date().getMonth() ? dateKey(new Date()) : `${prefix}-01`);
    setNote("");
    setColor(paymentColor.advance);
    setModalVisible(true);
  };

  const addPayment = () => {
    const amount = Number(amountText.replace(",", "."));
    if (!/^\d{4}-\d{2}-\d{2}$/.test(paymentDate) || dateKey(new Date(`${paymentDate}T12:00:00`)) !== paymentDate) {
      return Alert.alert("Проверьте дату", "Введите дату в формате ГГГГ-ММ-ДД.");
    }
    if (!Number.isFinite(amount) || amount <= 0) return Alert.alert("Проверьте сумму", "Укажите сумму больше нуля.");
    savePayment({ date: paymentDate, type, amount, note: note.trim() || undefined, color });
    setModalVisible(false);
  };

  const askDelete = (payment: WagePayment) => Alert.alert("Удалить выплату?", `${payment.type === "advance" ? "Аванс" : "Зарплата"} · ${formatMoney(payment.amount)}`, [
    { text: "Отмена", style: "cancel" },
    { text: "Удалить", style: "destructive", onPress: () => deletePayment(payment.id) },
  ]);

  if (isLoading) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: topInset + 16, paddingBottom: bottomInset + 32 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.back} accessibilityLabel="Назад"><Feather name="arrow-left" size={20} color={colors.foreground} /></TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>Финансы</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Начисления, авансы и зарплаты</Text>
          </View>
          <TouchableOpacity onPress={openModal} style={[styles.addButton, { backgroundColor: colors.primary }]} accessibilityLabel="Добавить выплату"><Feather name="plus" size={18} color="#fff" /></TouchableOpacity>
        </View>

        <View style={[styles.monthBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TouchableOpacity onPress={() => changeMonth(-1)} style={styles.arrow}><Feather name="chevron-left" size={22} color={colors.foreground} /></TouchableOpacity>
          <Text style={[styles.monthTitle, { color: colors.foreground }]}>{monthTitle(month)}</Text>
          <TouchableOpacity onPress={() => changeMonth(1)} style={styles.arrow}><Feather name="chevron-right" size={22} color={colors.foreground} /></TouchableOpacity>
        </View>

        <View style={[styles.earnedCard, { backgroundColor: colors.foreground }]}>
          <Text style={[styles.cardEyebrow, { color: colors.background, opacity: 0.7 }]}>НАЧИСЛЕНО ЗА МЕСЯЦ</Text>
          <Text style={[styles.earnedValue, { color: colors.background }]}>{isLoading ? "…" : formatMoney(earned)}</Text>
          <Text style={[styles.earnedHint, { color: colors.background, opacity: 0.72 }]}>По запланированным сменам</Text>
        </View>

        <View style={styles.metricRow}>
          <Metric label="Авансы" value={formatMoney(advances)} color="#E07B39" colors={colors} />
          <Metric label="Зарплаты" value={formatMoney(salaries)} color="#0F7B6C" colors={colors} />
        </View>
        <View style={[styles.balanceCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>ОСТАТОК К ВЫПЛАТЕ</Text>
            <Text style={[styles.balanceValue, { color: colors.foreground }]}>{formatMoney(earned - paid)}</Text>
          </View>
          <View style={styles.balanceRight}>
            <Text style={[styles.balanceLabel, { color: colors.mutedForeground }]}>ВЫПЛАЧЕНО</Text>
            <Text style={[styles.paidValue, { color: colors.foreground }]}>{formatMoney(paid)}</Text>
          </View>
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>История выплат</Text>
          <TouchableOpacity onPress={() => router.push("/statistics")}><Text style={[styles.link, { color: colors.primary }]}>Статистика</Text></TouchableOpacity>
        </View>
        {monthPayments.length === 0 ? (
          <View style={[styles.empty, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="credit-card" size={22} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>В этом месяце пока нет выплат</Text>
            <TouchableOpacity onPress={openModal}><Text style={[styles.link, { color: colors.primary }]}>Добавить аванс или зарплату</Text></TouchableOpacity>
          </View>
        ) : monthPayments.map(payment => (
          <View key={payment.id} style={[styles.paymentRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.paymentIcon, { backgroundColor: `${payment.color}20` }]}>
              <Feather name={payment.type === "advance" ? "corner-up-right" : "briefcase"} size={17} color={payment.color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={[styles.paymentTitle, { color: colors.foreground }]}>{payment.type === "advance" ? "Аванс" : "Зарплата"}</Text>
              <Text style={[styles.paymentMeta, { color: colors.mutedForeground }]}>{new Date(`${payment.date}T12:00:00`).toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}{payment.note ? ` · ${payment.note}` : ""}</Text>
            </View>
            <Text style={[styles.paymentAmount, { color: payment.color }]}>{formatMoney(payment.amount)}</Text>
            <TouchableOpacity onPress={() => askDelete(payment)} style={styles.deleteIcon} accessibilityLabel="Удалить выплату"><Feather name="x" size={16} color={colors.mutedForeground} /></TouchableOpacity>
          </View>
        ))}

        <View style={[styles.infoNote, { backgroundColor: colors.surface }]}>
          <Feather name="info" size={15} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>Остаток считается как заработок по сменам минус все внесённые авансы и выплаты.</Text>
        </View>
      </ScrollView>

      <Modal visible={modalVisible} animationType="slide" transparent presentationStyle="overFullScreen" onRequestClose={() => setModalVisible(false)}>
        <View style={styles.overlay}>
          <ScrollView contentContainerStyle={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border, paddingBottom: bottomInset + 24 }]} keyboardShouldPersistTaps="handled">
            <View style={[styles.handle, { backgroundColor: colors.border }]} />
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Новая выплата</Text>
            <View style={[styles.segment, { backgroundColor: colors.surface }]}>
              {(["advance", "salary"] as const).map(value => (
                <TouchableOpacity key={value} onPress={() => { setType(value); setColor(paymentColor[value]); }} style={[styles.segmentButton, type === value && { backgroundColor: colors.foreground }]}>
                  <Text style={[styles.segmentText, { color: type === value ? colors.background : colors.mutedForeground }]}>{value === "advance" ? "Аванс" : "Зарплата"}</Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput value={amountText} onChangeText={setAmountText} keyboardType="decimal-pad" placeholder="Сумма, ₽" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, backgroundColor: colors.surface, borderColor: colors.border }]} />
            <TextInput value={paymentDate} onChangeText={setPaymentDate} placeholder="ГГГГ-ММ-ДД" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, backgroundColor: colors.surface, borderColor: colors.border }]} />
            <TextInput value={note} onChangeText={setNote} placeholder="Заметка (необязательно)" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, backgroundColor: colors.surface, borderColor: colors.border }]} />
            <Text style={[styles.label, { color: colors.mutedForeground }]}>ЦВЕТ МЕТКИ</Text>
            <View style={styles.colorRow}>
              {SHIFT_COLORS.map(value => <TouchableOpacity key={value} onPress={() => setColor(value)} style={[styles.colorDot, { backgroundColor: value, borderColor: color === value ? colors.foreground : "transparent" }]} />)}
            </View>
            <View style={styles.footerButtons}>
              <TouchableOpacity onPress={() => setModalVisible(false)} style={[styles.cancelButton, { borderColor: colors.border }]}><Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Отмена</Text></TouchableOpacity>
              <TouchableOpacity onPress={addPayment} style={[styles.saveButton, { backgroundColor: colors.foreground }]}><Text style={[styles.saveText, { color: colors.background }]}>Сохранить</Text></TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

function Metric({ label, value, color, colors }: { label: string; value: string; color: string; colors: ReturnType<typeof useTheme>["colors"] }) {
  return (
    <View style={[styles.metric, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[styles.metricDot, { backgroundColor: color }]} />
      <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.metricValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, gap: 13 },
  header: { flexDirection: "row", alignItems: "center", gap: 11, marginBottom: 4 },
  back: { width: 28, height: 40, justifyContent: "center" },
  title: { fontSize: 24, fontFamily: "Inter_700Bold", fontWeight: "700" },
  subtitle: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 3 },
  addButton: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  monthBar: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 13, padding: 5 },
  arrow: { width: 38, height: 35, alignItems: "center", justifyContent: "center" },
  monthTitle: { flex: 1, textAlign: "center", fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  earnedCard: { borderRadius: 16, padding: 18 },
  cardEyebrow: { fontSize: 10, letterSpacing: 0.7, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  earnedValue: { fontSize: 30, fontFamily: "Inter_700Bold", fontWeight: "700", marginTop: 6 },
  earnedHint: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  metricRow: { flexDirection: "row", gap: 10 },
  metric: { flex: 1, borderWidth: 1, borderRadius: 13, padding: 13 },
  metricDot: { width: 7, height: 7, borderRadius: 4, marginBottom: 9 },
  metricLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  metricValue: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginTop: 4 },
  balanceCard: { borderWidth: 1, borderRadius: 13, padding: 14, flexDirection: "row", alignItems: "center", gap: 12 },
  balanceLabel: { fontSize: 9, letterSpacing: 0.5, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  balanceValue: { fontSize: 20, fontFamily: "Inter_700Bold", fontWeight: "700", marginTop: 4 },
  balanceRight: { alignItems: "flex-end" },
  paidValue: { fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginTop: 5 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 8 },
  sectionTitle: { fontSize: 17, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  link: { fontSize: 12, fontFamily: "Inter_500Medium", fontWeight: "500" },
  empty: { minHeight: 140, alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 14, borderStyle: "dashed", gap: 10 },
  emptyText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  paymentRow: { minHeight: 67, borderRadius: 12, borderWidth: 1, paddingHorizontal: 11, flexDirection: "row", alignItems: "center", gap: 10 },
  paymentIcon: { width: 36, height: 36, borderRadius: 11, alignItems: "center", justifyContent: "center" },
  paymentTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  paymentMeta: { fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 3 },
  paymentAmount: { fontSize: 12, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  deleteIcon: { padding: 5 },
  infoNote: { flexDirection: "row", gap: 8, padding: 11, borderRadius: 10, marginTop: 4 },
  infoText: { flex: 1, fontSize: 10, lineHeight: 15, fontFamily: "Inter_400Regular" },
  overlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.36)" },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, borderTopWidth: StyleSheet.hairlineWidth, padding: 22, gap: 13 },
  handle: { width: 38, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 3 },
  sheetTitle: { fontSize: 19, fontFamily: "Inter_700Bold", fontWeight: "700" },
  segment: { flexDirection: "row", padding: 3, borderRadius: 10 },
  segmentButton: { flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 8 },
  segmentText: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  input: { borderWidth: 1, borderRadius: 10, padding: 12, fontSize: 14, fontFamily: "Inter_400Regular" },
  label: { fontSize: 10, letterSpacing: 0.7, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  colorRow: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  colorDot: { width: 29, height: 29, borderRadius: 15, borderWidth: 3 },
  footerButtons: { flexDirection: "row", gap: 10, marginTop: 4 },
  cancelButton: { flex: 1, padding: 13, alignItems: "center", borderWidth: 1, borderRadius: 10 },
  cancelText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  saveButton: { flex: 1, padding: 13, alignItems: "center", borderRadius: 10 },
  saveText: { fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
