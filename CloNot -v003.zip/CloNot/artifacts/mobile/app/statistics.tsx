import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import { ActivityIndicator, PanResponder, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import Svg, { Circle, Line, Path, Text as SvgText } from "react-native-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useWorkSchedule } from "@/context/WorkScheduleContext";
import { useTheme } from "@/context/ThemeContext";
import { dateKey, earnedForDay, formatMoney, hoursForDay, monthTitle } from "@/utils/workSchedule";

export default function WorkStatisticsScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { templates, days, payments, isLoading } = useWorkSchedule();
  const [month, setMonth] = useState(() => new Date());
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;
  const prefix = `${month.getFullYear()}-${String(month.getMonth() + 1).padStart(2, "0")}`;
  const numberOfDays = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();

  const daily = useMemo(() => Array.from({ length: numberOfDays }, (_, index) => {
    const date = new Date(month.getFullYear(), month.getMonth(), index + 1);
    const key = dateKey(date);
    const entry = days.find(item => item.date === key);
    const template = templates.find(item => item.id === entry?.templateId);
    return { date, key, entry, template, amount: entry?.templateId ? earnedForDay(entry, template) : 0 };
  }), [days, month, numberOfDays, templates]);
  const total = daily.reduce((sum, item) => sum + item.amount, 0);
  const worked = daily.filter(item => item.entry?.templateId).length;
  const hours = daily.reduce((sum, item) => sum + (item.entry ? hoursForDay(item.entry, item.template) : 0), 0);
  const daysOff = daily.filter(item => !!item.entry?.isDayOff || ((item.date.getDay() === 0 || item.date.getDay() === 6) && !item.entry?.templateId)).length;
  const monthPayments = payments.filter(item => item.date.startsWith(prefix));
  const paid = monthPayments.reduce((sum, item) => sum + item.amount, 0);
  const graphValues = daily.map(item => item.amount);
  const max = Math.max(1, ...graphValues);
  const hasData = graphValues.some(value => value > 0);

  const changeMonth = (delta: number) => setMonth(current => new Date(current.getFullYear(), current.getMonth() + delta, 1));
  const changeMonthRef = useRef(changeMonth);
  changeMonthRef.current = changeMonth;
  const panResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => false,
    onMoveShouldSetPanResponder: (_event, gesture) => Math.abs(gesture.dx) > 32 && Math.abs(gesture.dx) > Math.abs(gesture.dy) * 1.3,
    onPanResponderRelease: (_event, gesture) => {
      if (Math.abs(gesture.dx) > 50) changeMonthRef.current(gesture.dx < 0 ? 1 : -1);
    },
  }), []);

  const chartWidth = 340;
  const chartHeight = 194;
  const left = 37;
  const right = chartWidth - 10;
  const top = 12;
  const bottom = chartHeight - 24;
  const plotWidth = right - left;
  const plotHeight = bottom - top;
  const path = graphValues.map((value, index) => {
    const x = left + (index / Math.max(1, graphValues.length - 1)) * plotWidth;
    const y = bottom - (value / max) * plotHeight;
    return `${index === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(" ");

  if (isLoading) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: topInset + 16, paddingBottom: bottomInset + 32 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.back} accessibilityLabel="Назад"><Feather name="arrow-left" size={20} color={colors.foreground} /></TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>Статистика</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Ваш рабочий месяц</Text>
          </View>
          <TouchableOpacity onPress={() => router.push("/finance")} style={[styles.financeButton, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="credit-card" size={16} color={colors.foreground} />
            <Text style={[styles.financeButtonText, { color: colors.foreground }]}>Финансы</Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.monthBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TouchableOpacity onPress={() => changeMonth(-1)} style={styles.arrow}><Feather name="chevron-left" size={22} color={colors.foreground} /></TouchableOpacity>
          <Text style={[styles.monthTitle, { color: colors.foreground }]}>{monthTitle(month)}</Text>
          <TouchableOpacity onPress={() => changeMonth(1)} style={styles.arrow}><Feather name="chevron-right" size={22} color={colors.foreground} /></TouchableOpacity>
        </View>

        <View style={[styles.hero, { backgroundColor: colors.foreground }]}>
          <Text style={[styles.heroLabel, { color: colors.background, opacity: 0.7 }]}>ОСТАТОК К ВЫПЛАТЕ</Text>
          <Text style={[styles.heroValue, { color: colors.background }]}>{formatMoney(total - paid)}</Text>
          <View style={[styles.heroFoot, { borderTopColor: colors.background + "30" }]}>
            <Text style={[styles.heroFootText, { color: colors.background, opacity: 0.75 }]}>Заработано {formatMoney(total)}</Text>
            <Text style={[styles.heroFootText, { color: colors.background, opacity: 0.75 }]}>Выплачено {formatMoney(paid)}</Text>
          </View>
        </View>

        <View style={styles.statsGrid}>
          <StatCard icon="clock" label="Отработано" value={`${hours.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} ч`} colors={colors} />
          <StatCard icon="briefcase" label="Рабочих дней" value={String(worked)} colors={colors} />
          <StatCard icon="sun" label="Выходных" value={String(daysOff)} colors={colors} />
        </View>

        <View style={[styles.chartCard, { backgroundColor: colors.card, borderColor: colors.border }]} {...panResponder.panHandlers}>
          <View style={styles.chartHeader}>
            <View>
              <Text style={[styles.chartTitle, { color: colors.foreground }]}>Заработок по дням</Text>
              <Text style={[styles.chartSubtitle, { color: colors.mutedForeground }]}>Начисления по сменам</Text>
            </View>
            <Feather name="trending-up" size={18} color={colors.primary} />
          </View>
          <View style={{ alignItems: "center", marginTop: 10 }}>
            <Svg width="100%" height={chartHeight} viewBox={`0 0 ${chartWidth} ${chartHeight}`}>
              {[0, 1, 2, 3].map(index => {
                const y = top + (plotHeight * index) / 3;
                const amount = max * (1 - index / 3);
                return (
                  <React.Fragment key={index}>
                    <Line x1={left} y1={y} x2={right} y2={y} stroke={colors.border} strokeWidth="1" />
                    <SvgText x={left - 5} y={y + 4} fill={colors.mutedForeground} fontSize="8" textAnchor="end">{Math.round(amount).toLocaleString("ru-RU")}</SvgText>
                  </React.Fragment>
                );
              })}
              <Line x1={left} y1={bottom} x2={right} y2={bottom} stroke={colors.border} strokeWidth="1" />
              {[1, Math.ceil(numberOfDays / 4), Math.ceil(numberOfDays / 2), Math.ceil((numberOfDays * 3) / 4), numberOfDays].map(day => {
                const x = left + ((day - 1) / Math.max(1, numberOfDays - 1)) * plotWidth;
                return <SvgText key={day} x={x} y={chartHeight - 5} fill={colors.mutedForeground} fontSize="8" textAnchor="middle">{day}</SvgText>;
              })}
              {hasData && <Path d={path} fill="none" stroke={colors.primary} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />}
              {hasData && graphValues.map((value, index) => value > 0 ? (
                <Circle key={index} cx={left + (index / Math.max(1, graphValues.length - 1)) * plotWidth} cy={bottom - (value / max) * plotHeight} r="3.2" fill={colors.primary} />
              ) : null)}
            </Svg>
          </View>
          {!hasData && <Text style={[styles.noData, { color: colors.mutedForeground }]}>График появится после добавления смен</Text>}
          <Text style={[styles.swipeHint, { color: colors.mutedForeground }]}>Листайте, чтобы сменить месяц</Text>
        </View>

        <View style={[styles.detailCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.detailTitle, { color: colors.foreground }]}>Состав месяца</Text>
          <DetailRow label="Начислено за смены" value={formatMoney(total)} colors={colors} />
          <DetailRow label="Авансы и зарплаты" value={formatMoney(paid)} colors={colors} />
          <DetailRow label="Рабочие дни" value={`${worked} дн.`} colors={colors} />
          <DetailRow label="Отработанные часы" value={`${hours.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} ч`} colors={colors} last />
        </View>
      </ScrollView>
    </View>
  );
}

function StatCard({ icon, label, value, colors }: { icon: React.ComponentProps<typeof Feather>["name"]; label: string; value: string; colors: ReturnType<typeof useTheme>["colors"] }) {
  return (
    <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Feather name={icon} size={15} color={colors.primary} />
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

function DetailRow({ label, value, colors, last = false }: { label: string; value: string; colors: ReturnType<typeof useTheme>["colors"]; last?: boolean }) {
  return (
    <View style={[styles.detailRow, !last && { borderBottomColor: colors.border, borderBottomWidth: StyleSheet.hairlineWidth }]}>
      <Text style={[styles.detailLabel, { color: colors.mutedForeground }]}>{label}</Text>
      <Text style={[styles.detailValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, gap: 13 },
  header: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 3 },
  back: { width: 28, height: 40, justifyContent: "center" },
  title: { fontSize: 24, fontFamily: "Inter_700Bold", fontWeight: "700" },
  subtitle: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 3 },
  financeButton: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderRadius: 9, paddingHorizontal: 10, paddingVertical: 9 },
  financeButtonText: { fontSize: 11, fontFamily: "Inter_500Medium", fontWeight: "500" },
  monthBar: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 13, padding: 5 },
  arrow: { width: 38, height: 35, alignItems: "center", justifyContent: "center" },
  monthTitle: { flex: 1, textAlign: "center", fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  hero: { borderRadius: 16, padding: 18 },
  heroLabel: { fontSize: 10, letterSpacing: 0.7, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  heroValue: { fontSize: 34, fontFamily: "Inter_700Bold", fontWeight: "700", marginVertical: 7 },
  heroFoot: { borderTopWidth: 1, paddingTop: 10, flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between", gap: 10 },
  heroFootText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  statsGrid: { flexDirection: "row", gap: 8 },
  statCard: { flex: 1, minHeight: 92, borderWidth: 1, borderRadius: 13, padding: 10, gap: 5 },
  statLabel: { fontSize: 10, fontFamily: "Inter_400Regular" },
  statValue: { fontSize: 17, fontFamily: "Inter_700Bold", fontWeight: "700" },
  chartCard: { borderWidth: 1, borderRadius: 15, padding: 14 },
  chartHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  chartTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  chartSubtitle: { fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 3 },
  noData: { fontSize: 11, textAlign: "center", marginTop: 2, fontFamily: "Inter_400Regular" },
  swipeHint: { fontSize: 9, textAlign: "center", marginTop: 7, fontFamily: "Inter_400Regular" },
  detailCard: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingTop: 14 },
  detailTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginBottom: 3 },
  detailRow: { minHeight: 43, flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 10 },
  detailLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  detailValue: { fontSize: 12, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
