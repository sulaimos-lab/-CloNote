import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as ImagePicker from "expo-image-picker";
import { router, useLocalSearchParams } from "expo-router";
import { scheduleTaskReminder } from "@/utils/notifications";
import React, { useState } from "react";
import {
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { PRIORITY_CONFIG, Priority, useTasks } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const PRIORITIES: Priority[] = ["high", "normal", "low"];

const DATE_OPTIONS = [
  { label: "Сегодня",     offset: 0 },
  { label: "Завтра",      offset: 1 },
  { label: "Через 3 дня", offset: 3 },
  { label: "Неделя",      offset: 7 },
];

function offsetDate(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString();
}

export default function AddTaskScreen() {
  const { colors } = useTheme();
  const { addTask, tasks, categories } = useTasks();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ parentId?: string; parentCategory?: string }>();

  const parentId   = params.parentId ?? undefined;
  const parentTask = parentId ? tasks.find(t => t.id === parentId) : undefined;

  const defaultCategoryId = params.parentCategory ?? (categories[0]?.id ?? "work");
  const [title,      setTitle]      = useState("");
  const [categoryId, setCategoryId] = useState<string>(defaultCategoryId);
  const [priority,   setPriority]   = useState<Priority>("normal");
  const [dueDateKey, setDueDateKey] = useState<number | null>(null);
  const [imageUri,   setImageUri]   = useState<string | undefined>(undefined);

  const topInset    = Platform.OS === "web" ? 0 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;
  const isSubtask   = !!parentId;

  const handlePickImage = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    if (Platform.OS === "web") {
      // Web: use file input approach via ImagePicker
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ["images"],
        allowsEditing: true,
        quality: 0.8,
      });
      if (!result.canceled && result.assets[0]) {
        setImageUri(result.assets[0].uri);
      }
      return;
    }

    Alert.alert("Прикрепить фото", "Выбери источник", [
      {
        text: "Галерея",
        onPress: async () => {
          const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
          if (status !== "granted") {
            Alert.alert("Нет доступа", "Разреши доступ к галерее в настройках телефона.");
            return;
          }
          const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ["images"],
            allowsEditing: true,
            aspect: [4, 3],
            quality: 0.8,
          });
          if (!result.canceled && result.assets[0]) {
            setImageUri(result.assets[0].uri);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          }
        },
      },
      {
        text: "Камера",
        onPress: async () => {
          const { status } = await ImagePicker.requestCameraPermissionsAsync();
          if (status !== "granted") {
            Alert.alert("Нет доступа", "Разреши доступ к камере в настройках телефона.");
            return;
          }
          const result = await ImagePicker.launchCameraAsync({
            allowsEditing: true,
            aspect: [4, 3],
            quality: 0.8,
          });
          if (!result.canceled && result.assets[0]) {
            setImageUri(result.assets[0].uri);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          }
        },
      },
      { text: "Отмена", style: "cancel" },
    ]);
  };

  const handleSave = () => {
    if (!title.trim()) { Alert.alert("Введите название задачи"); return; }
    const dueDate = dueDateKey !== null ? offsetDate(dueDateKey) : undefined;
    const newId = Date.now().toString(36) + Math.random().toString(36).slice(2);
    addTask({
      title: title.trim(),
      category: categoryId,
      priority,
      dueDate,
      completed: false,
      parentId,
      imageUri,
    });
    if (dueDate) {
      scheduleTaskReminder({ taskId: newId, title: title.trim(), dueDate }).catch(() => {});
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    router.back();
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: topInset + 16, borderBottomColor: colors.border, backgroundColor: colors.card }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="x" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            {isSubtask ? "Подзадача" : "Новая задача"}
          </Text>
          {parentTask && (
            <Text style={[styles.headerSub, { color: colors.mutedForeground }]} numberOfLines={1}>
              → {parentTask.title}
            </Text>
          )}
        </View>
        <TouchableOpacity onPress={handleSave} style={[styles.saveBtn, { backgroundColor: colors.primary }]} activeOpacity={0.85}>
          <Text style={styles.saveBtnText}>Сохранить</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: bottomInset + 40 }]} keyboardShouldPersistTaps="handled">
        {isSubtask && (
          <View style={[styles.breadcrumb, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="layers" size={13} color={colors.mutedForeground} />
            <Text style={[styles.breadcrumbText, { color: colors.mutedForeground }]}>
              {parentTask ? `Подзадача для «${parentTask.title}»` : "Подзадача"}
            </Text>
          </View>
        )}

        <Text style={[styles.label, { color: colors.mutedForeground }]}>НАЗВАНИЕ</Text>
        <TextInput
          value={title}
          onChangeText={setTitle}
          placeholder="Что нужно сделать?"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.titleInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]}
          multiline
          autoFocus
          maxLength={200}
        />

        {/* Image attachment */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>ФОТО (ОПЦИОНАЛЬНО)</Text>
        {imageUri ? (
          <View style={styles.imagePreviewWrap}>
            <Image source={{ uri: imageUri }} style={styles.imagePreview} resizeMode="cover" />
            <TouchableOpacity
              style={[styles.removeImageBtn, { backgroundColor: colors.foreground }]}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); setImageUri(undefined); }}
              activeOpacity={0.8}
            >
              <Feather name="x" size={14} color={colors.background} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.changeImageBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
              onPress={handlePickImage}
              activeOpacity={0.8}
            >
              <Feather name="refresh-cw" size={13} color={colors.foreground} />
              <Text style={[styles.changeImageText, { color: colors.foreground }]}>Заменить</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity
            style={[styles.imagePickBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={handlePickImage}
            activeOpacity={0.8}
          >
            <Feather name="image" size={20} color={colors.mutedForeground} />
            <Text style={[styles.imagePickText, { color: colors.mutedForeground }]}>Прикрепить фото</Text>
            <Text style={[styles.imagePickHint, { color: colors.mutedForeground }]}>Галерея или камера</Text>
          </TouchableOpacity>
        )}

        {/* Priority */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>ПРИОРИТЕТ</Text>
        <View style={styles.priorityRow}>
          {PRIORITIES.map(p => {
            const cfg = PRIORITY_CONFIG[p];
            const isActive = priority === p;
            return (
              <TouchableOpacity
                key={p}
                style={[
                  styles.priorityBtn,
                  { borderColor: isActive ? cfg.color : colors.border, backgroundColor: isActive ? cfg.color + "18" : colors.surface },
                ]}
                onPress={() => { Haptics.selectionAsync(); setPriority(p); }}
                activeOpacity={0.8}
              >
                <View style={[styles.priDot, { backgroundColor: cfg.color }]} />
                <Text style={[styles.priLabel, { color: isActive ? cfg.color : colors.mutedForeground, fontFamily: isActive ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                  {cfg.label}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Category */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>КАТЕГОРИЯ</Text>
        <View style={styles.catsGrid}>
          {categories.map(cat => {
            const isActive = categoryId === cat.id;
            return (
              <TouchableOpacity
                key={cat.id}
                style={[
                  styles.catBtn,
                  { backgroundColor: isActive ? colors.foreground : colors.surface, borderColor: isActive ? colors.foreground : colors.border },
                ]}
                onPress={() => { Haptics.selectionAsync(); setCategoryId(cat.id); }}
                activeOpacity={0.8}
              >
                <Text style={styles.catEmoji}>{cat.emoji}</Text>
                <Text style={[styles.catName, { color: isActive ? colors.background : colors.foreground }]}>{cat.name}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Due date */}
        <Text style={[styles.label, { color: colors.mutedForeground }]}>СРОК (ОПЦИОНАЛЬНО)</Text>
        <View style={styles.dateRow}>
          {DATE_OPTIONS.map(opt => (
            <TouchableOpacity
              key={opt.offset}
              style={[
                styles.dateBtn,
                { backgroundColor: dueDateKey === opt.offset ? colors.foreground : colors.surface, borderColor: dueDateKey === opt.offset ? colors.foreground : colors.border },
              ]}
              onPress={() => { Haptics.selectionAsync(); setDueDateKey(dueDateKey === opt.offset ? null : opt.offset); }}
              activeOpacity={0.8}
            >
              <Text style={[styles.dateBtnText, { color: dueDateKey === opt.offset ? colors.background : colors.foreground }]}>
                {opt.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 18, paddingBottom: 16, borderBottomWidth: 1, gap: 8,
  },
  backBtn: { padding: 4 },
  headerCenter: { flex: 1, alignItems: "center" },
  headerTitle: { fontSize: 17, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  headerSub: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
  saveBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 6 },
  saveBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  content: { paddingHorizontal: 20, paddingTop: 24, gap: 12 },
  breadcrumb: {
    flexDirection: "row", alignItems: "center", gap: 8,
    padding: 12, borderRadius: 8, borderWidth: 1, marginBottom: 4,
  },
  breadcrumbText: { fontSize: 13, fontFamily: "Inter_400Regular", flex: 1 },
  label: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.8, marginBottom: 2 },
  titleInput: {
    borderWidth: 1, borderRadius: 8, padding: 14, fontSize: 16,
    fontFamily: "Inter_400Regular", minHeight: 80, textAlignVertical: "top", marginBottom: 8,
  },
  /* Image picker */
  imagePickBtn: {
    borderWidth: 1, borderRadius: 10, borderStyle: "dashed",
    padding: 20, alignItems: "center", gap: 6, marginBottom: 8,
  },
  imagePickText: { fontSize: 15, fontFamily: "Inter_500Medium", fontWeight: "500" },
  imagePickHint: { fontSize: 12, fontFamily: "Inter_400Regular" },
  imagePreviewWrap: { borderRadius: 10, overflow: "hidden", marginBottom: 8, position: "relative" },
  imagePreview: { width: "100%", height: 180, borderRadius: 10 },
  removeImageBtn: {
    position: "absolute", top: 8, right: 8,
    width: 28, height: 28, borderRadius: 14,
    alignItems: "center", justifyContent: "center",
  },
  changeImageBtn: {
    position: "absolute", bottom: 8, right: 8,
    flexDirection: "row", alignItems: "center", gap: 5,
    paddingHorizontal: 10, paddingVertical: 6,
    borderRadius: 8, borderWidth: 1,
  },
  changeImageText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  /* Priority */
  priorityRow: { flexDirection: "row", gap: 8, marginBottom: 8 },
  priorityBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 10, borderRadius: 8, borderWidth: 1.5 },
  priDot: { width: 8, height: 8, borderRadius: 4 },
  priLabel: { fontSize: 13 },
  /* Categories */
  catsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 8 },
  catBtn: { flexDirection: "row", alignItems: "center", gap: 7, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 8, borderWidth: 1 },
  catEmoji: { fontSize: 16 },
  catName: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  /* Date */
  dateRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  dateBtn: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 6, borderWidth: 1 },
  dateBtnText: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
});
