import { Feather } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, Alert, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import { DaySchedule, ShiftTemplate, useWorkSchedule } from "@/context/WorkScheduleContext";
import { useTheme } from "@/context/ThemeContext";
import { dateKey, earnedForDay, formatMoney, SHIFT_COLORS, shiftHours } from "@/utils/workSchedule";

export default function ShiftEditorScreen() {
  const { date: dateParam } = useLocalSearchParams<{ date: string }>();
  const date = Array.isArray(dateParam) ? dateParam[0] : dateParam;
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { templates, days, isLoading, saveDay, deleteDay } = useWorkSchedule();
  const existing = days.find(item => item.date === date);
  const [templateId, setTemplateId] = useState<string>();
  const [rateText, setRateText] = useState("");
  const [note, setNote] = useState("");
  const [color, setColor] = useState(SHIFT_COLORS[0]);
  const [noteColor, setNoteColor] = useState(SHIFT_COLORS[4]);
  const [offColor, setOffColor] = useState(SHIFT_COLORS[5]);
  const [isDayOff, setIsDayOff] = useState(false);
  const [initialized, setInitialized] = useState(false);
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  useEffect(() => {
    if (isLoading || initialized || !date) return;
    setTemplateId(existing?.templateId);
    setRateText(existing?.rateOverride != null ? String(existing.rateOverride) : "");
    setNote(existing?.note ?? "");
    setColor(existing?.colorOverride ?? templates.find(item => item.id === existing?.templateId)?.color ?? SHIFT_COLORS[0]);
    setNoteColor(existing?.noteColor ?? SHIFT_COLORS[4]);
    setOffColor(existing?.offColor ?? SHIFT_COLORS[5]);
    setIsDayOff(!!existing?.isDayOff);
    setInitialized(true);
  }, [date, existing, initialized, isLoading, templates]);

  const template = useMemo(() => templates.find(item => item.id === templateId), [templateId, templates]);
  const selectedDate = date ? new Date(`${date}T12:00:00`) : new Date();
  const rate = rateText.trim() ? Number(rateText.replace(",", ".")) : undefined;
  const previewDay: DaySchedule = {
    date: date ?? dateKey(new Date()), templateId, rateOverride: rate, colorOverride: color,
    note: note.trim(), noteColor, offColor, isDayOff,
  };
  const amount = earnedForDay(previewDay, template);

  const save = () => {
    if (!date) return;
    if (templateId && !template) return Alert.alert("Шаблон не найден", "Выберите другой шаблон смены.");
    if (rate != null && (!Number.isFinite(rate) || rate < 0)) return Alert.alert("Проверьте ставку", "Сумма должна быть нулём или больше.");
    if (!templateId && !isDayOff && !note.trim()) {
      deleteDay(date);
      router.back();
      return;
    }
    saveDay({
      date,
      templateId,
      rateOverride: templateId ? rate : undefined,
      colorOverride: templateId ? color : undefined,
      note: note.trim() || undefined,
      noteColor: note.trim() ? noteColor : undefined,
      isDayOff,
      offColor: isDayOff ? offColor : undefined,
    });
    router.back();
  };

  const deleteShift = () => {
    if (!date) return;
    if (note.trim() || isDayOff) {
      saveDay({ date, note: note.trim() || undefined, noteColor: note.trim() ? noteColor : undefined, isDayOff, offColor: isDayOff ? offColor : undefined });
    } else {
      deleteDay(date);
    }
    router.back();
  };

  const heading = selectedDate.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" });

  if (isLoading) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scrollView}
        contentContainerStyle={[styles.content, { paddingTop: topInset + 16, paddingBottom: bottomInset + 48 }]}
        bottomOffset={24}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.back} accessibilityLabel="Назад">
            <Feather name="arrow-left" size={20} color={colors.foreground} />
          </TouchableOpacity>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>{existing ? "Изменить день" : "План на день"}</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{heading}</Text>
          </View>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>СМЕНА</Text>
        {templates.length === 0 ? (
          <TouchableOpacity onPress={() => router.push("/templates")} style={[styles.emptyAction, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="plus-circle" size={19} color={colors.primary} />
            <Text style={[styles.actionText, { color: colors.foreground }]}>Сначала создайте шаблон смены</Text>
          </TouchableOpacity>
        ) : (
          <View style={{ gap: 9 }}>
            {templates.map(item => (
              <TouchableOpacity key={item.id} onPress={() => { setTemplateId(templateId === item.id ? undefined : item.id); setColor(item.color); setIsDayOff(false); }} style={[styles.templateOption, { backgroundColor: colors.card, borderColor: templateId === item.id ? item.color : colors.border }]}>
                <View style={[styles.templateSwatch, { backgroundColor: item.color }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.templateName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.templateMeta, { color: colors.mutedForeground }]}>{item.startTime}—{item.endTime} · {item.payType === "hourly" ? `${formatMoney(item.rate)}/ч` : `${formatMoney(item.rate)} за смену`}</Text>
                </View>
                {templateId === item.id && <Feather name="check-circle" size={20} color={item.color} />}
              </TouchableOpacity>
            ))}
          </View>
        )}

        {template && (
          <View style={[styles.overrideCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
              {template.payType === "hourly" ? "СТАВКА НА ЭТОТ ДЕНЬ, ₽/Ч (НЕОБЯЗАТЕЛЬНО)" : "ОПЛАТА ЗА ЭТУ СМЕНУ, ₽ (НЕОБЯЗАТЕЛЬНО)"}
            </Text>
            <TextInput value={rateText} onChangeText={setRateText} keyboardType="decimal-pad" placeholder={String(template.rate)} placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.card }]} />
            <Text style={[styles.preview, { color: colors.foreground }]}>
              {template.payType === "hourly" ? `${shiftHours(template).toLocaleString("ru-RU")} ч · ` : ""}
              {formatMoney(amount)}
            </Text>
          </View>
        )}

        {template && (
          <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ЦВЕТ СМЕНЫ</Text>
            <ColorPicker colorsList={SHIFT_COLORS} selected={color} onSelect={setColor} />
          </View>
        )}

        <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.rowBetween}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Выходной</Text>
              <Text style={[styles.templateMeta, { color: colors.mutedForeground }]}>Можно отметить любой день</Text>
            </View>
            <TouchableOpacity onPress={() => { setIsDayOff(!isDayOff); if (!isDayOff) setTemplateId(undefined); }} style={[styles.toggle, { backgroundColor: isDayOff ? colors.primary : colors.border }]}>
              <View style={[styles.toggleKnob, { alignSelf: isDayOff ? "flex-end" : "flex-start", backgroundColor: "#fff" }]} />
            </TouchableOpacity>
          </View>
          {isDayOff && <ColorPicker colorsList={SHIFT_COLORS} selected={offColor} onSelect={setOffColor} />}
        </View>

        <View style={[styles.sectionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Заметка на день</Text>
          <TextInput value={note} onChangeText={setNote} multiline placeholder="Например: взять аванс или купить продукты" placeholderTextColor={colors.mutedForeground} style={[styles.noteInput, { color: colors.foreground, backgroundColor: colors.surface, borderColor: colors.border }]} />
          {note.trim().length > 0 && <ColorPicker colorsList={SHIFT_COLORS} selected={noteColor} onSelect={setNoteColor} />}
        </View>

        <View style={styles.footer}>
          {existing && (
            <TouchableOpacity onPress={deleteShift} style={[styles.deleteButton, { borderColor: colors.destructive }]}>
              <Text style={[styles.deleteText, { color: colors.destructive }]}>Удалить</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={save} style={[styles.saveButton, { backgroundColor: colors.foreground }]}>
            <Text style={[styles.saveText, { color: colors.background }]}>Сохранить</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function ColorPicker({ colorsList, selected, onSelect }: { colorsList: string[]; selected: string; onSelect: (color: string) => void }) {
  const { colors } = useTheme();
  return (
    <View style={styles.colorRow}>
      {colorsList.map(value => (
        <TouchableOpacity key={value} onPress={() => onSelect(value)} style={[styles.colorDot, { backgroundColor: value, borderColor: selected === value ? colors.foreground : "transparent" }]} accessibilityLabel={`Выбрать цвет ${value}`} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scrollView: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, gap: 14 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 8 },
  back: { width: 34, height: 40, justifyContent: "center" },
  title: { fontSize: 23, fontFamily: "Inter_700Bold", fontWeight: "700" },
  subtitle: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 3, textTransform: "capitalize" },
  sectionLabel: { fontSize: 10, letterSpacing: 0.75, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginBottom: 3 },
  templateOption: { flexDirection: "row", alignItems: "center", gap: 11, padding: 13, borderWidth: 1.5, borderRadius: 12 },
  templateSwatch: { width: 10, height: 38, borderRadius: 5 },
  templateName: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  templateMeta: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 3 },
  emptyAction: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 12, padding: 14 },
  actionText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  overrideCard: { padding: 14, borderWidth: 1, borderRadius: 12, gap: 8 },
  input: { borderWidth: 1, borderRadius: 9, padding: 12, fontSize: 15, fontFamily: "Inter_400Regular" },
  preview: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  sectionCard: { borderWidth: 1, borderRadius: 12, padding: 14, gap: 12 },
  sectionTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  rowBetween: { flexDirection: "row", alignItems: "center", gap: 14 },
  toggle: { width: 48, height: 28, borderRadius: 14, padding: 3, justifyContent: "center" },
  toggleKnob: { width: 22, height: 22, borderRadius: 11 },
  colorRow: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  colorDot: { width: 28, height: 28, borderRadius: 14, borderWidth: 3 },
  noteInput: { minHeight: 84, borderWidth: 1, borderRadius: 10, padding: 12, fontSize: 14, fontFamily: "Inter_400Regular", textAlignVertical: "top" },
  footer: { flexDirection: "row", gap: 10, marginTop: 2 },
  saveButton: { flex: 1, padding: 15, borderRadius: 12, alignItems: "center" },
  saveText: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  deleteButton: { paddingHorizontal: 20, borderWidth: 1, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  deleteText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
});
