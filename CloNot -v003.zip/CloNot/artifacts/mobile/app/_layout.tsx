import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from "@expo-google-fonts/inter";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { KeyboardProvider } from "react-native-keyboard-controller";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { TaskProvider } from "@/context/TaskContext";
import { WorkScheduleProvider } from "@/context/WorkScheduleContext";
import { ThemeProvider, useTheme } from "@/context/ThemeContext";
import { ONBOARDING_KEY } from "@/app/onboarding";

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

function AuthGate({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const { colors } = useTheme();
  const router   = useRouter();
  const segments = useSegments();

  // null = ещё не проверили, true/false = результат
  const [onboardingDone, setOnboardingDone] = useState<boolean | null>(null);

  useEffect(() => {
    if (isLoading) return;

    let cancelled = false;

    const syncOnboardingAndRoute = async () => {
      try {
        // Always re-read after navigation: the onboarding screen can update
        // AsyncStorage while this gate is still mounted.
        const completed = (await AsyncStorage.getItem(ONBOARDING_KEY)) === "1";
        if (cancelled) return;

        setOnboardingDone(completed);

        const inOnboarding = segments[0] === "onboarding";
        const inLogin = segments[0] === "login";

        if (!completed && !inOnboarding) {
          router.replace("/onboarding");
          return;
        }

        if (completed) {
          if (!user && !inLogin) {
            router.replace("/login");
          } else if (user && inLogin) {
            router.replace("/(tabs)");
          }
        }
      } catch (error) {
        console.error("Unable to read onboarding status:", error);
        if (cancelled) return;

        setOnboardingDone(false);
        if (segments[0] !== "onboarding") {
          router.replace("/onboarding");
        }
      }
    };

    void syncOnboardingAndRoute();

    return () => {
      cancelled = true;
    };
  }, [user, isLoading, segments, router]);

  if (isLoading || onboardingDone === null) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background }}>
        <ActivityIndicator color={colors.foreground} />
      </View>
    );
  }

  return <>{children}</>;
}

function RootLayoutNav() {
  return (
    <AuthGate>
      <Stack screenOptions={{ headerBackTitle: "Назад" }}>
        <Stack.Screen name="onboarding" options={{ headerShown: false }} />
        <Stack.Screen name="login"     options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)"    options={{ headerShown: false }} />
        <Stack.Screen name="add-task"   options={{ headerShown: false, presentation: "modal" }} />
        <Stack.Screen name="edit-task"  options={{ headerShown: false, presentation: "modal" }} />
        <Stack.Screen name="archive"    options={{ headerShown: false }} />
        <Stack.Screen name="categories"   options={{ headerShown: false }} />
        <Stack.Screen name="mcp-connect"  options={{ headerShown: false }} />
        <Stack.Screen name="graph"        options={{ headerShown: false }} />
        <Stack.Screen name="privacy"      options={{ headerShown: false }} />
        <Stack.Screen name="templates"    options={{ headerShown: false, presentation: "modal" }} />
        <Stack.Screen name="shift-editor" options={{ headerShown: false, presentation: "modal" }} />
        <Stack.Screen name="finance"      options={{ headerShown: false, presentation: "modal" }} />
        <Stack.Screen name="statistics"   options={{ headerShown: false, presentation: "modal" }} />
      </Stack>
    </AuthGate>
  );
}

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) SplashScreen.hideAsync();
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) return null;

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <ThemeProvider>
            <AuthProvider>
              <TaskProvider>
                <WorkScheduleProvider>
                  <GestureHandlerRootView>
                    <KeyboardProvider>
                      <RootLayoutNav />
                    </KeyboardProvider>
                  </GestureHandlerRootView>
                </WorkScheduleProvider>
              </TaskProvider>
            </AuthProvider>
          </ThemeProvider>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
