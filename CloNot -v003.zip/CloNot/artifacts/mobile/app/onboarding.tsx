/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * onboarding.tsx
 * Экран приветствия — показывается только при первом запуске.
 * Пять слайдов с описанием ключевых возможностей приложения.
 * После просмотра флаг сохраняется в AsyncStorage — больше не показывается.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Animated,
  Dimensions,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";

export const ONBOARDING_KEY = "clonote_onboarding_done_v1";

const { width: SW } = Dimensions.get("window");

type Slide = {
  key: string;
  emoji: string;
  title: string;
  subtitle: string;
  accent: string;
  points: string[];
};

const SLIDES: Slide[] = [
  {
    key:      "welcome",
    emoji:    "✅",
    title:    "Добро пожаловать\nв CloNote",
    subtitle: "Твои задачи — твой порядок.",
    accent:   "#18181b",
    points:   [
      "Минимализм в стиле Notion",
      "Без рекламы и без подписок",
      "Полностью бесплатно",
    ],
  },
  {
    key:      "tasks",
    emoji:    "📋",
    title:    "Задачи\nи подзадачи",
    subtitle: "Организуй работу по категориям и приоритетам.",
    accent:   "#6366f1",
    points:   [
      "Категории: Работа, Дом, Покупки...",
      "Приоритеты: срочно / важно / обычно",
      "Вложенные подзадачи на любую глубину",
    ],
  },
  {
    key:      "habits",
    emoji:    "🌱",
    title:    "Трекер\nпривычек",
    subtitle: "Строй полезные привычки день за днём.",
    accent:   "#10b981",
    points:   [
      "Отмечай привычки каждый день",
      "Следи за стриком — не прерывай цепочку",
      "Разные цвета для разных привычек",
    ],
  },
  {
    key:      "dashboard",
    emoji:    "📊",
    title:    "Дашборд\nи граф",
    subtitle: "Видь всю картину своей продуктивности.",
    accent:   "#f59e0b",
    points:   [
      "Heatmap активности как в GitHub",
      "Граф связей задач — 3 режима",
      "Экспорт в Markdown и HTML",
    ],
  },
  {
    key:      "ai",
    emoji:    "🤖",
    title:    "ИИ управляет\nтвоими задачами",
    subtitle: "Подключи Claude, Cursor или Cline.",
    accent:   "#8b5cf6",
    points:   [
      "Просто скажи: «создай задачу»",
      "ИИ видит и редактирует твой список",
      "QR-код для быстрого подключения",
    ],
  },
];

export default function OnboardingScreen() {
  const { colors, theme } = useTheme();
  const insets   = useSafeAreaInsets();
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const isDark   = theme === "dark";

  const [index, setIndex] = useState(0);
  const flatRef  = useRef<FlatList<Slide>>(null);
  const scrollX  = useRef(new Animated.Value(0)).current;

  const slide = SLIDES[index];

  const finish = async () => {
    await AsyncStorage.setItem(ONBOARDING_KEY, "1");
    router.replace("/login");
  };

  const next = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (index < SLIDES.length - 1) {
      flatRef.current?.scrollToIndex({ index: index + 1, animated: true });
      setIndex(index + 1);
    } else {
      finish();
    }
  };

  const skip = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    finish();
  };

  const isLast = index === SLIDES.length - 1;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Skip */}
      {!isLast && (
        <TouchableOpacity
          style={[styles.skipBtn, { paddingTop: topInset + 16 }]}
          onPress={skip}
          activeOpacity={0.6}
        >
          <Text style={[styles.skipText, { color: colors.mutedForeground }]}>Пропустить</Text>
        </TouchableOpacity>
      )}

      {/* Slides */}
      <FlatList
        ref={flatRef}
        data={SLIDES}
        keyExtractor={s => s.key}
        horizontal
        pagingEnabled
        scrollEnabled={false}
        showsHorizontalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { x: scrollX } } }], { useNativeDriver: false })}
        renderItem={({ item: s }: { item: Slide }) => (
          <View style={[styles.slide, { width: SW }]}>
            {/* Emoji bubble */}
            <View style={[styles.emojiBubble, { backgroundColor: isDark ? "#1a1a1a" : "#f4f4f5" }]}>
              <Text style={styles.emojiText}>{s.emoji}</Text>
            </View>

            <Text style={[styles.slideTitle, { color: colors.foreground }]}>{s.title}</Text>
            <Text style={[styles.slideSub, { color: colors.mutedForeground }]}>{s.subtitle}</Text>

            {/* Points */}
            <View style={styles.points}>
              {s.points.map((p, i) => (
                <View key={i} style={styles.pointRow}>
                  <View style={[styles.pointDot, { backgroundColor: s.accent }]} />
                  <Text style={[styles.pointText, { color: colors.foreground }]}>{p}</Text>
                </View>
              ))}
            </View>
          </View>
        )}
      />

      {/* Bottom */}
      <View style={[styles.bottom, { paddingBottom: insets.bottom + 24 }]}>
        {/* Dots */}
        <View style={styles.dots}>
          {SLIDES.map((_, i) => {
            const inputRange = [(i - 1) * SW, i * SW, (i + 1) * SW];
            const width = scrollX.interpolate({ inputRange, outputRange: [8, 24, 8], extrapolate: "clamp" });
            const opacity = scrollX.interpolate({ inputRange, outputRange: [0.3, 1, 0.3], extrapolate: "clamp" });
            const bg = index === i ? slide.accent : (isDark ? "#444" : "#d4d4d8");
            return (
              <Animated.View
                key={i}
                style={[styles.dot, { width, opacity, backgroundColor: bg }]}
              />
            );
          })}
        </View>

        {/* Button */}
        <TouchableOpacity
          style={[styles.nextBtn, { backgroundColor: slide.accent }]}
          onPress={next}
          activeOpacity={0.85}
        >
          <Text style={styles.nextBtnText}>
            {isLast ? "Начать  →" : "Далее  →"}
          </Text>
        </TouchableOpacity>

        {/* Step counter */}
        <Text style={[styles.counter, { color: colors.mutedForeground }]}>
          {index + 1} / {SLIDES.length}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  skipBtn: {
    position: "absolute", top: 0, right: 20, zIndex: 10,
    paddingVertical: 8, paddingHorizontal: 4,
  },
  skipText: { fontSize: 14, fontFamily: "Inter_400Regular" },

  slide: {
    flex: 1, alignItems: "center", justifyContent: "center",
    paddingHorizontal: 36, paddingTop: 60, paddingBottom: 160, gap: 20,
  },

  emojiBubble: {
    width: 120, height: 120, borderRadius: 36,
    alignItems: "center", justifyContent: "center",
    marginBottom: 12,
  },
  emojiText: { fontSize: 60 },

  slideTitle: {
    fontSize: 30, fontFamily: "Inter_700Bold", fontWeight: "700",
    textAlign: "center", letterSpacing: -0.8, lineHeight: 38,
  },
  slideSub: {
    fontSize: 15, fontFamily: "Inter_400Regular",
    textAlign: "center", lineHeight: 22,
  },

  points: { gap: 12, alignSelf: "stretch", marginTop: 8 },
  pointRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  pointDot: { width: 8, height: 8, borderRadius: 4, flexShrink: 0 },
  pointText: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 20, flex: 1 },

  bottom: {
    position: "absolute", bottom: 0, left: 0, right: 0,
    alignItems: "center", gap: 16, paddingHorizontal: 24,
    paddingTop: 16,
  },

  dots: { flexDirection: "row", alignItems: "center", gap: 6 },
  dot:  { height: 8, borderRadius: 4 },

  nextBtn: {
    width: "100%", paddingVertical: 16, borderRadius: 14,
    alignItems: "center",
  },
  nextBtnText: {
    fontSize: 17, fontFamily: "Inter_600SemiBold", fontWeight: "600",
    color: "#fff", letterSpacing: 0.2,
  },

  counter: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
