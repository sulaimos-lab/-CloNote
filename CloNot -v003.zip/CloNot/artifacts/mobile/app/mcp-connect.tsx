/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * mcp-connect.tsx
 * Экран подключения ИИ-ассистентов (Claude, Cursor, Cline и др.)
 * через протокол MCP (Model Context Protocol).
 * Показывает QR-код, URL и JSON-конфиг для копирования/шаринга.
 */
import { Feather } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Platform,
  ScrollView,
  Share,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import QRCode from "react-native-qrcode-svg";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";

const MCP_URL =
  "https://9670f83a-1e11-4a65-8f8d-252fd6eb6a94-00-2d6gnvzcs6qt8.sisko.replit.dev/mcp-server/mcp";

const CONFIG_JSON = JSON.stringify(
  {
    mcpServers: {
      clonote: {
        type: "http",
        url: MCP_URL,
      },
    },
  },
  null,
  2,
);

const AI_TOOLS = [
  { name: "Claude Desktop", emoji: "🤖", hint: "claude_desktop_config.json" },
  { name: "Cursor",         emoji: "⚡", hint: ".cursor/mcp.json" },
  { name: "Windsurf",       emoji: "🌊", hint: "mcp_config.json" },
  { name: "Cline",          emoji: "🔧", hint: "Настройки → MCP Servers" },
];

const TOOLS_LIST = [
  { icon: "list",      label: "list_tasks",     desc: "Показать все задачи" },
  { icon: "plus",      label: "create_task",    desc: "Создать новую задачу" },
  { icon: "check",     label: "complete_task",  desc: "Отметить выполненной" },
  { icon: "edit-2",    label: "update_task",    desc: "Изменить задачу" },
  { icon: "trash-2",   label: "delete_task",    desc: "Удалить задачу" },
  { icon: "bar-chart", label: "get_stats",      desc: "Статистика задач" },
];

export default function McpConnectScreen() {
  const { colors } = useTheme();
  const insets   = useSafeAreaInsets();
  const topInset = Platform.OS === "web" ? 0 : insets.top;

  const [copied, setCopied] = useState<"url" | "config" | null>(null);

  const copy = async (text: string, type: "url" | "config") => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await Clipboard.setStringAsync(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  const share = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await Share.share({ message: `CloNote MCP Server\n${MCP_URL}` });
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="chevron-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Подключить ИИ</Text>
        <TouchableOpacity onPress={share} style={styles.shareBtn} activeOpacity={0.7}>
          <Feather name="share" size={18} color={colors.foreground} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 48 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* QR block */}
        <View style={[styles.qrCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.qrTitle, { color: colors.foreground }]}>
            Отсканируй QR-код
          </Text>
          <Text style={[styles.qrSub, { color: colors.mutedForeground }]}>
            или скопируй URL вручную
          </Text>

          <View style={[styles.qrBox, { backgroundColor: "#fff" }]}>
            {Platform.OS !== "web" ? (
              <QRCode
                value={MCP_URL}
                size={200}
                color="#000"
                backgroundColor="#fff"
              />
            ) : (
              <View style={styles.qrWebFallback}>
                <Text style={{ fontSize: 48 }}>🔗</Text>
                <Text style={[styles.qrWebText, { color: colors.mutedForeground }]}>
                  QR недоступен на веб
                </Text>
              </View>
            )}
          </View>

          {/* URL row */}
          <TouchableOpacity
            style={[styles.urlRow, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => copy(MCP_URL, "url")}
            activeOpacity={0.7}
          >
            <Text style={[styles.urlText, { color: colors.foreground }]} numberOfLines={1} ellipsizeMode="middle">
              {MCP_URL}
            </Text>
            <View style={[styles.copyBadge, { backgroundColor: copied === "url" ? "#10B981" : colors.border }]}>
              <Feather name={copied === "url" ? "check" : "copy"} size={13} color={copied === "url" ? "#fff" : colors.mutedForeground} />
            </View>
          </TouchableOpacity>
        </View>

        {/* Config block */}
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>КОНФИГУРАЦИЯ</Text>
          <View style={[styles.configCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.configText, { color: colors.foreground }]}>{CONFIG_JSON}</Text>
            <TouchableOpacity
              style={[styles.copyConfigBtn, { borderTopColor: colors.border, backgroundColor: copied === "config" ? "#10B98118" : "transparent" }]}
              onPress={() => copy(CONFIG_JSON, "config")}
              activeOpacity={0.7}
            >
              <Feather name={copied === "config" ? "check" : "copy"} size={14} color={copied === "config" ? "#10B981" : colors.mutedForeground} />
              <Text style={[styles.copyConfigText, { color: copied === "config" ? "#10B981" : colors.mutedForeground }]}>
                {copied === "config" ? "Скопировано!" : "Скопировать конфиг"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Compatible tools */}
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ПОДДЕРЖИВАЕМЫЕ ИИ</Text>
          <View style={[styles.toolsCard, { borderColor: colors.border }]}>
            {AI_TOOLS.map((tool, idx) => (
              <View
                key={tool.name}
                style={[
                  styles.toolRow,
                  { borderBottomColor: colors.border },
                  idx === AI_TOOLS.length - 1 && { borderBottomWidth: 0 },
                ]}
              >
                <Text style={styles.toolEmoji}>{tool.emoji}</Text>
                <View style={styles.toolInfo}>
                  <Text style={[styles.toolName, { color: colors.foreground }]}>{tool.name}</Text>
                  <Text style={[styles.toolHint, { color: colors.mutedForeground }]}>{tool.hint}</Text>
                </View>
                <View style={[styles.toolBadge, { backgroundColor: "#10B98118" }]}>
                  <Text style={[styles.toolBadgeText, { color: "#10B981" }]}>MCP</Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Available tools */}
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ЧТО УМЕЕТ ИИ</Text>
          <View style={[styles.toolsCard, { borderColor: colors.border }]}>
            {TOOLS_LIST.map((t, idx) => (
              <View
                key={t.label}
                style={[
                  styles.toolRow,
                  { borderBottomColor: colors.border },
                  idx === TOOLS_LIST.length - 1 && { borderBottomWidth: 0 },
                ]}
              >
                <View style={[styles.toolIconWrap, { backgroundColor: colors.surface }]}>
                  <Feather name={t.icon as any} size={14} color={colors.foreground} />
                </View>
                <View style={styles.toolInfo}>
                  <Text style={[styles.toolName, { color: colors.foreground, fontFamily: "Inter_500Medium" }]}>
                    {t.label}
                  </Text>
                  <Text style={[styles.toolHint, { color: colors.mutedForeground }]}>{t.desc}</Text>
                </View>
              </View>
            ))}
            <View style={[styles.moreRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.moreText, { color: colors.mutedForeground }]}>
                + ещё 4 инструмента (reopen, archive, get_task, list_categories)
              </Text>
            </View>
          </View>
        </View>

        {/* How to use tip */}
        <View style={[styles.tipCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.tipTitle, { color: colors.foreground }]}>💬 Примеры команд</Text>
          {[
            "Покажи мои задачи на сегодня",
            "Создай задачу: позвонить врачу, срочно",
            "Отметь задачу t1 выполненной",
            "Сделай ежедневный обзор задач",
            "Разбей задачу на подзадачи",
          ].map(cmd => (
            <View key={cmd} style={[styles.cmdRow, { borderTopColor: colors.border }]}>
              <Text style={[styles.cmdQuote, { color: colors.mutedForeground }]}>›</Text>
              <Text style={[styles.cmdText, { color: colors.foreground }]}>«{cmd}»</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { padding: 4, marginRight: 10 },
  headerTitle: { flex: 1, fontSize: 20, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.4 },
  shareBtn: { padding: 6 },

  content: { paddingHorizontal: 20, paddingTop: 24, gap: 24 },

  qrCard: {
    borderRadius: 16, borderWidth: StyleSheet.hairlineWidth,
    padding: 24, alignItems: "center", gap: 6,
  },
  qrTitle: { fontSize: 18, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.3 },
  qrSub: { fontSize: 13, fontFamily: "Inter_400Regular", marginBottom: 16 },
  qrBox: { borderRadius: 16, padding: 16, marginBottom: 16 },
  qrWebFallback: { width: 200, height: 200, alignItems: "center", justifyContent: "center", gap: 8 },
  qrWebText: { fontSize: 13, fontFamily: "Inter_400Regular" },

  urlRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    borderWidth: 1, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12,
    width: "100%",
  },
  urlText: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular" },
  copyBadge: { width: 26, height: 26, borderRadius: 6, alignItems: "center", justifyContent: "center" },

  section: { gap: 8 },
  sectionLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.6 },

  configCard: {
    borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, overflow: "hidden",
  },
  configText: {
    fontFamily: "Inter_400Regular", fontSize: 12,
    padding: 14, lineHeight: 20,
  },
  copyConfigBtn: {
    flexDirection: "row", alignItems: "center", gap: 8,
    borderTopWidth: StyleSheet.hairlineWidth, padding: 12, paddingHorizontal: 14,
  },
  copyConfigText: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },

  toolsCard: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 12, overflow: "hidden" },
  toolRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingVertical: 12, paddingHorizontal: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  toolEmoji: { fontSize: 20, width: 28, textAlign: "center" },
  toolIconWrap: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  toolInfo: { flex: 1, gap: 2 },
  toolName: { fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  toolHint: { fontSize: 12, fontFamily: "Inter_400Regular" },
  toolBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  toolBadgeText: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  moreRow: { borderTopWidth: StyleSheet.hairlineWidth, paddingVertical: 10, paddingHorizontal: 14 },
  moreText: { fontSize: 12, fontFamily: "Inter_400Regular" },

  tipCard: { borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, padding: 16, gap: 0 },
  tipTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginBottom: 10 },
  cmdRow: { flexDirection: "row", alignItems: "flex-start", gap: 8, paddingVertical: 7, borderTopWidth: StyleSheet.hairlineWidth },
  cmdQuote: { fontSize: 16, fontFamily: "Inter_400Regular", marginTop: 1 },
  cmdText: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
});
