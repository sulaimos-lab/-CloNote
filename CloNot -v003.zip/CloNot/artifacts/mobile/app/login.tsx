import { Feather } from "@expo/vector-icons";
import * as AuthSession from "expo-auth-session";
import * as Haptics from "expo-haptics";
import * as WebBrowser from "expo-web-browser";
import { Redirect } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  AuthUser,
  OAUTH_CONFIG,
  PROVIDER_META,
  Provider,
  fetchProviderUser,
  useAuth,
} from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";

WebBrowser.maybeCompleteAuthSession();

const REDIRECT_URI = AuthSession.makeRedirectUri({ scheme: "mobile", path: "login" });

const GOOGLE_ID  = process.env.EXPO_PUBLIC_GOOGLE_CLIENT_ID  ?? "";
const YANDEX_ID  = process.env.EXPO_PUBLIC_YANDEX_CLIENT_ID  ?? "";
const VK_ID      = process.env.EXPO_PUBLIC_VK_CLIENT_ID      ?? "";
const MAILRU_ID  = process.env.EXPO_PUBLIC_MAILRU_CLIENT_ID  ?? "";

export default function LoginScreen() {
  const { user, setUser } = useAuth();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState<Provider | null>(null);

  const topPad = Platform.OS === "web" ? 0 : insets.top;

  /* ─── OAuth hooks (must be inside component) ────────── */
  const [, googleResponse, googlePromptAsync] = AuthSession.useAuthRequest(
    { clientId: GOOGLE_ID || "placeholder", responseType: AuthSession.ResponseType.Token, scopes: ["openid", "email", "profile"], redirectUri: REDIRECT_URI, usePKCE: false },
    { authorizationEndpoint: OAUTH_CONFIG.google.authorizationEndpoint },
  );
  const [, yandexResponse, yandexPromptAsync] = AuthSession.useAuthRequest(
    { clientId: YANDEX_ID || "placeholder", responseType: AuthSession.ResponseType.Token, scopes: ["login:email", "login:info", "login:avatar"], redirectUri: REDIRECT_URI, usePKCE: false },
    { authorizationEndpoint: OAUTH_CONFIG.yandex.authorizationEndpoint },
  );
  const [, vkResponse, vkPromptAsync] = AuthSession.useAuthRequest(
    { clientId: VK_ID || "placeholder", responseType: AuthSession.ResponseType.Token, scopes: ["email"], redirectUri: REDIRECT_URI, usePKCE: false, extraParams: { display: "mobile", v: "5.131" } },
    { authorizationEndpoint: OAUTH_CONFIG.vk.authorizationEndpoint },
  );
  const [, mailruResponse, mailruPromptAsync] = AuthSession.useAuthRequest(
    { clientId: MAILRU_ID || "placeholder", responseType: AuthSession.ResponseType.Token, scopes: ["userinfo"], redirectUri: REDIRECT_URI, usePKCE: false },
    { authorizationEndpoint: OAUTH_CONFIG.mailru.authorizationEndpoint },
  );

  /* ─── Handle OAuth responses ────────────────────────── */
  const handleOAuthResponse = async (provider: Provider, response: AuthSession.AuthSessionResult | null) => {
    if (!response || response.type === "dismiss" || response.type === "cancel") {
      setLoading(null);
      return;
    }
    if (response.type === "success") {
        const params = (response as unknown as { params?: Record<string, string> }).params ?? {};
      const token = params.access_token;
      if (token) {
        try {
          const authUser = await fetchProviderUser(provider, token);
          setUser(authUser);
        } catch {
          Alert.alert("Ошибка", "Не удалось получить данные профиля. Попробуй ещё раз.");
          setLoading(null);
        }
      } else {
        setLoading(null);
      }
    } else if (response.type === "error") {
      Alert.alert("Ошибка входа", (response as any).error?.message ?? "Неизвестная ошибка");
      setLoading(null);
    } else {
      setLoading(null);
    }
  };

  useEffect(() => { handleOAuthResponse("google",  googleResponse); }, [googleResponse]);
  useEffect(() => { handleOAuthResponse("yandex",  yandexResponse); }, [yandexResponse]);
  useEffect(() => { handleOAuthResponse("vk",      vkResponse); },    [vkResponse]);
  useEffect(() => { handleOAuthResponse("mailru",  mailruResponse); }, [mailruResponse]);

  /* ─── Redirect if already logged in ─────────────────── */
  if (user) return <Redirect href="/(tabs)" />;

  /* ─── Login actions ──────────────────────────────────── */
  const loginWith = async (provider: Provider) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    if (provider === "guest") {
      const guestUser: AuthUser = { id: "guest_" + Date.now(), name: "Гость", provider: "guest" };
      setUser(guestUser);
      return;
    }

    const clientIds: Record<string, string> = { google: GOOGLE_ID, yandex: YANDEX_ID, vk: VK_ID, mailru: MAILRU_ID };
    if (!clientIds[provider]) {
      const envName = `EXPO_PUBLIC_${provider.toUpperCase()}_CLIENT_ID`;
      Alert.alert(
        "Требуется настройка",
        `Для входа через ${PROVIDER_META[provider].label} добавь секрет:\n\n${envName}\n\nПолучи Client ID в панели разработчика ${PROVIDER_META[provider].label}.`,
        [{ text: "Понятно" }],
      );
      return;
    }

    setLoading(provider);
    try {
      const prompts: Record<string, () => Promise<any>> = {
        google: googlePromptAsync,
        yandex: yandexPromptAsync,
        vk: vkPromptAsync,
        mailru: mailruPromptAsync,
      };
      await prompts[provider]();
    } catch {
      Alert.alert("Ошибка", "Не удалось открыть окно входа.");
      setLoading(null);
    }
  };

  /* ─── Provider list ──────────────────────────────────── */
  const PROVIDERS: { id: Provider; clientId: string }[] = [
    { id: "google",  clientId: GOOGLE_ID  },
    { id: "yandex",  clientId: YANDEX_ID  },
    { id: "vk",      clientId: VK_ID      },
    { id: "mailru",  clientId: MAILRU_ID  },
  ];

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingTop: topPad + 40, paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Logo */}
        <View style={styles.logoWrap}>
          <View style={[styles.logoBox, { backgroundColor: colors.foreground }]}>
            <Feather name="check-square" size={32} color={colors.background} />
          </View>
          <Text style={[styles.appName, { color: colors.foreground }]}>CloNote</Text>
          <Text style={[styles.tagline, { color: colors.mutedForeground }]}>
            Твои задачи — твой порядок
          </Text>
        </View>

        {/* Auth providers */}
        <View style={styles.providersWrap}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
            ВОЙТИ С ПОМОЩЬЮ
          </Text>

          {PROVIDERS.map(({ id, clientId }) => {
            const meta = PROVIDER_META[id];
            const isLoading_ = loading === id;
            const noKey = !clientId;

            return (
              <TouchableOpacity
                key={id}
                style={[
                  styles.providerBtn,
                  {
                    backgroundColor: noKey ? colors.surface : meta.bg,
                    borderColor: noKey ? colors.border : "transparent",
                    opacity: (loading && loading !== id) ? 0.5 : 1,
                  },
                ]}
                onPress={() => loginWith(id)}
                activeOpacity={0.85}
                disabled={!!loading}
              >
                {isLoading_ ? (
                  <ActivityIndicator color={noKey ? colors.mutedForeground : "#fff"} size="small" style={{ width: 28 }} />
                ) : (
                  <Text style={styles.providerEmoji}>{meta.emoji}</Text>
                )}
                <View style={styles.providerTextCol}>
                  <Text style={[styles.providerLabel, { color: noKey ? colors.foreground : meta.color }]}>
                    {isLoading_ ? "Входим..." : `Войти через ${meta.label}`}
                  </Text>
                  {noKey && (
                    <Text style={[styles.providerHint, { color: colors.mutedForeground }]}>
                      Требует настройки Client ID
                    </Text>
                  )}
                </View>
                {!isLoading_ && (
                  <Feather
                    name={noKey ? "settings" : "arrow-right"}
                    size={15}
                    color={noKey ? colors.mutedForeground : meta.color}
                  />
                )}
              </TouchableOpacity>
            );
          })}

          {/* Divider */}
          <View style={styles.dividerWrap}>
            <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
            <Text style={[styles.dividerText, { color: colors.mutedForeground }]}>или</Text>
            <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
          </View>

          {/* Guest */}
          <TouchableOpacity
            style={[styles.guestBtn, { borderColor: colors.border }]}
            onPress={() => loginWith("guest")}
            activeOpacity={0.7}
            disabled={!!loading}
          >
            <Feather name="user" size={16} color={colors.mutedForeground} />
            <Text style={[styles.guestLabel, { color: colors.mutedForeground }]}>
              Войти без аккаунта (Гость)
            </Text>
          </TouchableOpacity>
        </View>

        {/* Privacy note */}
        <Text style={[styles.footer, { color: colors.mutedForeground }]}>
          Данные хранятся только на вашем устройстве.{"\n"}Мы не передаём их третьим лицам.
        </Text>

        {/* Setup hint */}
        <View style={[styles.setupHint, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Feather name="info" size={14} color={colors.mutedForeground} />
          <Text style={[styles.setupHintText, { color: colors.mutedForeground }]}>
            Для OAuth: добавь Client ID каждого провайдера в{" "}
            <Text style={{ fontFamily: "Inter_600SemiBold" }}>Secrets → EXPO_PUBLIC_*_CLIENT_ID</Text>
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  scroll: { paddingHorizontal: 24, alignItems: "stretch" },
  logoWrap: { alignItems: "center", gap: 12, marginBottom: 48 },
  logoBox: {
    width: 72, height: 72, borderRadius: 20,
    alignItems: "center", justifyContent: "center",
  },
  appName: { fontSize: 32, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -1 },
  tagline: { fontSize: 15, fontFamily: "Inter_400Regular", textAlign: "center" },
  providersWrap: { gap: 10 },
  sectionLabel: {
    fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600",
    letterSpacing: 0.8, marginBottom: 4,
  },
  providerBtn: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingHorizontal: 16, paddingVertical: 14,
    borderRadius: 12, borderWidth: 1,
  },
  providerEmoji: { fontSize: 22, width: 28, textAlign: "center" },
  providerTextCol: { flex: 1, gap: 2 },
  providerLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  providerHint: { fontSize: 11, fontFamily: "Inter_400Regular" },
  dividerWrap: { flexDirection: "row", alignItems: "center", gap: 10, marginVertical: 4 },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  guestBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 8, borderWidth: 1, borderRadius: 12, paddingVertical: 13,
  },
  guestLabel: { fontSize: 14, fontFamily: "Inter_400Regular" },
  footer: {
    fontSize: 12, fontFamily: "Inter_400Regular",
    textAlign: "center", marginTop: 32, lineHeight: 18,
  },
  setupHint: {
    flexDirection: "row", gap: 8, alignItems: "flex-start",
    borderRadius: 10, borderWidth: 1, padding: 12, marginTop: 16,
  },
  setupHintText: { fontSize: 12, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 17 },
});
