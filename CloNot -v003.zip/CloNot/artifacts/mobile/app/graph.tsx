/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * graph.tsx
 * Граф связей задач — визуализация в трёх режимах:
 *   • По категориям — кластеры задач вокруг категорий
 *   • По приоритету — группировка срочно/важно/обычно
 *   • Иерархия     — родительские задачи с подзадачами
 * Рендер через react-native-svg без тяжёлых D3-зависимостей.
 */
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  Dimensions,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Svg, { Circle, Line, Text as SvgText, G } from "react-native-svg";
import { useTheme } from "@/context/ThemeContext";
import { useTasks, PRIORITY_CONFIG } from "@/context/TaskContext";
import type { Task } from "@/context/TaskContext";

const { width: SW } = Dimensions.get("window");
const W = Math.min(SW - 40, 500);
const H = W * 0.9;
const CX = W / 2;
const CY = H / 2;

type ViewMode = "category" | "priority" | "hierarchy";

function layoutNodes(tasks: Task[], categories: { id: string; name: string; emoji: string }[], mode: ViewMode) {
  const active = tasks.filter(t => !t.archived);

  if (mode === "category") {
    const cats = categories.filter(c => active.some(t => t.category === c.id));
    const nodes: { id: string; label: string; x: number; y: number; r: number; color: string; sub?: boolean }[] = [];
    const edges: { from: string; to: string }[] = [];

    cats.forEach((cat, ci) => {
      const angle = (2 * Math.PI * ci) / cats.length - Math.PI / 2;
      const cx = CX + Math.cos(angle) * (W * 0.3);
      const cy = CY + Math.sin(angle) * (H * 0.28);
      const catTasks = active.filter(t => t.category === cat.id);
      const color = catColor(ci);
      nodes.push({ id: `cat_${cat.id}`, label: `${cat.emoji} ${cat.name}`, x: cx, y: cy, r: 22, color });

      catTasks.slice(0, 6).forEach((t, ti) => {
        const spread = Math.min(catTasks.length, 6);
        const ta = angle + ((ti - spread / 2 + 0.5) / spread) * 1.2;
        const tx = cx + Math.cos(ta) * 72;
        const ty = cy + Math.sin(ta) * 62;
        nodes.push({ id: t.id, label: t.title.slice(0, 14), x: tx, y: ty, r: t.completed ? 8 : 11, color: t.completed ? "#10B981" : color, sub: true });
        edges.push({ from: `cat_${cat.id}`, to: t.id });
      });
      if (catTasks.length > 6) {
        nodes.push({ id: `more_${cat.id}`, label: `+${catTasks.length - 6}`, x: cx + Math.cos(angle + 0.7) * 75, y: cy + Math.sin(angle + 0.7) * 65, r: 9, color: "#aaa", sub: true });
        edges.push({ from: `cat_${cat.id}`, to: `more_${cat.id}` });
      }
    });
    return { nodes, edges };
  }

  if (mode === "priority") {
    const groups = [
      { key: "high",   label: "🔴 Срочно",  color: "#E03E3E", angle: -Math.PI / 2 },
      { key: "normal", label: "🟡 Важно",   color: "#D9730D", angle: Math.PI / 6 },
      { key: "low",    label: "⚪ Обычно",  color: "#9B9A97", angle: Math.PI * 5 / 6 },
    ] as const;
    const nodes: any[] = [];
    const edges: any[] = [];
    for (const g of groups) {
      const gx = CX + Math.cos(g.angle) * (W * 0.28);
      const gy = CY + Math.sin(g.angle) * (H * 0.25);
      const gTasks = active.filter(t => t.priority === g.key && !t.completed);
      nodes.push({ id: `pri_${g.key}`, label: g.label, x: gx, y: gy, r: 20, color: g.color });
      gTasks.slice(0, 5).forEach((t, ti) => {
        const ta = g.angle + (ti - 2) * 0.35;
        nodes.push({ id: t.id, label: t.title.slice(0, 12), x: gx + Math.cos(ta) * 68, y: gy + Math.sin(ta) * 58, r: 10, color: g.color, sub: true });
        edges.push({ from: `pri_${g.key}`, to: t.id });
      });
    }
    return { nodes, edges };
  }

  // hierarchy
  const roots = active.filter(t => !t.parentId).slice(0, 8);
  const nodes: any[] = [];
  const edges: any[] = [];
  roots.forEach((root, ri) => {
    const angle = (2 * Math.PI * ri) / roots.length - Math.PI / 2;
    const rx = CX + Math.cos(angle) * (W * 0.3);
    const ry = CY + Math.sin(angle) * (H * 0.28);
    const color = catColor(ri);
    nodes.push({ id: root.id, label: root.title.slice(0, 14), x: rx, y: ry, r: root.completed ? 10 : 16, color: root.completed ? "#10B981" : color });
    const kids = active.filter(t => t.parentId === root.id).slice(0, 4);
    kids.forEach((k, ki) => {
      const ka = angle + (ki - kids.length / 2 + 0.5) * 0.5;
      nodes.push({ id: k.id, label: k.title.slice(0, 12), x: rx + Math.cos(ka) * 65, y: ry + Math.sin(ka) * 55, r: k.completed ? 7 : 10, color: k.completed ? "#10B981" : color, sub: true });
      edges.push({ from: root.id, to: k.id });
    });
  });
  return { nodes, edges };
}

function catColor(i: number) {
  const palette = ["#6366f1","#f59e0b","#10b981","#ef4444","#8b5cf6","#0ea5e9","#ec4899","#14b8a6"];
  return palette[i % palette.length];
}

export default function GraphScreen() {
  const { colors, theme } = useTheme();
  const insets = useSafeAreaInsets();
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const { tasks, categories } = useTasks();
  const [mode, setMode] = useState<ViewMode>("category");
  const [selected, setSelected] = useState<string | null>(null);

  const { nodes, edges } = useMemo(() => layoutNodes(tasks, categories, mode), [tasks, categories, mode]);

  const selectedTask = useMemo(() => {
    if (!selected) return null;
    return tasks.find(t => t.id === selected) ?? null;
  }, [selected, tasks]);

  const isDark = theme === "dark";
  const lineColor = isDark ? "#333" : "#e5e7eb";
  const labelColor = isDark ? "#e5e7eb" : "#374151";

  const MODES: { key: ViewMode; label: string; icon: string }[] = [
    { key: "category",  label: "Категории", icon: "grid" },
    { key: "priority",  label: "Приоритет", icon: "alert-triangle" },
    { key: "hierarchy", label: "Иерархия",  icon: "git-merge" },
  ];

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="chevron-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Граф задач</Text>
        <View style={{ width: 34 }} />
      </View>

      {/* Mode switcher */}
      <View style={styles.modeRow}>
        {MODES.map(m => (
          <TouchableOpacity
            key={m.key}
            style={[styles.modeBtn, { backgroundColor: mode === m.key ? colors.foreground : colors.surface, borderColor: colors.border }]}
            onPress={() => { setMode(m.key); setSelected(null); }}
            activeOpacity={0.7}
          >
            <Feather name={m.icon as any} size={13} color={mode === m.key ? colors.background : colors.mutedForeground} />
            <Text style={[styles.modeBtnText, { color: mode === m.key ? colors.background : colors.mutedForeground }]}>
              {m.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* SVG Graph */}
      <View style={styles.svgWrap}>
        <Svg width={W} height={H}>
          {edges.map((e, i) => {
            const from = nodes.find(n => n.id === e.from);
            const to   = nodes.find(n => n.id === e.to);
            if (!from || !to) return null;
            return (
              <Line key={i} x1={from.x} y1={from.y} x2={to.x} y2={to.y}
                stroke={lineColor} strokeWidth={1.5} />
            );
          })}
          {nodes.map(n => (
            <G key={n.id} onPress={() => setSelected(n.id === selected ? null : n.id)}>
              <Circle
                cx={n.x} cy={n.y} r={n.r + (selected === n.id ? 4 : 0)}
                fill={n.color}
                opacity={selected && selected !== n.id ? 0.4 : 1}
                stroke={selected === n.id ? "#fff" : "transparent"}
                strokeWidth={2}
              />
              {!n.sub && (
                <SvgText
                  x={n.x} y={n.y + n.r + 13}
                  textAnchor="middle"
                  fontSize={10}
                  fill={labelColor}
                  fontWeight="600"
                >
                  {n.label}
                </SvgText>
              )}
            </G>
          ))}
        </Svg>
      </View>

      {/* Selected task detail */}
      {selectedTask ? (
        <View style={[styles.detailCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <View style={[styles.detailDot, { backgroundColor: selectedTask.completed ? "#10B981" : PRIORITY_CONFIG[selectedTask.priority].color }]} />
            <Text style={[styles.detailTitle, { color: colors.foreground }]} numberOfLines={2}>
              {selectedTask.title}
            </Text>
          </View>
          <Text style={[styles.detailMeta, { color: colors.mutedForeground }]}>
            {categories.find(c => c.id === selectedTask.category)?.emoji}{" "}
            {categories.find(c => c.id === selectedTask.category)?.name} · {PRIORITY_CONFIG[selectedTask.priority].label}
            {selectedTask.completed ? " · ✅ Выполнено" : ""}
          </Text>
        </View>
      ) : (
        <View style={[styles.hintCard, { backgroundColor: colors.surface }]}>
          <Text style={[styles.hintText, { color: colors.mutedForeground }]}>
            Нажми на узел чтобы увидеть задачу
          </Text>
        </View>
      )}

      {/* Legend */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.legendScroll} contentContainerStyle={styles.legendRow}>
        {mode === "category" && categories.filter(c => tasks.some(t => t.category === c.id && !t.archived)).map((cat, i) => (
          <View key={cat.id} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: catColor(i) }]} />
            <Text style={[styles.legendText, { color: colors.mutedForeground }]}>{cat.emoji} {cat.name}</Text>
          </View>
        ))}
        {mode === "priority" && (["high","normal","low"] as const).map(p => (
          <View key={p} style={styles.legendItem}>
            <View style={[styles.legendDot, { backgroundColor: PRIORITY_CONFIG[p].color }]} />
            <Text style={[styles.legendText, { color: colors.mutedForeground }]}>{PRIORITY_CONFIG[p].label}</Text>
          </View>
        ))}
        <View style={styles.legendItem}>
          <View style={[styles.legendDot, { backgroundColor: "#10B981" }]} />
          <Text style={[styles.legendText, { color: colors.mutedForeground }]}>Выполнено</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingBottom: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { padding: 4, marginRight: 8, width: 34 },
  headerTitle: { flex: 1, fontSize: 20, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.4, textAlign: "center" },

  modeRow: { flexDirection: "row", gap: 8, paddingHorizontal: 20, paddingVertical: 14 },
  modeBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 5, paddingVertical: 8, borderRadius: 8, borderWidth: 1 },
  modeBtnText: { fontSize: 12, fontFamily: "Inter_500Medium", fontWeight: "500" },

  svgWrap: { alignItems: "center", paddingHorizontal: 20 },

  detailCard: {
    marginHorizontal: 20, marginTop: 14, borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, padding: 14, gap: 6,
  },
  detailDot: { width: 10, height: 10, borderRadius: 5 },
  detailTitle: { flex: 1, fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  detailMeta: { fontSize: 12, fontFamily: "Inter_400Regular", marginLeft: 20 },

  hintCard: { marginHorizontal: 20, marginTop: 14, borderRadius: 10, padding: 12, alignItems: "center" },
  hintText: { fontSize: 13, fontFamily: "Inter_400Regular" },

  legendScroll: { marginTop: 14 },
  legendRow: { paddingHorizontal: 20, gap: 14, paddingBottom: 8 },
  legendItem: { flexDirection: "row", alignItems: "center", gap: 6 },
  legendDot: { width: 10, height: 10, borderRadius: 5 },
  legendText: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
