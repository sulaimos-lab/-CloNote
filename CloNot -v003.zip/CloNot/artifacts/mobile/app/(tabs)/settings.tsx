import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { PROVIDER_META, useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import {
  cancelAllReminders,
  getNotifEnabled,
  getNotificationPermission,
  getScheduledCount,
  requestNotificationPermission,
  setNotifEnabled,
} from "@/utils/notifications";

type ThemeMode = "light" | "dark" | "system";

const THEME_OPTIONS: { key: ThemeMode; label: string; desc: string }[] = [
  { key: "light",  label: "Светлая",   desc: "Всегда белый фон"     },
  { key: "dark",   label: "Тёмная",    desc: "Всегда тёмный фон"    },
  { key: "system", label: "Системная", desc: "Следует теме телефона" },
];

export default function SettingsScreen() {
  const { colors, themeMode, setThemeMode } = useTheme();
  const { user, logout } = useAuth();
  const insets      = useSafeAreaInsets();
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 96 : insets.bottom + 72;

  const providerMeta = user ? PROVIDER_META[user.provider] : null;

  const [notifEnabled,   setNotifEnabledState] = useState(true);
  const [notifPerm,      setNotifPerm]         = useState<string>("undetermined");
  const [scheduledCount, setScheduledCount]    = useState(0);

  useEffect(() => {
    if (Platform.OS === "web") return;
    getNotifEnabled().then(setNotifEnabledState);
    getNotificationPermission().then(setNotifPerm);
    getScheduledCount().then(setScheduledCount);
  }, []);

  const handleToggleNotif = async (val: boolean) => {
    Haptics.selectionAsync();
    if (val) {
      const granted = await requestNotificationPermission();
      if (!granted) {
        Alert.alert("Нет разрешения", "Разреши уведомления в настройках телефона → CloNote → Уведомления.");
        return;
      }
    } else {
      await cancelAllReminders();
      setScheduledCount(0);
    }
    await setNotifEnabled(val);
    setNotifEnabledState(val);
    const newPerm = await getNotificationPermission();
    setNotifPerm(newPerm);
  };

  const handleClearAll = () => {
    Alert.alert("Очистить все напоминания?", "Все запланированные уведомления будут отменены.", [
      { text: "Отмена", style: "cancel" },
      {
        text: "Очистить", style: "destructive",
        onPress: async () => {
          await cancelAllReminders();
          setScheduledCount(0);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
      },
    ]);
  };

  const handleLogout = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert("Выйти из аккаунта?", "Данные задач останутся на устройстве.", [
      { text: "Отмена", style: "cancel" },
      {
        text: "Выйти", style: "destructive",
        onPress: async () => { await logout(); router.replace("/login"); },
      },
    ]);
  };

  const permLabel = Platform.OS === "web"
    ? "Недоступно на веб"
    : notifPerm === "granted" ? "✓ Разрешено" : notifPerm === "denied" ? "✗ Запрещено" : "Не запрошено";

  return (
    <ScrollView
      style={[styles.root, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: topInset + 20, paddingBottom: bottomPadding, paddingHorizontal: 20 }}
      showsVerticalScrollIndicator={false}
    >
      <Text style={[styles.title, { color: colors.foreground }]}>Настройки</Text>

      {/* ── Account ── */}
      {user && (
        <>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>АККАУНТ</Text>
          <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
            <View style={[styles.profileRow, { borderBottomColor: colors.border }]}>
              <View style={[styles.avatarWrap, { backgroundColor: providerMeta?.bg ?? colors.surface }]}>
                {user.avatar
                  ? <Image source={{ uri: user.avatar }} style={styles.avatarImg} />
                  : <Text style={styles.avatarEmoji}>{providerMeta?.emoji ?? "👤"}</Text>
                }
              </View>
              <View style={styles.profileInfo}>
                <Text style={[styles.profileName, { color: colors.foreground }]} numberOfLines={1}>{user.name}</Text>
                {user.email
                  ? <Text style={[styles.profileEmail, { color: colors.mutedForeground }]} numberOfLines={1}>{user.email}</Text>
                  : <View style={[styles.providerBadge, { backgroundColor: providerMeta?.bg ?? colors.surface }]}>
                      <Text style={[styles.providerBadgeText, { color: providerMeta?.color ?? colors.foreground }]}>
                        {providerMeta?.emoji} {providerMeta?.label ?? "Гость"}
                      </Text>
                    </View>
                }
              </View>
            </View>
            <TouchableOpacity style={[styles.row, { borderBottomWidth: 0 }]} onPress={handleLogout} activeOpacity={0.6}>
              <Text style={[styles.rowLabel, { color: "#E03E3E" }]}>Выйти из аккаунта</Text>
              <Feather name="log-out" size={18} color="#E03E3E" />
            </TouchableOpacity>
          </View>
        </>
      )}

      {/* ── Notifications ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 28 }]}>УВЕДОМЛЕНИЯ</Text>
      <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
        {/* Toggle */}
        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Напоминания о задачах</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>За 1 день и 1 час до срока</Text>
          </View>
          <Switch
            value={notifEnabled && Platform.OS !== "web"}
            onValueChange={handleToggleNotif}
            disabled={Platform.OS === "web"}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor="#fff"
          />
        </View>

        {/* Permission status */}
        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Разрешение системы</Text>
            <Text style={[styles.rowDesc, { color: notifPerm === "granted" ? "#2D9E6B" : notifPerm === "denied" ? "#E03E3E" : colors.mutedForeground }]}>
              {permLabel}
            </Text>
          </View>
          {notifPerm === "denied" && Platform.OS !== "web" && (
            <Feather name="alert-triangle" size={16} color="#E03E3E" />
          )}
        </View>

        {/* Scheduled count */}
        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Запланировано</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>
              {Platform.OS === "web" ? "Недоступно на веб" : `${scheduledCount} уведомлений`}
            </Text>
          </View>
        </View>

        {/* Clear all */}
        {scheduledCount > 0 && (
          <TouchableOpacity style={[styles.row, { borderBottomWidth: 0 }]} onPress={handleClearAll} activeOpacity={0.6}>
            <Text style={[styles.rowLabel, { color: "#E03E3E" }]}>Очистить все напоминания</Text>
            <Feather name="bell-off" size={16} color="#E03E3E" />
          </TouchableOpacity>
        )}
        {scheduledCount === 0 && (
          <View style={[styles.row, { borderBottomWidth: 0 }]}>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>
              Напоминания появятся при добавлении срока задачи
            </Text>
          </View>
        )}
      </View>

      {/* ── Projects ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 28 }]}>ПРОЕКТЫ</Text>
      <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[styles.row, { borderBottomWidth: 0 }]}
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); router.push("/categories"); }}
          activeOpacity={0.6}
        >
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Управление проектами</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>Добавить, изменить или удалить категории</Text>
          </View>
          <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      {/* ── AI Connect ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 28 }]}>ПОДКЛЮЧИТЬ ИИ</Text>
      <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[styles.row, { borderBottomWidth: 0 }]}
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); router.push("/mcp-connect"); }}
          activeOpacity={0.6}
        >
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>MCP — Claude, Cursor, Cline</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>QR-код и конфиг для подключения ИИ к задачам</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
            <View style={{ backgroundColor: "#10B98118", paddingHorizontal: 7, paddingVertical: 3, borderRadius: 6 }}>
              <Text style={{ fontSize: 11, color: "#10B981", fontFamily: "Inter_600SemiBold" }}>●  Live</Text>
            </View>
            <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
          </View>
        </TouchableOpacity>
      </View>

      {/* ── Theme ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 28 }]}>ТЕМА ОФОРМЛЕНИЯ</Text>
      <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
        {THEME_OPTIONS.map((opt, idx) => (
          <TouchableOpacity
            key={opt.key}
            style={[styles.row, { borderBottomColor: colors.border }, idx === THEME_OPTIONS.length - 1 && { borderBottomWidth: 0 }]}
            onPress={() => { Haptics.selectionAsync(); setThemeMode(opt.key); }}
            activeOpacity={0.6}
          >
            <View style={styles.rowText}>
              <Text style={[styles.rowLabel, { color: colors.foreground }]}>{opt.label}</Text>
              <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>{opt.desc}</Text>
            </View>
            {themeMode === opt.key && <Feather name="check" size={18} color={colors.primary} />}
          </TouchableOpacity>
        ))}
      </View>

      {/* ── About ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 28 }]}>О ПРИЛОЖЕНИИ</Text>
      <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>

        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>CloNote</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>Версия 1.0.0 · Тариф: Бесплатный</Text>
          </View>
          <View style={[styles.verBadge, { backgroundColor: "#10B98118" }]}>
            <Text style={[styles.verBadgeText, { color: "#10B981" }]}>v1.0.0</Text>
          </View>
        </View>

        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Автор</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>Sulaimon Qurbonov</Text>
          </View>
          <Text style={{ fontSize: 18 }}>👤</Text>
        </View>

        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Лицензия</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>MIT License © 2025</Text>
          </View>
          <Text style={{ fontSize: 18 }}>📄</Text>
        </View>

        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Платформа</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>Expo SDK 54 · React Native 0.81</Text>
          </View>
          <Text style={{ fontSize: 18 }}>📱</Text>
        </View>

        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Языки</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>TypeScript 5.9 · JavaScript (Node.js 24)</Text>
          </View>
          <Text style={{ fontSize: 18 }}>⌨️</Text>
        </View>

        <View style={[styles.row, { borderBottomColor: colors.border }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>База данных</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>PostgreSQL · Drizzle ORM</Text>
          </View>
          <Text style={{ fontSize: 18 }}>🗄️</Text>
        </View>

        <View style={[styles.row, { borderBottomWidth: 0 }]}>
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>ИИ-интеграция</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>MCP Protocol · Streamable HTTP</Text>
          </View>
          <Text style={{ fontSize: 18 }}>🤖</Text>
        </View>

      </View>

      {/* ── Legal ── */}
      <Text style={[styles.sectionLabel, { color: colors.mutedForeground, marginTop: 28 }]}>ПРАВОВОЕ</Text>
      <View style={[styles.group, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
        <TouchableOpacity
          style={[styles.row, { borderBottomWidth: 0 }]}
          onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); router.push("/privacy"); }}
          activeOpacity={0.6}
        >
          <View style={styles.rowText}>
            <Text style={[styles.rowLabel, { color: colors.foreground }]}>Политика конфиденциальности</Text>
            <Text style={[styles.rowDesc, { color: colors.mutedForeground }]}>Как мы храним и защищаем твои данные</Text>
          </View>
          <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      <Text style={[styles.tagline, { color: colors.mutedForeground }]}>
        CloNote — твои задачи, твой порядок.{"\n"}
        © 2025 Sulaimon Qurbonov · MIT License
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.5, marginBottom: 28 },
  sectionLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.5, marginBottom: 8 },
  group: { borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth },
  profileRow: {
    flexDirection: "row", alignItems: "center", gap: 14,
    paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  avatarWrap: { width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  avatarImg: { width: 52, height: 52 },
  avatarEmoji: { fontSize: 24 },
  profileInfo: { flex: 1, gap: 4 },
  profileName: { fontSize: 16, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  profileEmail: { fontSize: 13, fontFamily: "Inter_400Regular" },
  providerBadge: { alignSelf: "flex-start", paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  providerBadgeText: { fontSize: 12, fontFamily: "Inter_500Medium", fontWeight: "500" },
  row: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  rowText: { flex: 1, gap: 2, marginRight: 8 },
  rowLabel: { fontSize: 15, fontFamily: "Inter_400Regular" },
  rowDesc: { fontSize: 12, fontFamily: "Inter_400Regular" },
  tagline: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", marginTop: 32, lineHeight: 20 },
  verBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  verBadgeText: { fontSize: 12, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
