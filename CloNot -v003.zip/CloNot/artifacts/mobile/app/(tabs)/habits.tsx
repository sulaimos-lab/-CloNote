import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import HabitRow from "@/components/HabitRow";
import { useTasks } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const COLORS = ["#37352F", "#2383E2", "#0F7B6C", "#9065B0", "#D44C47", "#E07B39", "#CB912F"];

export default function HabitsScreen() {
  const { colors } = useTheme();
  const { habits, addHabit, toggleHabitDay, deleteHabit } = useTasks();
  const insets = useSafeAreaInsets();
  const [modalVisible, setModalVisible] = useState(false);
  const [title, setTitle] = useState("");
  const [selectedColor, setSelectedColor] = useState(COLORS[0]);

  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 96 : insets.bottom + 72;

  const handleAdd = () => {
    if (!title.trim()) { Alert.alert("Введите название привычки"); return; }
    addHabit({ title: title.trim(), color: selectedColor });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setTitle("");
    setSelectedColor(COLORS[0]);
    setModalVisible(false);
  };

  const weekDone = habits.reduce((acc, h) => {
    const today = new Date();
    const dow = today.getDay();
    const diff = dow === 0 ? -6 : 1 - dow;
    const monday = new Date(today);
    monday.setDate(today.getDate() + diff);
    const weekDates = Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return d.toDateString();
    });
    return acc + weekDates.filter(d => h.completedDays.includes(d)).length;
  }, 0);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingTop: topInset + 20, paddingBottom: bottomPadding },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>Привычки</Text>
          <TouchableOpacity
            onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setModalVisible(true); }}
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
            activeOpacity={0.8}
          >
            <Feather name="plus" size={16} color="#fff" />
            <Text style={styles.addBtnText}>Привычка</Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.statRow, { borderBottomColor: colors.border }]}>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>Отмечено на этой неделе</Text>
          <Text style={[styles.statNum, { color: colors.foreground }]}>{weekDone}</Text>
        </View>

        {habits.length === 0 ? (
          <View style={styles.empty}>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Нет привычек</Text>
            <TouchableOpacity onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setModalVisible(true); }} activeOpacity={0.7}>
              <Text style={[styles.emptyAction, { color: colors.primary }]}>+ Добавить привычку</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[styles.listBox, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
            {habits.map((h, idx) => (
              <HabitRow
                key={h.id}
                habit={h}
                onToggleDay={toggleHabitDay}
                onDelete={deleteHabit}
                isLast={idx === habits.length - 1}
              />
            ))}
          </View>
        )}
      </ScrollView>

      <Modal visible={modalVisible} animationType="slide" transparent presentationStyle="overFullScreen">
        <View style={styles.overlay}>
          <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>Новая привычка</Text>

            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="Название привычки"
              placeholderTextColor={colors.mutedForeground}
              style={[styles.input, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.surface }]}
              autoFocus
            />

            <Text style={[styles.colorSectionLabel, { color: colors.mutedForeground }]}>ЦВЕТ</Text>
            <View style={styles.colorRow}>
              {COLORS.map(c => (
                <TouchableOpacity
                  key={c}
                  style={[styles.colorDot, { backgroundColor: c }, selectedColor === c && [styles.colorSelected, { borderColor: c }]]}
                  onPress={() => { Haptics.selectionAsync(); setSelectedColor(c); }}
                />
              ))}
            </View>

            <View style={styles.sheetActions}>
              <TouchableOpacity
                style={[styles.cancelBtn, { borderColor: colors.border }]}
                onPress={() => setModalVisible(false)}
              >
                <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.saveBtn, { backgroundColor: colors.foreground }]}
                onPress={handleAdd}
              >
                <Text style={[styles.saveBtnText, { color: colors.background }]}>Добавить</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.5 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 6 },
  addBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  statRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingBottom: 14, marginBottom: 8, borderBottomWidth: StyleSheet.hairlineWidth },
  statLabel: { fontSize: 13, fontFamily: "Inter_400Regular" },
  statNum: { fontSize: 22, fontFamily: "Inter_700Bold", fontWeight: "700" },
  listBox: { borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth },
  empty: { paddingTop: 48, alignItems: "center", gap: 14 },
  emptyText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  emptyAction: { fontSize: 15, fontFamily: "Inter_500Medium", fontWeight: "500" },
  overlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.3)" },
  sheet: { borderTopLeftRadius: 12, borderTopRightRadius: 12, borderTopWidth: StyleSheet.hairlineWidth, padding: 24, paddingBottom: 40, gap: 16 },
  handle: { width: 36, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 4 },
  sheetTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  input: { borderWidth: 1, borderRadius: 8, padding: 12, fontSize: 15, fontFamily: "Inter_400Regular" },
  colorSectionLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.5 },
  colorRow: { flexDirection: "row", gap: 10, flexWrap: "wrap" },
  colorDot: { width: 30, height: 30, borderRadius: 15 },
  colorSelected: { borderWidth: 3, transform: [{ scale: 1.15 }] },
  sheetActions: { flexDirection: "row", gap: 10, marginTop: 4 },
  cancelBtn: { flex: 1, borderWidth: 1, borderRadius: 8, padding: 13, alignItems: "center" },
  cancelText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  saveBtn: { flex: 1, borderRadius: 8, padding: 13, alignItems: "center" },
  saveBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
