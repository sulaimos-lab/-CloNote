import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useMemo, useRef, useState } from "react";
import { ActivityIndicator, PanResponder, Platform, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { DaySchedule, useWorkSchedule } from "@/context/WorkScheduleContext";
import { useTheme } from "@/context/ThemeContext";
import { blendWithWhite, dateKey, earnedForDay, formatMoney, monthDays, monthTitle, parseDateKey, WEEKDAYS_RU, weekDays } from "@/utils/workSchedule";

type CalendarMode = "month" | "week";

export default function ScheduleScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { templates, days, payments, isLoading } = useWorkSchedule();
  const [selectedDate, setSelectedDate] = useState(() => new Date());
  const [mode, setMode] = useState<CalendarMode>("month");
  const selectedKey = dateKey(selectedDate);
  const currentMonthDays = useMemo(() => monthDays(selectedDate), [selectedDate]);
  const selectedWeek = useMemo(() => weekDays(selectedDate), [selectedDate]);
  const visibleDays = mode === "month" ? currentMonthDays : weekDays(selectedDate);
  const selectedSchedule = days.find(day => day.date === selectedKey);
  const selectedTemplate = templates.find(item => item.id === selectedSchedule?.templateId);
  const selectedPayments = payments.filter(payment => payment.date === selectedKey);
  const monthPrefix = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, "0")}`;
  const thisMonthShifts = days.filter(day => day.date.startsWith(monthPrefix) && day.templateId);
  const monthEarned = thisMonthShifts.reduce((total, day) => total + earnedForDay(day, templates.find(template => template.id === day.templateId)), 0);
  const selectedWeekKeys = new Set(selectedWeek.map(dateKey));
  const weekEarned = days
    .filter(day => selectedWeekKeys.has(day.date) && day.templateId)
    .reduce((total, day) => total + earnedForDay(day, templates.find(template => template.id === day.templateId)), 0);
  const maxPayment = Math.max(1, ...payments.filter(payment => payment.date.startsWith(monthPrefix)).map(payment => payment.amount));
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 96 : insets.bottom + 72;

  const movePeriod = (direction: number) => {
    setSelectedDate(current => {
      const next = new Date(current);
      if (mode === "month") {
        const day = current.getDate();
        next.setDate(1);
        next.setMonth(current.getMonth() + direction);
        const lastDay = new Date(next.getFullYear(), next.getMonth() + 1, 0).getDate();
        next.setDate(Math.min(day, lastDay));
      } else {
        next.setDate(current.getDate() + direction * 7);
      }
      return next;
    });
  };
  const movePeriodRef = useRef(movePeriod);
  movePeriodRef.current = movePeriod;
  const panResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => false,
    onMoveShouldSetPanResponder: (_event, gesture) => Math.abs(gesture.dx) > 32 && Math.abs(gesture.dx) > Math.abs(gesture.dy) * 1.3,
    onPanResponderRelease: (_event, gesture) => {
      if (Math.abs(gesture.dx) > 50) movePeriodRef.current(gesture.dx < 0 ? 1 : -1);
    },
  }), []);

  const openEditor = () => router.push(`/shift-editor?date=${selectedKey}`);
  const daysForSelectedMonth = useMemo(() => {
    const count = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();
    return Array.from({ length: count }, (_, index) => {
      const value = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), index + 1);
      return days.find(day => day.date === dateKey(value));
    }).filter((day): day is DaySchedule => !!day?.templateId);
  }, [days, selectedDate]);
  const offCount = useMemo(() => {
    const count = new Date(selectedDate.getFullYear(), selectedDate.getMonth() + 1, 0).getDate();
    return Array.from({ length: count }, (_, index) => {
      const date = new Date(selectedDate.getFullYear(), selectedDate.getMonth(), index + 1);
      const day = days.find(item => item.date === dateKey(date));
      return !!day?.isDayOff || ((date.getDay() === 0 || date.getDay() === 6) && !day?.templateId);
    }).filter(Boolean).length;
  }, [days, selectedDate]);

  if (isLoading) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: topInset + 18, paddingBottom: bottomPadding }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.title, { color: colors.foreground }]}>Календарь смен</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>План работы и заработка</Text>
          </View>
          <TouchableOpacity onPress={() => router.push("/finance")} style={[styles.headerIcon, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityLabel="Финансы">
            <Feather name="credit-card" size={18} color={colors.foreground} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => router.push("/templates")} style={[styles.headerIcon, { backgroundColor: colors.surface, borderColor: colors.border }]} accessibilityLabel="Шаблоны смен">
            <Feather name="layers" size={18} color={colors.foreground} />
          </TouchableOpacity>
        </View>

        <View style={[styles.monthHeader, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <TouchableOpacity onPress={() => movePeriod(-1)} style={styles.arrow} accessibilityLabel="Предыдущий период">
            <Feather name="chevron-left" size={21} color={colors.foreground} />
          </TouchableOpacity>
          <Text style={[styles.monthTitle, { color: colors.foreground }]}>{monthTitle(selectedDate)}</Text>
          <TouchableOpacity onPress={() => movePeriod(1)} style={styles.arrow} accessibilityLabel="Следующий период">
            <Feather name="chevron-right" size={21} color={colors.foreground} />
          </TouchableOpacity>
          <View style={[styles.modeSwitch, { backgroundColor: colors.surface }]}>
            {(["month", "week"] as const).map(value => (
              <TouchableOpacity key={value} onPress={() => setMode(value)} style={[styles.modeButton, mode === value && { backgroundColor: colors.foreground }]}>
                <Text style={[styles.modeText, { color: mode === value ? colors.background : colors.mutedForeground }]}>{value === "month" ? "Месяц" : "Неделя"}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View {...panResponder.panHandlers} style={[styles.calendar, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.weekdayRow}>
            {WEEKDAYS_RU.map((day, index) => (
              <Text key={day} style={[styles.weekday, { color: index > 4 ? colors.primary : colors.mutedForeground }]}>{day}</Text>
            ))}
          </View>
          <View style={styles.dayGrid}>
            {visibleDays.map(date => {
              const key = dateKey(date);
              const entry = days.find(day => day.date === key);
              const template = templates.find(item => item.id === entry?.templateId);
              const dayPayments = payments.filter(payment => payment.date === key);
              const isSelected = key === selectedKey;
              const inMonth = date.getMonth() === selectedDate.getMonth();
              const isWeekend = date.getDay() === 0 || date.getDay() === 6;
              const paymentMax = Math.max(1, ...dayPayments.map(item => item.amount));
              const dots: { color: string; opacity: number }[] = [];
              if (entry?.isDayOff) dots.push({ color: entry.offColor ?? "#CB912F", opacity: 1 });
              else if (template) dots.push({ color: entry?.colorOverride ?? template.color, opacity: 1 });
              if (entry?.note) dots.push({ color: entry.noteColor ?? "#E07B39", opacity: 1 });
              dayPayments.slice(0, 2).forEach(payment => dots.push({
                color: blendWithWhite(payment.color, 0.45 + (payment.amount / maxPayment) * 0.55),
                opacity: 1,
              }));
              return (
                <TouchableOpacity key={key} onPress={() => setSelectedDate(date)} style={[styles.dayCell, isSelected && { backgroundColor: colors.foreground }]}>
                  <Text style={[styles.dayNumber, { color: isSelected ? colors.background : !inMonth ? colors.mutedForeground : isWeekend ? colors.primary : colors.foreground, opacity: inMonth ? 1 : 0.4 }]}>{date.getDate()}</Text>
                  <View style={styles.dots}>
                    {dots.slice(0, 4).map((dot, index) => <View key={`${key}-${index}`} style={[styles.dot, { backgroundColor: isSelected ? colors.background : dot.color, opacity: dot.opacity }]} />)}
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
          <Text style={[styles.swipeHint, { color: colors.mutedForeground }]}>Листайте календарь влево или вправо</Text>
        </View>

        <View style={styles.quickLinks}>
          <QuickLink icon="bar-chart-2" label="Статистика" onPress={() => router.push("/statistics")} colors={colors} />
          <QuickLink icon="layers" label="Шаблоны" onPress={() => router.push("/templates")} colors={colors} />
          <QuickLink icon="credit-card" label="Финансы" onPress={() => router.push("/finance")} colors={colors} />
        </View>

        <View style={[styles.summaryCard, { backgroundColor: colors.foreground }]}>
          <View style={styles.summaryTop}>
            <View>
              <Text style={[styles.summaryLabel, { color: colors.background, opacity: 0.68 }]}>ЗАПЛАНИРОВАНО В {monthTitle(selectedDate).toLocaleUpperCase("ru-RU")}</Text>
              <Text style={[styles.summaryValue, { color: colors.background }]}>{isLoading ? "…" : formatMoney(monthEarned)}</Text>
            </View>
            <Feather name="trending-up" size={22} color={colors.background} />
          </View>
          <View style={[styles.summaryDivider, { backgroundColor: colors.background, opacity: 0.18 }]} />
          <View style={styles.summaryStats}>
            <View><Text style={[styles.summaryStatValue, { color: colors.background }]}>{daysForSelectedMonth.length}</Text><Text style={[styles.summaryStatLabel, { color: colors.background, opacity: 0.68 }]}>смен</Text></View>
            <View><Text style={[styles.summaryStatValue, { color: colors.background }]}>{offCount}</Text><Text style={[styles.summaryStatLabel, { color: colors.background, opacity: 0.68 }]}>выходных</Text></View>
            <TouchableOpacity onPress={() => router.push("/statistics")} style={[styles.detailsButton, { borderColor: colors.background }]}>
              <Text style={[styles.detailsText, { color: colors.background }]}>Подробнее</Text>
              <Feather name="arrow-up-right" size={13} color={colors.background} />
            </TouchableOpacity>
          </View>
        </View>
        <View style={[styles.weekSummary, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.weekIcon, { backgroundColor: colors.successLight }]}>
            <Feather name="calendar" size={15} color={colors.success} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.weekLabel, { color: colors.mutedForeground }]}>ЗАРАБОТАНО ЗА НЕДЕЛЮ</Text>
            <Text style={[styles.weekDates, { color: colors.mutedForeground }]}>
              {selectedWeek[0].toLocaleDateString("ru-RU", { day: "numeric", month: "short" })} — {selectedWeek[6].toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}
            </Text>
          </View>
          <Text style={[styles.weekValue, { color: colors.foreground }]}>{formatMoney(weekEarned)}</Text>
        </View>

        <View style={styles.dayHeader}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.dayHeading, { color: colors.foreground }]}>{parseDateKey(selectedKey).toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" })}</Text>
            <Text style={[styles.daySubtitle, { color: colors.mutedForeground }]}>План на выбранный день</Text>
          </View>
          <TouchableOpacity onPress={openEditor} style={[styles.addDayButton, { backgroundColor: colors.primary }]}>
            <Feather name="edit-2" size={15} color="#fff" />
            <Text style={styles.addDayText}>{selectedSchedule ? "Изменить" : "Добавить"}</Text>
          </TouchableOpacity>
        </View>

        {selectedSchedule || selectedPayments.length > 0 ? (
          <View style={[styles.eventCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {selectedSchedule?.isDayOff && (
              <View style={styles.eventRow}>
                <View style={[styles.eventMark, { backgroundColor: selectedSchedule.offColor ?? "#CB912F" }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.eventTitle, { color: colors.foreground }]}>Выходной</Text>
                  <Text style={[styles.eventMeta, { color: colors.mutedForeground }]}>День отмечен как выходной</Text>
                </View>
              </View>
            )}
            {selectedTemplate && !selectedSchedule?.isDayOff && (
              <View style={styles.eventRow}>
                <View style={[styles.eventMark, { backgroundColor: selectedSchedule?.colorOverride ?? selectedTemplate.color }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.eventTitle, { color: colors.foreground }]}>{selectedTemplate.name}</Text>
                  <Text style={[styles.eventMeta, { color: colors.mutedForeground }]}>{selectedTemplate.startTime} — {selectedTemplate.endTime} · {selectedTemplate.payType === "hourly" ? `${formatMoney(selectedSchedule?.rateOverride ?? selectedTemplate.rate)} / час` : formatMoney(selectedSchedule?.rateOverride ?? selectedTemplate.rate)}</Text>
                </View>
                <Text style={[styles.eventAmount, { color: colors.foreground }]}>{formatMoney(earnedForDay(selectedSchedule!, selectedTemplate))}</Text>
              </View>
            )}
            {selectedSchedule?.note && (
              <View style={styles.eventRow}>
                <View style={[styles.eventMark, { backgroundColor: selectedSchedule.noteColor ?? "#E07B39" }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.eventTitle, { color: colors.foreground }]}>Заметка</Text>
                  <Text style={[styles.eventMeta, { color: colors.mutedForeground }]}>{selectedSchedule.note}</Text>
                </View>
              </View>
            )}
            {selectedPayments.map(payment => (
              <View key={payment.id} style={styles.eventRow}>
                <View style={[styles.eventMark, { backgroundColor: payment.color }]} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.eventTitle, { color: colors.foreground }]}>{payment.type === "advance" ? "Аванс" : "Зарплата"}</Text>
                  {payment.note ? <Text style={[styles.eventMeta, { color: colors.mutedForeground }]}>{payment.note}</Text> : null}
                </View>
                <Text style={[styles.eventAmount, { color: colors.foreground }]}>{formatMoney(payment.amount)}</Text>
              </View>
            ))}
          </View>
        ) : (
          <TouchableOpacity onPress={openEditor} style={[styles.emptyDay, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="plus" size={17} color={colors.primary} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Добавьте смену, выходной или заметку</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

function QuickLink({ icon, label, onPress, colors }: { icon: React.ComponentProps<typeof Feather>["name"]; label: string; onPress: () => void; colors: ReturnType<typeof useTheme>["colors"] }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.quickLink, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Feather name={icon} size={16} color={colors.primary} />
      <Text style={[styles.quickLinkText, { color: colors.foreground }]}>{label}</Text>
      <Feather name="chevron-right" size={14} color={colors.mutedForeground} />
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 18, gap: 12 },
  header: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 },
  title: { fontSize: 25, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.4 },
  subtitle: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 3 },
  headerIcon: { width: 38, height: 38, borderWidth: 1, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  monthHeader: { flexDirection: "row", alignItems: "center", borderWidth: 1, borderRadius: 14, padding: 7, gap: 4 },
  arrow: { width: 30, height: 34, alignItems: "center", justifyContent: "center" },
  monthTitle: { flex: 1, fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600", textAlign: "center" },
  modeSwitch: { flexDirection: "row", padding: 3, borderRadius: 9 },
  modeButton: { paddingHorizontal: 9, paddingVertical: 7, borderRadius: 7 },
  modeText: { fontSize: 11, fontFamily: "Inter_500Medium", fontWeight: "500" },
  calendar: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 7, paddingTop: 10, paddingBottom: 8 },
  weekdayRow: { flexDirection: "row", marginBottom: 3 },
  weekday: { flex: 1, textAlign: "center", fontSize: 10, paddingVertical: 6, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  dayGrid: { flexDirection: "row", flexWrap: "wrap" },
  dayCell: { width: "14.2857%", height: 46, alignItems: "center", justifyContent: "center", borderRadius: 10, gap: 4 },
  dayNumber: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  dots: { flexDirection: "row", height: 5, gap: 3, alignItems: "center" },
  dot: { width: 5, height: 5, borderRadius: 3 },
  swipeHint: { textAlign: "center", fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 4 },
  quickLinks: { gap: 7 },
  quickLink: { minHeight: 42, borderWidth: 1, borderRadius: 11, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 9 },
  quickLinkText: { flex: 1, fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },
  summaryCard: { borderRadius: 16, padding: 16, marginTop: 1 },
  summaryTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  summaryLabel: { fontSize: 9, letterSpacing: 0.6, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  summaryValue: { fontSize: 26, fontFamily: "Inter_700Bold", fontWeight: "700", marginTop: 4 },
  summaryDivider: { height: 1, marginVertical: 12 },
  summaryStats: { flexDirection: "row", alignItems: "center", gap: 22 },
  summaryStatValue: { fontSize: 16, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  summaryStatLabel: { fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 2 },
  weekSummary: { flexDirection: "row", alignItems: "center", gap: 10, borderWidth: 1, borderRadius: 13, padding: 12 },
  weekIcon: { width: 32, height: 32, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  weekLabel: { fontSize: 9, letterSpacing: 0.45, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  weekDates: { fontSize: 10, fontFamily: "Inter_400Regular", marginTop: 3, textTransform: "capitalize" },
  weekValue: { fontSize: 15, fontFamily: "Inter_700Bold", fontWeight: "700" },
  detailsButton: { marginLeft: "auto", flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 8, paddingHorizontal: 9, paddingVertical: 7 },
  detailsText: { fontSize: 11, fontFamily: "Inter_500Medium", fontWeight: "500" },
  dayHeader: { flexDirection: "row", alignItems: "center", gap: 10, marginTop: 5 },
  dayHeading: { fontSize: 16, fontFamily: "Inter_600SemiBold", fontWeight: "600", textTransform: "capitalize" },
  daySubtitle: { fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 2 },
  addDayButton: { flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 9, paddingHorizontal: 11, paddingVertical: 9 },
  addDayText: { color: "#fff", fontSize: 12, fontFamily: "Inter_500Medium", fontWeight: "500" },
  eventCard: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 13 },
  eventRow: { flexDirection: "row", alignItems: "center", gap: 11, minHeight: 58, paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "rgba(120,120,120,0.18)" },
  eventMark: { width: 8, height: 34, borderRadius: 5 },
  eventTitle: { fontSize: 13, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  eventMeta: { fontSize: 11, lineHeight: 16, marginTop: 3, fontFamily: "Inter_400Regular" },
  eventAmount: { fontSize: 12, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  emptyDay: { minHeight: 58, borderRadius: 12, borderWidth: 1, borderStyle: "dashed", flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  emptyText: { fontSize: 12, fontFamily: "Inter_400Regular" },
});
