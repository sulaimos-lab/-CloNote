/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * (tabs)/index.tsx
 * Главный экран приложения — список задач.
 * Поддерживает: фильтрацию по категориям, сортировку,
 * свайп для удаления, подзадачи, поиск и анимации.
 * Тариф: бесплатный — без ограничений и рекламы.
 */
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Alert,
  Animated,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Confetti from "@/components/Confetti";
import ProgressBar from "@/components/ProgressBar";
import TaskTree from "@/components/TaskTree";
import { CategoryDef, Priority, Task, useTasks } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const EMOJI_SUGGESTIONS = [
  "💼","🏠","🌱","❤️","🛒","📚","🎯","💡","🔧","🎨","🏋️","✈️",
  "💰","📝","🎵","🌍","🤝","🧠","⭐","🔥","💻","📱","🏆","🎉",
];

type SortKey = "default" | "priority" | "date" | "alpha";

const SORT_OPTIONS: { key: SortKey; label: string; icon: string }[] = [
  { key: "default",  label: "По умолчанию", icon: "list"      },
  { key: "priority", label: "По приоритету", icon: "alert-circle" },
  { key: "date",     label: "По дате",       icon: "calendar"  },
  { key: "alpha",    label: "По алфавиту",   icon: "type"      },
];

const PRIORITY_ORDER: Record<Priority, number> = { high: 0, normal: 1, low: 2 };

function sortTasks(tasks: Task[], key: SortKey): Task[] {
  const arr = [...tasks];
  switch (key) {
    case "priority":
      return arr.sort((a, b) => {
        const pa = PRIORITY_ORDER[a.priority ?? "normal"];
        const pb = PRIORITY_ORDER[b.priority ?? "normal"];
        if (pa !== pb) return pa - pb;
        return a.title.localeCompare(b.title, "ru");
      });
    case "date":
      return arr.sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return 0;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      });
    case "alpha":
      return arr.sort((a, b) => a.title.localeCompare(b.title, "ru"));
    default:
      return arr;
  }
}

interface CatModalState {
  visible: boolean;
  mode: "add" | "edit";
  id?: string;
  name: string;
  emoji: string;
}

export default function TasksScreen() {
  const { colors } = useTheme();
  const { getRootTasks, categories, addCategory, updateCategory, deleteCategory, todayCompleted, todayTotal } = useTasks();
  const insets = useSafeAreaInsets();

  const [activeTab,    setActiveTab]    = useState<string>("all");
  const [searchOpen,   setSearchOpen]   = useState(false);
  const [searchQuery,  setSearchQuery]  = useState("");
  const [sortKey,      setSortKey]      = useState<SortKey>("default");
  const [sortOpen,     setSortOpen]     = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [modal,        setModal]        = useState<CatModalState>({ visible: false, mode: "add", name: "", emoji: "📁" });

  const searchAnim = useRef(new Animated.Value(0)).current;
  const sortAnim   = useRef(new Animated.Value(0)).current;
  const celebAnim  = useRef(new Animated.Value(0)).current;
  const prevCompleted = useRef(todayCompleted);

  useEffect(() => {
    Animated.spring(searchAnim, { toValue: searchOpen ? 1 : 0, friction: 8, tension: 100, useNativeDriver: false }).start();
    if (!searchOpen) setSearchQuery("");
  }, [searchOpen, searchAnim]);

  useEffect(() => {
    Animated.spring(sortAnim, { toValue: sortOpen ? 1 : 0, friction: 8, tension: 100, useNativeDriver: false }).start();
  }, [sortOpen, sortAnim]);

  useEffect(() => {
    const justFinished = todayTotal > 0 && todayCompleted === todayTotal && prevCompleted.current < todayTotal;
    if (justFinished) {
      setShowConfetti(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Animated.sequence([
        Animated.spring(celebAnim, { toValue: 1, friction: 6, tension: 80, useNativeDriver: true }),
        Animated.delay(2800),
        Animated.timing(celebAnim, { toValue: 0, duration: 400, useNativeDriver: true }),
      ]).start(() => setShowConfetti(false));
    }
    prevCompleted.current = todayCompleted;
  }, [todayCompleted, todayTotal, celebAnim]);

  const rootTasks = getRootTasks();
  const filtered = sortTasks(
    rootTasks
      .filter(t => activeTab === "all" || t.category === activeTab)
      .filter(t => !searchQuery || t.title.toLowerCase().includes(searchQuery.toLowerCase())),
    sortKey,
  );

  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 96 : insets.bottom + 72;

  const openAdd = () => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setModal({ visible: true, mode: "add", name: "", emoji: "📁" }); };
  const openEdit = (cat: CategoryDef) => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); setModal({ visible: true, mode: "edit", id: cat.id, name: cat.name, emoji: cat.emoji }); };

  const handleSaveModal = () => {
    if (!modal.name.trim()) { Alert.alert("Введите название"); return; }
    if (modal.mode === "add") addCategory(modal.name.trim(), modal.emoji);
    else if (modal.id) updateCategory(modal.id, modal.name.trim(), modal.emoji);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setModal(m => ({ ...m, visible: false }));
  };

  const handleDeleteCat = () => {
    if (!modal.id) return;
    Alert.alert("Удалить категорию?", "Задачи останутся, но потеряют категорию.", [
      { text: "Отмена", style: "cancel" },
      { text: "Удалить", style: "destructive", onPress: () => {
        deleteCategory(modal.id!);
        if (activeTab === modal.id) setActiveTab("all");
        setModal(m => ({ ...m, visible: false }));
      }},
    ]);
  };

  const handleSelectSort = (key: SortKey) => {
    Haptics.selectionAsync();
    setSortKey(key);
    setSortOpen(false);
  };

  const searchBarHeight = searchAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 46] });
  const sortPanelHeight = sortAnim.interpolate({ inputRange: [0, 1], outputRange: [0, SORT_OPTIONS.length * 44 + 8] });

  const activeCatDef = categories.find(c => c.id === activeTab);
  const sectionLabel = activeTab === "all" ? "Все задачи" : (activeCatDef?.name ?? "");
  const activeSortLabel = SORT_OPTIONS.find(o => o.key === sortKey)?.label ?? "";
  const celebTranslate  = celebAnim.interpolate({ inputRange: [0, 1], outputRange: [-80, 0] });

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[styles.content, { paddingTop: topInset + 20, paddingBottom: bottomPadding }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.appName, { color: colors.foreground }]}>CloNote</Text>
          <View style={styles.headerRight}>
            <TouchableOpacity
              onPress={() => { Haptics.selectionAsync(); setSortOpen(v => !v); if (searchOpen) setSearchOpen(false); }}
              style={[styles.iconBtn, { borderColor: colors.border }, sortKey !== "default" && { backgroundColor: colors.foreground }]}
              activeOpacity={0.7}
            >
              <Feather name="sliders" size={16} color={sortKey !== "default" ? colors.background : colors.foreground} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { Haptics.selectionAsync(); setSearchOpen(v => !v); if (sortOpen) setSortOpen(false); }}
              style={[styles.iconBtn, { borderColor: colors.border }, searchOpen && { backgroundColor: colors.foreground }]}
              activeOpacity={0.7}
            >
              <Feather name={searchOpen ? "x" : "search"} size={16} color={searchOpen ? colors.background : colors.foreground} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); router.push("/archive"); }}
              style={[styles.iconBtn, { borderColor: colors.border }]}
              activeOpacity={0.7}
            >
              <Feather name="trash-2" size={16} color={colors.mutedForeground} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); router.push("/add-task"); }}
              style={[styles.addBtn, { backgroundColor: colors.primary }]}
              activeOpacity={0.8}
            >
              <Feather name="plus" size={16} color="#fff" />
              <Text style={styles.addBtnText}>Задача</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Progress stats — right under header */}
        <ProgressBar completed={todayCompleted} total={todayTotal} />

        {/* Search bar */}
        <Animated.View style={{ height: searchBarHeight, opacity: searchAnim, overflow: "hidden", marginBottom: searchOpen ? 10 : 0 }}>
          <View style={[styles.searchBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Feather name="search" size={15} color={colors.mutedForeground} />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder="Поиск задач..."
              placeholderTextColor={colors.mutedForeground}
              style={[styles.searchInput, { color: colors.foreground }]}
              autoFocus={searchOpen}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery("")}>
                <Feather name="x-circle" size={14} color={colors.mutedForeground} />
              </TouchableOpacity>
            )}
          </View>
        </Animated.View>

        {/* Sort panel */}
        <Animated.View style={{ height: sortPanelHeight, overflow: "hidden", marginBottom: sortOpen ? 10 : 0 }}>
          <View style={[styles.sortPanel, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            {SORT_OPTIONS.map((opt, idx) => {
              const isActive = sortKey === opt.key;
              return (
                <TouchableOpacity
                  key={opt.key}
                  onPress={() => handleSelectSort(opt.key)}
                  style={[
                    styles.sortRow,
                    { borderBottomColor: colors.border },
                    idx === SORT_OPTIONS.length - 1 && { borderBottomWidth: 0 },
                  ]}
                  activeOpacity={0.7}
                >
                  <Feather name={opt.icon as any} size={15} color={isActive ? colors.foreground : colors.mutedForeground} />
                  <Text style={[styles.sortLabel, { color: isActive ? colors.foreground : colors.mutedForeground, fontFamily: isActive ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
                    {opt.label}
                  </Text>
                  {isActive && <Feather name="check" size={14} color={colors.foreground} style={{ marginLeft: "auto" }} />}
                </TouchableOpacity>
              );
            })}
          </View>
        </Animated.View>

        {/* Category tabs */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsScroll} contentContainerStyle={styles.tabsRow}>
          <TouchableOpacity
            onPress={() => { Haptics.selectionAsync(); setActiveTab("all"); }}
            style={[styles.tab, { borderColor: activeTab === "all" ? colors.foreground : colors.border }, activeTab === "all" && { backgroundColor: colors.foreground }]}
            activeOpacity={0.7}
          >
            <Text style={[styles.tabLabel, { color: activeTab === "all" ? colors.background : colors.mutedForeground }]}>Все</Text>
          </TouchableOpacity>

          {categories.map(cat => (
            <TouchableOpacity
              key={cat.id}
              onPress={() => { Haptics.selectionAsync(); setActiveTab(cat.id); }}
              onLongPress={() => openEdit(cat)}
              delayLongPress={400}
              style={[styles.tab, { borderColor: activeTab === cat.id ? colors.foreground : colors.border }, activeTab === cat.id && { backgroundColor: colors.foreground }]}
              activeOpacity={0.7}
            >
              <Text style={[styles.tabLabel, { color: activeTab === cat.id ? colors.background : colors.mutedForeground }]}>
                {cat.emoji} {cat.name}
              </Text>
            </TouchableOpacity>
          ))}

          <TouchableOpacity onPress={openAdd} style={[styles.tab, styles.addCatTab, { borderColor: colors.border }]} activeOpacity={0.7}>
            <Feather name="plus" size={13} color={colors.mutedForeground} />
          </TouchableOpacity>
        </ScrollView>

        <Text style={[styles.hint, { color: colors.mutedForeground }]}>Удерживай вкладку, чтобы изменить</Text>

        {/* Section + sort label */}
        <View style={styles.sectionRow}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>
            {searchQuery ? `«${searchQuery}»` : sectionLabel.toUpperCase()}
          </Text>
          {sortKey !== "default" && (
            <Text style={[styles.sortBadge, { color: colors.mutedForeground, borderColor: colors.border }]}>
              ↕ {activeSortLabel}
            </Text>
          )}
        </View>

        {/* Task list */}
        {filtered.length === 0 ? (
          <View style={styles.empty}>
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
              {searchQuery ? "Ничего не найдено" : "Задач нет"}
            </Text>
            {!searchQuery && (
              <TouchableOpacity onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); router.push("/add-task"); }} activeOpacity={0.7}>
                <Text style={[styles.emptyAction, { color: colors.primary }]}>+ Добавить задачу</Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          <View style={[styles.listContainer, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
            <TaskTree tasks={filtered} categories={categories} />
          </View>
        )}
      </ScrollView>

      {/* Celebration banner */}
      {showConfetti && (
        <Animated.View
          style={[styles.celebBanner, { backgroundColor: colors.foreground, transform: [{ translateY: celebTranslate }], opacity: celebAnim }]}
          pointerEvents="none"
        >
          <Text style={[styles.celebText, { color: colors.background }]}>🎉 Все задачи выполнены!</Text>
        </Animated.View>
      )}
      <Confetti visible={showConfetti} />

      {/* Category editor modal */}
      <Modal visible={modal.visible} animationType="slide" transparent presentationStyle="overFullScreen">
        <View style={styles.overlay}>
          <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>
              {modal.mode === "add" ? "Новая категория" : "Изменить категорию"}
            </Text>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>ЭМОДЗИ</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.emojiScroll} contentContainerStyle={styles.emojiRow}>
              {EMOJI_SUGGESTIONS.map(e => (
                <TouchableOpacity
                  key={e}
                  onPress={() => { Haptics.selectionAsync(); setModal(m => ({ ...m, emoji: e })); }}
                  style={[styles.emojiBtn, { borderColor: modal.emoji === e ? colors.foreground : colors.border }, modal.emoji === e && { backgroundColor: colors.surface }]}
                >
                  <Text style={styles.emojiBtnText}>{e}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>НАЗВАНИЕ</Text>
            <View style={styles.nameRow}>
              <Text style={styles.selectedEmoji}>{modal.emoji}</Text>
              <TextInput
                value={modal.name}
                onChangeText={name => setModal(m => ({ ...m, name }))}
                placeholder="Название категории"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.nameInput, { borderColor: colors.border, color: colors.foreground, backgroundColor: colors.surface }]}
                autoFocus={modal.mode === "add"}
                maxLength={30}
              />
            </View>
            <View style={styles.sheetActions}>
              {modal.mode === "edit" && (
                <TouchableOpacity style={[styles.deleteBtn, { borderColor: "#E03E3E" }]} onPress={handleDeleteCat}>
                  <Feather name="trash-2" size={16} color="#E03E3E" />
                </TouchableOpacity>
              )}
              <TouchableOpacity style={[styles.cancelBtn, { borderColor: colors.border, flex: 1 }]} onPress={() => setModal(m => ({ ...m, visible: false }))}>
                <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.saveSheetBtn, { backgroundColor: colors.foreground, flex: 1 }]} onPress={handleSaveModal}>
                <Text style={[styles.saveSheetText, { color: colors.background }]}>Сохранить</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 20 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  appName: { fontSize: 26, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.5 },
  headerRight: { flexDirection: "row", alignItems: "center", gap: 6 },
  iconBtn: { width: 34, height: 34, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 6 },
  addBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  searchBar: { flexDirection: "row", alignItems: "center", gap: 8, paddingHorizontal: 12, borderWidth: 1, borderRadius: 8, height: 40 },
  searchInput: { flex: 1, fontSize: 14, fontFamily: "Inter_400Regular", padding: 0 },
  sortPanel: { borderWidth: 1, borderRadius: 10, overflow: "hidden" },
  sortRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 14, height: 44, borderBottomWidth: StyleSheet.hairlineWidth },
  sortLabel: { fontSize: 14 },
  tabsScroll: { marginBottom: 6, marginHorizontal: -20 },
  tabsRow: { paddingHorizontal: 20, gap: 6, flexDirection: "row", alignItems: "center" },
  tab: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 6, borderWidth: 1 },
  addCatTab: { width: 30, alignItems: "center", justifyContent: "center" },
  tabLabel: { fontSize: 13, fontFamily: "Inter_400Regular" },
  hint: { fontSize: 11, fontFamily: "Inter_400Regular", marginBottom: 14 },
  sectionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 4 },
  sectionLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.8, textTransform: "uppercase" },
  sortBadge: { fontSize: 11, fontFamily: "Inter_400Regular", borderWidth: 1, borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  listContainer: { borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth },
  empty: { paddingTop: 48, alignItems: "center", gap: 14 },
  emptyText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  emptyAction: { fontSize: 15, fontFamily: "Inter_500Medium", fontWeight: "500" },
  celebBanner: {
    position: "absolute", top: 0, left: 20, right: 20,
    borderRadius: 12, padding: 14, alignItems: "center", zIndex: 99,
    shadowColor: "#000", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.18, shadowRadius: 12, elevation: 8,
  },
  celebText: { fontSize: 17, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  overlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.3)" },
  sheet: { borderTopLeftRadius: 16, borderTopRightRadius: 16, borderTopWidth: StyleSheet.hairlineWidth, padding: 20, paddingBottom: 44, gap: 14 },
  handle: { width: 36, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 4 },
  sheetTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  fieldLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.6 },
  emojiScroll: { marginHorizontal: -4 },
  emojiRow: { flexDirection: "row", gap: 6, paddingHorizontal: 4 },
  emojiBtn: { width: 40, height: 40, borderRadius: 8, borderWidth: 1.5, alignItems: "center", justifyContent: "center" },
  emojiBtnText: { fontSize: 20 },
  nameRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  selectedEmoji: { fontSize: 26 },
  nameInput: { flex: 1, borderWidth: 1, borderRadius: 8, padding: 11, fontSize: 15, fontFamily: "Inter_400Regular" },
  sheetActions: { flexDirection: "row", gap: 8, marginTop: 4 },
  deleteBtn: { borderWidth: 1, borderRadius: 8, padding: 13, alignItems: "center", justifyContent: "center", width: 46 },
  cancelBtn: { borderWidth: 1, borderRadius: 8, padding: 13, alignItems: "center" },
  cancelText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  saveSheetBtn: { borderRadius: 8, padding: 13, alignItems: "center" },
  saveSheetText: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
