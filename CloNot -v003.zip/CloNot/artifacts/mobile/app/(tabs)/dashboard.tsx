/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * dashboard.tsx
 * Главный дашборд в стиле Obsidian.
 * Показывает: прогресс за сегодня, стрик, heatmap активности,
 * статистику по категориям и приоритетам, кнопки экспорта в MD/HTML.
 */
import { Feather } from "@expo/vector-icons";
import * as Sharing from "expo-sharing";
import * as FileSystem from "expo-file-system/legacy";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";
import { useTasks, PRIORITY_CONFIG } from "@/context/TaskContext";
import { exportMarkdown, exportHTML } from "@/utils/exportService";

function pad(n: number) { return String(n).padStart(2, "0"); }
function dayKey(d: Date) {
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}

const WEEK_RU = ["Пн","Вт","Ср","Чт","Пт","Сб","Вс"];

export default function DashboardScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 96 : insets.bottom + 72;
  const {
    tasks, categories, habits,
    todayCompleted, todayTotal,
  } = useTasks();

  const [exporting, setExporting] = useState(false);

  const active   = useMemo(() => tasks.filter(t => !t.archived), [tasks]);
  const done     = useMemo(() => active.filter(t => t.completed).length, [active]);
  const total    = active.length;
  const pct      = total ? Math.round((done / total) * 100) : 0;
  const overdue  = useMemo(() => {
    const today = dayKey(new Date());
    return active.filter(t => !t.completed && t.dueDate && t.dueDate < today).length;
  }, [active]);
  const high = useMemo(() => active.filter(t => !t.completed && t.priority === "high").length, [active]);

  /* Heatmap — last 35 days */
  const heatmap = useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of active) {
      const key = dayKey(new Date(t.createdAt));
      map[key] = (map[key] || 0) + 1;
      if (t.completed) map[key] = (map[key] || 0) + 0.5;
    }
    const cells: { key: string; count: number }[] = [];
    for (let i = 34; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - i);
      const k = dayKey(d);
      cells.push({ key: k, count: map[k] || 0 });
    }
    return cells;
  }, [active]);
  const maxHeat = Math.max(...heatmap.map(c => c.count), 1);

  /* Streak */
  const streak = useMemo(() => {
    let s = 0;
    const d = new Date();
    while (true) {
      const k = dayKey(d);
      const dayTasks = active.filter(t => dayKey(new Date(t.createdAt)) === k);
      if (!dayTasks.length) break;
      const anyDone = dayTasks.some(t => t.completed);
      if (!anyDone) break;
      s++;
      d.setDate(d.getDate() - 1);
    }
    return s;
  }, [active]);

  /* Per-category stats */
  const catStats = useMemo(() => categories.map(cat => {
    const all  = active.filter(t => t.category === cat.id);
    const done = all.filter(t => t.completed).length;
    return { ...cat, total: all.length, done };
  }).filter(c => c.total > 0), [active, categories]);

  /* Priority breakdown */
  const priStats = useMemo(() => (["high","normal","low"] as const).map(p => ({
    p,
    count: active.filter(t => !t.completed && t.priority === p).length,
    ...PRIORITY_CONFIG[p],
  })).filter(x => x.count > 0), [active]);

  /* Habits today */
  const today = dayKey(new Date());
  const habitsToday = habits.filter(h => h.completedDays.includes(today)).length;

  /* Export */
  const doExport = async (format: "md" | "html") => {
    if (Platform.OS === "web") {
      const text = format === "md"
        ? exportMarkdown(tasks, categories)
        : exportHTML(tasks, categories);
      const blob = new Blob([text], { type: format === "md" ? "text/markdown" : "text/html" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url; a.download = `clonote-tasks.${format}`; a.click();
      URL.revokeObjectURL(url);
      return;
    }
    setExporting(true);
    try {
      const text = format === "md"
        ? exportMarkdown(tasks, categories)
        : exportHTML(tasks, categories);
      const ext  = format === "md" ? "md" : "html";
      const path = `${FileSystem.documentDirectory}clonote-tasks.${ext}`;
      await FileSystem.writeAsStringAsync(path, text, { encoding: FileSystem.EncodingType.UTF8 });
      await Sharing.shareAsync(path, {
        mimeType: format === "md" ? "text/markdown" : "text/html",
        dialogTitle: "Экспорт задач CloNote",
      });
    } catch (e) {
      Alert.alert("Ошибка", "Не удалось экспортировать файл.");
    } finally {
      setExporting(false);
    }
  };

  const heatCell = (count: number) => {
    const ratio = count / maxHeat;
    if (ratio === 0) return colors.border;
    if (ratio < 0.33) return "#86efac";
    if (ratio < 0.66) return "#22c55e";
    return "#15803d";
  };

  return (
    <ScrollView
      style={[styles.root, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingTop: topInset + 20, paddingBottom: bottomPadding, paddingHorizontal: 20 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.headerRow}>
        <View>
          <Text style={[styles.title, { color: colors.foreground }]}>Дашборд</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {new Date().toLocaleDateString("ru-RU", { day:"numeric", month:"long" })}
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => router.push("/graph")}
          style={[styles.graphBtn, { backgroundColor: colors.surface, borderColor: colors.border }]}
          activeOpacity={0.7}
        >
          <Feather name="share-2" size={16} color={colors.foreground} />
          <Text style={[styles.graphBtnText, { color: colors.foreground }]}>Граф</Text>
        </TouchableOpacity>
      </View>

      {/* Today progress */}
      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.cardHeader}>
          <Text style={[styles.cardLabel, { color: colors.mutedForeground }]}>СЕГОДНЯ</Text>
          <Text style={[styles.pctBig, { color: colors.foreground }]}>{pct}%</Text>
        </View>
        <View style={[styles.barTrack, { backgroundColor: colors.border }]}>
          <View style={[styles.barFill, { width: `${pct}%`, backgroundColor: "#10B981" }]} />
        </View>
        <Text style={[styles.cardSub, { color: colors.mutedForeground }]}>
          {done} из {total} задач · {todayCompleted}/{todayTotal} за сегодня
        </Text>
      </View>

      {/* Stats row */}
      <View style={styles.statsRow}>
        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={styles.statEmoji}>🔥</Text>
          <Text style={[styles.statNum, { color: colors.foreground }]}>{streak}</Text>
          <Text style={[styles.statLab, { color: colors.mutedForeground }]}>стрик</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={styles.statEmoji}>⚡</Text>
          <Text style={[styles.statNum, { color: colors.foreground }]}>{high}</Text>
          <Text style={[styles.statLab, { color: colors.mutedForeground }]}>срочных</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={styles.statEmoji}>⏰</Text>
          <Text style={[styles.statNum, { color: overdue > 0 ? "#E03E3E" : colors.foreground }]}>{overdue}</Text>
          <Text style={[styles.statLab, { color: colors.mutedForeground }]}>просрочено</Text>
        </View>
        <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={styles.statEmoji}>🌱</Text>
          <Text style={[styles.statNum, { color: colors.foreground }]}>{habitsToday}/{habits.length}</Text>
          <Text style={[styles.statLab, { color: colors.mutedForeground }]}>привычки</Text>
        </View>
      </View>

      {/* Activity heatmap */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>АКТИВНОСТЬ (5 НЕДЕЛЬ)</Text>
        <View style={[styles.heatCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.heatGrid}>
            {heatmap.map((c, i) => (
              <View
                key={c.key}
                style={[styles.heatCell, { backgroundColor: heatCell(c.count) }]}
              />
            ))}
          </View>
          <View style={styles.heatLegend}>
            <Text style={[styles.heatLegText, { color: colors.mutedForeground }]}>Меньше</Text>
            {[0, 0.25, 0.6, 1].map(r => (
              <View key={r} style={[styles.heatCell, { backgroundColor: heatCell(r * maxHeat) }]} />
            ))}
            <Text style={[styles.heatLegText, { color: colors.mutedForeground }]}>Больше</Text>
          </View>
        </View>
      </View>

      {/* Category progress */}
      {catStats.length > 0 && (
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ПО КАТЕГОРИЯМ</Text>
          <View style={[styles.listCard, { borderColor: colors.border }]}>
            {catStats.map((cat, i) => {
              const p = cat.total ? Math.round((cat.done / cat.total) * 100) : 0;
              return (
                <View
                  key={cat.id}
                  style={[styles.catRow, { borderBottomColor: colors.border }, i === catStats.length - 1 && { borderBottomWidth: 0 }]}
                >
                  <Text style={styles.catEmoji}>{cat.emoji}</Text>
                  <View style={styles.catInfo}>
                    <View style={styles.catTop}>
                      <Text style={[styles.catName, { color: colors.foreground }]}>{cat.name}</Text>
                      <Text style={[styles.catPct, { color: colors.mutedForeground }]}>{cat.done}/{cat.total}</Text>
                    </View>
                    <View style={[styles.catTrack, { backgroundColor: colors.border }]}>
                      <View style={[styles.catFill, { width: `${p}%`, backgroundColor: p === 100 ? "#10B981" : colors.primary }]} />
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        </View>
      )}

      {/* Priority breakdown */}
      {priStats.length > 0 && (
        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ПРИОРИТЕТЫ (активные)</Text>
          <View style={styles.priRow}>
            {priStats.map(ps => (
              <View key={ps.p} style={[styles.priCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={[styles.priDot, { backgroundColor: ps.color }]} />
                <Text style={[styles.priNum, { color: colors.foreground }]}>{ps.count}</Text>
                <Text style={[styles.priLab, { color: colors.mutedForeground }]}>{ps.label}</Text>
              </View>
            ))}
          </View>
        </View>
      )}

      {/* Export */}
      <View style={styles.section}>
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ЭКСПОРТ</Text>
        <View style={styles.exportRow}>
          <Pressable
            style={[styles.exportBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => doExport("md")}
            disabled={exporting}
          >
            <Text style={styles.exportIcon}>📝</Text>
            <Text style={[styles.exportLabel, { color: colors.foreground }]}>Markdown</Text>
            <Text style={[styles.exportSub, { color: colors.mutedForeground }]}>Obsidian, Notion</Text>
          </Pressable>
          <Pressable
            style={[styles.exportBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => doExport("html")}
            disabled={exporting}
          >
            <Text style={styles.exportIcon}>🌐</Text>
            <Text style={[styles.exportLabel, { color: colors.foreground }]}>HTML</Text>
            <Text style={[styles.exportSub, { color: colors.mutedForeground }]}>Браузер, ИИ</Text>
          </Pressable>
        </View>
        <Text style={[styles.exportHint, { color: colors.mutedForeground }]}>
          MD подходит для импорта в Claude, ChatGPT, Obsidian. HTML — для просмотра в браузере.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  headerRow: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 20 },
  title: { fontSize: 26, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.5 },
  subtitle: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 2 },
  graphBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, borderWidth: 1 },
  graphBtnText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },

  card: { borderRadius: 14, borderWidth: StyleSheet.hairlineWidth, padding: 18, marginBottom: 14 },
  cardHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 10 },
  cardLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.6 },
  pctBig: { fontSize: 22, fontFamily: "Inter_700Bold", fontWeight: "700" },
  barTrack: { height: 6, borderRadius: 3, overflow: "hidden", marginBottom: 8 },
  barFill: { height: 6, borderRadius: 3 },
  cardSub: { fontSize: 12, fontFamily: "Inter_400Regular" },

  statsRow: { flexDirection: "row", gap: 8, marginBottom: 24 },
  statCard: { flex: 1, borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, padding: 12, alignItems: "center", gap: 2 },
  statEmoji: { fontSize: 18 },
  statNum: { fontSize: 18, fontFamily: "Inter_700Bold", fontWeight: "700" },
  statLab: { fontSize: 10, fontFamily: "Inter_400Regular", textAlign: "center" },

  section: { marginBottom: 24 },
  sectionLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.6, marginBottom: 8 },

  heatCard: { borderRadius: 14, borderWidth: StyleSheet.hairlineWidth, padding: 16 },
  heatGrid: { flexDirection: "row", flexWrap: "wrap", gap: 3 },
  heatCell: { width: 14, height: 14, borderRadius: 3 },
  heatLegend: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 10, justifyContent: "flex-end" },
  heatLegText: { fontSize: 10, fontFamily: "Inter_400Regular" },

  listCard: { borderWidth: StyleSheet.hairlineWidth, borderRadius: 14, overflow: "hidden" },
  catRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, paddingHorizontal: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  catEmoji: { fontSize: 20, width: 28, textAlign: "center" },
  catInfo: { flex: 1, gap: 6 },
  catTop: { flexDirection: "row", justifyContent: "space-between" },
  catName: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  catPct: { fontSize: 12, fontFamily: "Inter_400Regular" },
  catTrack: { height: 4, borderRadius: 2, overflow: "hidden" },
  catFill: { height: 4, borderRadius: 2 },

  priRow: { flexDirection: "row", gap: 10 },
  priCard: { flex: 1, borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, padding: 14, alignItems: "center", gap: 4 },
  priDot: { width: 10, height: 10, borderRadius: 5 },
  priNum: { fontSize: 20, fontFamily: "Inter_700Bold", fontWeight: "700" },
  priLab: { fontSize: 11, fontFamily: "Inter_400Regular" },

  exportRow: { flexDirection: "row", gap: 12, marginBottom: 10 },
  exportBtn: { flex: 1, borderRadius: 14, borderWidth: StyleSheet.hairlineWidth, padding: 18, alignItems: "center", gap: 4 },
  exportIcon: { fontSize: 28, marginBottom: 4 },
  exportLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  exportSub: { fontSize: 11, fontFamily: "Inter_400Regular" },
  exportHint: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
});
