import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import { ActivityIndicator, Alert, Modal, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ShiftTemplate, useWorkSchedule } from "@/context/WorkScheduleContext";
import { useTheme } from "@/context/ThemeContext";
import { formatMoney, SHIFT_COLORS } from "@/utils/workSchedule";

type TemplateDraft = Omit<ShiftTemplate, "id">;
const EMPTY_DRAFT: TemplateDraft = {
  name: "", startTime: "09:00", endTime: "17:00", payType: "hourly", rate: 0, color: SHIFT_COLORS[0],
};

export default function ShiftTemplatesScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { templates, isLoading, saveTemplate, deleteTemplate } = useWorkSchedule();
  const [visible, setVisible] = useState(false);
  const [editingId, setEditingId] = useState<string | undefined>();
  const [draft, setDraft] = useState<TemplateDraft>(EMPTY_DRAFT);
  const topInset = Platform.OS === "web" ? 0 : insets.top;
  const bottomInset = Platform.OS === "web" ? 34 : insets.bottom;

  const openNew = () => {
    setEditingId(undefined);
    setDraft(EMPTY_DRAFT);
    setVisible(true);
  };

  const openEdit = (template: ShiftTemplate) => {
    const { id, ...rest } = template;
    setEditingId(id);
    setDraft(rest);
    setVisible(true);
  };

  const save = () => {
    const rate = Number(draft.rate);
    if (!draft.name.trim()) return Alert.alert("Введите название смены");
    const validTime = (value: string) => /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);
    if (!validTime(draft.startTime) || !validTime(draft.endTime)) {
      return Alert.alert("Укажите время в формате ЧЧ:ММ");
    }
    if (!Number.isFinite(rate) || rate < 0) return Alert.alert("Ставка не может быть отрицательной");
    saveTemplate({ ...draft, name: draft.name.trim(), rate }, editingId);
    setVisible(false);
  };

  const confirmDelete = (template: ShiftTemplate) => {
    Alert.alert("Удалить шаблон?", `«${template.name}»`, [
      { text: "Отмена", style: "cancel" },
      {
        text: "Удалить", style: "destructive", onPress: () => {
          if (!deleteTemplate(template.id)) {
            Alert.alert("Шаблон используется", "Сначала удалите назначенные по нему смены, затем удалите шаблон.");
          }
        },
      },
    ]);
  };

  if (isLoading) {
    return <View style={[styles.loading, { backgroundColor: colors.background }]}><ActivityIndicator color={colors.primary} /></View>;
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.content, { paddingTop: topInset + 18, paddingBottom: bottomInset + 36 }]} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.back} accessibilityLabel="Назад">
            <Feather name="arrow-left" size={20} color={colors.foreground} />
          </TouchableOpacity>
          <View style={styles.headerCopy}>
            <Text style={[styles.title, { color: colors.foreground }]}>Шаблоны смен</Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Ставка, время и цвет</Text>
          </View>
          <TouchableOpacity onPress={openNew} style={[styles.addButton, { backgroundColor: colors.primary }]}>
            <Feather name="plus" size={17} color="#fff" />
          </TouchableOpacity>
        </View>

        {isLoading ? (
          <Text style={[styles.empty, { color: colors.mutedForeground }]}>Загружаем…</Text>
        ) : templates.length === 0 ? (
          <View style={styles.emptyBlock}>
            <Feather name="calendar" size={30} color={colors.mutedForeground} />
            <Text style={[styles.empty, { color: colors.mutedForeground }]}>Пока нет шаблонов</Text>
            <Text style={[styles.hint, { color: colors.mutedForeground }]}>Создайте, например, дневную или ночную смену.</Text>
            <TouchableOpacity onPress={openNew} style={[styles.primaryButton, { backgroundColor: colors.foreground }]}>
              <Text style={[styles.primaryButtonText, { color: colors.background }]}>Создать шаблон</Text>
            </TouchableOpacity>
          </View>
        ) : templates.map(template => (
          <View key={template.id} style={[styles.templateCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.colorBar, { backgroundColor: template.color }]} />
            <View style={styles.templateBody}>
              <View style={styles.templateTop}>
                <Text style={[styles.templateName, { color: colors.foreground }]} numberOfLines={1}>{template.name}</Text>
                <View style={styles.actions}>
                  <TouchableOpacity onPress={() => openEdit(template)} style={styles.iconButton} accessibilityLabel="Изменить шаблон">
                    <Feather name="edit-2" size={16} color={colors.mutedForeground} />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => confirmDelete(template)} style={styles.iconButton} accessibilityLabel="Удалить шаблон">
                    <Feather name="trash-2" size={16} color={colors.destructive} />
                  </TouchableOpacity>
                </View>
              </View>
              <Text style={[styles.time, { color: colors.mutedForeground }]}>{template.startTime} — {template.endTime}</Text>
              <Text style={[styles.rate, { color: colors.foreground }]}>
                {template.payType === "hourly" ? `${formatMoney(template.rate)} / час` : `${formatMoney(template.rate)} за смену`}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>

      <Modal visible={visible} animationType="slide" transparent presentationStyle="overFullScreen" onRequestClose={() => setVisible(false)}>
        <View style={styles.overlay}>
          <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border, paddingBottom: bottomInset + 24 }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />
            <Text style={[styles.sheetTitle, { color: colors.foreground }]}>{editingId ? "Изменить шаблон" : "Новый шаблон смены"}</Text>
            <TextInput value={draft.name} onChangeText={name => setDraft(value => ({ ...value, name }))} placeholder="Например, Дневная" placeholderTextColor={colors.mutedForeground} style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]} />

            <Text style={[styles.label, { color: colors.mutedForeground }]}>ВРЕМЯ СМЕНЫ</Text>
            <View style={styles.timeRow}>
              <TextInput value={draft.startTime} onChangeText={startTime => setDraft(value => ({ ...value, startTime }))} placeholder="09:00" keyboardType="numbers-and-punctuation" style={[styles.input, styles.timeInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]} />
              <Text style={[styles.dash, { color: colors.mutedForeground }]}>—</Text>
              <TextInput value={draft.endTime} onChangeText={endTime => setDraft(value => ({ ...value, endTime }))} placeholder="17:00" keyboardType="numbers-and-punctuation" style={[styles.input, styles.timeInput, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]} />
            </View>

            <Text style={[styles.label, { color: colors.mutedForeground }]}>ОПЛАТА</Text>
            <View style={[styles.segment, { backgroundColor: colors.surface }]}>
              {(["hourly", "fixed"] as const).map(type => (
                <TouchableOpacity key={type} onPress={() => setDraft(value => ({ ...value, payType: type }))} style={[styles.segmentButton, draft.payType === type && { backgroundColor: colors.foreground }]}>
                  <Text style={[styles.segmentText, { color: draft.payType === type ? colors.background : colors.mutedForeground }]}>
                    {type === "hourly" ? "За час" : "За смену"}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
            <TextInput value={String(draft.rate || "")} onChangeText={value => setDraft(current => ({ ...current, rate: Number(value.replace(",", ".")) || 0 }))} placeholder={draft.payType === "hourly" ? "Ставка в ₽ за час" : "Сумма за смену в ₽"} placeholderTextColor={colors.mutedForeground} keyboardType="decimal-pad" style={[styles.input, { backgroundColor: colors.surface, borderColor: colors.border, color: colors.foreground }]} />

            <Text style={[styles.label, { color: colors.mutedForeground }]}>ЦВЕТ СМЕНЫ</Text>
            <View style={styles.colorRow}>
              {SHIFT_COLORS.map(color => (
                <TouchableOpacity key={color} onPress={() => setDraft(value => ({ ...value, color }))} style={[styles.colorDot, { backgroundColor: color }, draft.color === color && { borderColor: colors.foreground, borderWidth: 3 }]} accessibilityLabel={`Цвет ${color}`} />
              ))}
            </View>

            <View style={styles.footerButtons}>
              <TouchableOpacity onPress={() => setVisible(false)} style={[styles.secondaryButton, { borderColor: colors.border }]}>
                <Text style={[styles.secondaryButtonText, { color: colors.mutedForeground }]}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={save} style={[styles.primaryButton, { backgroundColor: colors.foreground }]}>
                <Text style={[styles.primaryButtonText, { color: colors.background }]}>Сохранить</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  content: { paddingHorizontal: 20, gap: 12 },
  header: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 14 },
  back: { width: 36, height: 40, justifyContent: "center" },
  headerCopy: { flex: 1 },
  title: { fontSize: 24, fontFamily: "Inter_700Bold", fontWeight: "700" },
  subtitle: { fontSize: 13, fontFamily: "Inter_400Regular", marginTop: 3 },
  addButton: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  templateCard: { flexDirection: "row", borderWidth: 1, borderRadius: 14, overflow: "hidden" },
  colorBar: { width: 6 },
  templateBody: { flex: 1, padding: 14, gap: 6 },
  templateTop: { flexDirection: "row", alignItems: "center", gap: 8 },
  templateName: { flex: 1, fontSize: 16, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  actions: { flexDirection: "row", gap: 8 },
  iconButton: { padding: 5 },
  time: { fontSize: 13, fontFamily: "Inter_400Regular" },
  rate: { fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginTop: 2 },
  emptyBlock: { alignItems: "center", paddingTop: 80, gap: 12 },
  empty: { textAlign: "center", fontSize: 15, fontFamily: "Inter_500Medium", marginTop: 12 },
  hint: { fontSize: 13, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 19, maxWidth: 280 },
  overlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.36)" },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, borderTopWidth: StyleSheet.hairlineWidth, padding: 22, gap: 13 },
  handle: { width: 38, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 4 },
  sheetTitle: { fontSize: 19, fontFamily: "Inter_700Bold", fontWeight: "700" },
  input: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 12, fontSize: 15, fontFamily: "Inter_400Regular" },
  label: { fontSize: 11, letterSpacing: 0.7, fontFamily: "Inter_600SemiBold", fontWeight: "600", marginTop: 3 },
  timeRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  timeInput: { flex: 1, textAlign: "center" },
  dash: { fontSize: 16 },
  segment: { flexDirection: "row", borderRadius: 10, padding: 3 },
  segmentButton: { flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 8 },
  segmentText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  colorRow: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  colorDot: { width: 30, height: 30, borderRadius: 15 },
  footerButtons: { flexDirection: "row", gap: 10, marginTop: 6 },
  secondaryButton: { flex: 1, alignItems: "center", padding: 13, borderWidth: 1, borderRadius: 10 },
  secondaryButtonText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  primaryButton: { flex: 1, alignItems: "center", padding: 13, borderRadius: 10 },
  primaryButtonText: { fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
