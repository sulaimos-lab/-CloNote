import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { CategoryDef, useTasks } from "@/context/TaskContext";
import { useTheme } from "@/context/ThemeContext";

const EMOJI_SUGGESTIONS = [
  "📁","💼","🏠","🌱","❤️","🛒","📚","🎯","💡","🔧","🎨","🏋️",
  "✈️","💰","📝","🎵","🌍","🤝","🧠","⭐","🔥","💻","📱","🏆",
  "🎉","🧪","🌿","🍕","🎮","🏗️","📊","🔑","🛡️","⚡","🌟","🎪",
];

interface ModalState {
  visible: boolean;
  mode: "add" | "edit";
  id?: string;
  name: string;
  emoji: string;
  color: string;
}

const PALETTE = [
  "#3B82F6","#10B981","#8B5CF6","#EF4444","#F59E0B",
  "#EC4899","#14B8A6","#F97316","#6366F1","#84CC16",
  "#06B6D4","#A855F7","#E11D48","#0EA5E9","#22C55E",
];

const INIT: ModalState = { visible: false, mode: "add", name: "", emoji: "📁", color: "#3B82F6" };

export default function CategoriesScreen() {
  const { colors } = useTheme();
  const { tasks, categories, addCategory, updateCategory, deleteCategory } = useTasks();
  const insets    = useSafeAreaInsets();
  const topInset  = Platform.OS === "web" ? 0 : insets.top;
  const nameRef   = useRef<TextInput>(null);

  const [modal, setModal] = useState<ModalState>(INIT);

  const countFor = (id: string) =>
    tasks.filter(t => t.category === id && !t.archived).length;

  const doneFor = (id: string) =>
    tasks.filter(t => t.category === id && !t.archived && t.completed).length;

  const openAdd = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setModal({ ...INIT, visible: true, mode: "add" });
    setTimeout(() => nameRef.current?.focus(), 200);
  };

  const openEdit = (cat: CategoryDef) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setModal({ visible: true, mode: "edit", id: cat.id, name: cat.name, emoji: cat.emoji, color: "#3B82F6" });
    setTimeout(() => nameRef.current?.focus(), 200);
  };

  const handleSave = () => {
    const name = modal.name.trim();
    if (!name) { Alert.alert("Введите название проекта"); return; }
    if (modal.mode === "add") {
      addCategory(name, modal.emoji);
    } else if (modal.id) {
      updateCategory(modal.id, name, modal.emoji);
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setModal(INIT);
  };

  const handleDelete = () => {
    if (!modal.id) return;
    const name = modal.name;
    Alert.alert(
      `Удалить «${name}»?`,
      "Задачи этого проекта останутся, но потеряют категорию.",
      [
        { text: "Отмена", style: "cancel" },
        {
          text: "Удалить", style: "destructive",
          onPress: () => {
            deleteCategory(modal.id!);
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
            setModal(INIT);
          },
        },
      ],
    );
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="chevron-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Проекты</Text>
        <TouchableOpacity onPress={openAdd} style={[styles.addBtn, { backgroundColor: colors.foreground }]} activeOpacity={0.8}>
          <Feather name="plus" size={16} color={colors.background} />
          <Text style={[styles.addBtnText, { color: colors.background }]}>Новый</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 40 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Summary */}
        <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.summaryItem}>
            <Text style={[styles.summaryNum, { color: colors.foreground }]}>{categories.length}</Text>
            <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Проектов</Text>
          </View>
          <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
          <View style={styles.summaryItem}>
            <Text style={[styles.summaryNum, { color: colors.foreground }]}>
              {tasks.filter(t => !t.archived).length}
            </Text>
            <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Задач</Text>
          </View>
          <View style={[styles.summaryDivider, { backgroundColor: colors.border }]} />
          <View style={styles.summaryItem}>
            <Text style={[styles.summaryNum, { color: colors.foreground }]}>
              {tasks.filter(t => !t.archived && t.completed).length}
            </Text>
            <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>Выполнено</Text>
          </View>
        </View>

        {/* Category list */}
        {categories.length === 0 ? (
          <View style={styles.empty}>
            <Text style={{ fontSize: 44, marginBottom: 12 }}>📁</Text>
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>Нет проектов</Text>
            <Text style={[styles.emptyDesc, { color: colors.mutedForeground }]}>
              Создай проект, чтобы группировать задачи
            </Text>
            <TouchableOpacity
              onPress={openAdd}
              style={[styles.emptyBtn, { backgroundColor: colors.foreground }]}
              activeOpacity={0.8}
            >
              <Text style={[styles.emptyBtnText, { color: colors.background }]}>Создать проект</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[styles.list, { borderTopColor: colors.border, borderBottomColor: colors.border }]}>
            {categories.map((cat, idx) => {
              const total = countFor(cat.id);
              const done  = doneFor(cat.id);
              const pct   = total > 0 ? done / total : 0;

              return (
                <TouchableOpacity
                  key={cat.id}
                  style={[
                    styles.catRow,
                    { borderBottomColor: colors.border },
                    idx === categories.length - 1 && { borderBottomWidth: 0 },
                  ]}
                  onPress={() => openEdit(cat)}
                  activeOpacity={0.7}
                >
                  {/* Left: emoji + info */}
                  <View style={[styles.catEmojiBubble, { backgroundColor: colors.surface }]}>
                    <Text style={styles.catEmoji}>{cat.emoji}</Text>
                  </View>

                  <View style={styles.catInfo}>
                    <Text style={[styles.catName, { color: colors.foreground }]}>{cat.name}</Text>
                    <View style={styles.catMeta}>
                      <Text style={[styles.catCount, { color: colors.mutedForeground }]}>
                        {total === 0
                          ? "Нет задач"
                          : `${done} из ${total} выполнено`}
                      </Text>
                    </View>
                    {/* Progress mini bar */}
                    {total > 0 && (
                      <View style={[styles.miniBarBg, { backgroundColor: colors.border }]}>
                        <View
                          style={[
                            styles.miniBarFill,
                            { backgroundColor: colors.foreground, width: `${pct * 100}%` },
                          ]}
                        />
                      </View>
                    )}
                  </View>

                  {/* Right: edit arrow */}
                  <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        <Text style={[styles.tip, { color: colors.mutedForeground }]}>
          Нажми на проект, чтобы изменить название или иконку
        </Text>
      </ScrollView>

      {/* Editor Modal */}
      <Modal
        visible={modal.visible}
        animationType="slide"
        transparent
        presentationStyle="overFullScreen"
        onRequestClose={() => setModal(INIT)}
      >
        <View style={styles.overlay}>
          <TouchableOpacity style={StyleSheet.absoluteFill} onPress={() => setModal(INIT)} activeOpacity={1} />
          <View style={[styles.sheet, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.handle, { backgroundColor: colors.border }]} />

            {/* Sheet title */}
            <View style={styles.sheetHeader}>
              <Text style={[styles.sheetEmoji]}>{modal.emoji}</Text>
              <Text style={[styles.sheetTitle, { color: colors.foreground }]}>
                {modal.mode === "add" ? "Новый проект" : "Редактировать"}
              </Text>
            </View>

            {/* Name input */}
            <View style={[styles.inputWrap, { borderColor: colors.border, backgroundColor: colors.surface }]}>
              <TextInput
                ref={nameRef}
                value={modal.name}
                onChangeText={name => setModal(m => ({ ...m, name }))}
                placeholder="Название проекта"
                placeholderTextColor={colors.mutedForeground}
                style={[styles.nameInput, { color: colors.foreground }]}
                maxLength={40}
                returnKeyType="done"
                onSubmitEditing={handleSave}
              />
              {modal.name.length > 0 && (
                <TouchableOpacity onPress={() => setModal(m => ({ ...m, name: "" }))}>
                  <Feather name="x" size={16} color={colors.mutedForeground} />
                </TouchableOpacity>
              )}
            </View>

            {/* Emoji picker */}
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>ИКОНКА</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.emojiScroll}
              contentContainerStyle={styles.emojiRow}
            >
              {EMOJI_SUGGESTIONS.map(e => (
                <TouchableOpacity
                  key={e}
                  onPress={() => { Haptics.selectionAsync(); setModal(m => ({ ...m, emoji: e })); }}
                  style={[
                    styles.emojiBtn,
                    { borderColor: modal.emoji === e ? colors.foreground : colors.border },
                    modal.emoji === e && { backgroundColor: colors.surface },
                  ]}
                >
                  <Text style={styles.emojiBtnText}>{e}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Actions */}
            <View style={styles.actions}>
              {modal.mode === "edit" && (
                <TouchableOpacity
                  style={[styles.deleteBtn, { borderColor: "#E03E3E22", backgroundColor: "#E03E3E11" }]}
                  onPress={handleDelete}
                  activeOpacity={0.7}
                >
                  <Feather name="trash-2" size={16} color="#E03E3E" />
                  <Text style={[styles.deleteBtnText, { color: "#E03E3E" }]}>Удалить</Text>
                </TouchableOpacity>
              )}
              <TouchableOpacity
                style={[styles.cancelBtn, { borderColor: colors.border, flex: 1 }]}
                onPress={() => setModal(INIT)}
                activeOpacity={0.7}
              >
                <Text style={[styles.cancelText, { color: colors.mutedForeground }]}>Отмена</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.saveBtn, { backgroundColor: colors.foreground, flex: 1 }]}
                onPress={handleSave}
                activeOpacity={0.8}
              >
                <Text style={[styles.saveBtnText, { color: colors.background }]}>
                  {modal.mode === "add" ? "Создать" : "Сохранить"}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth, gap: 10,
  },
  backBtn: { padding: 4, marginRight: 2 },
  headerTitle: { flex: 1, fontSize: 20, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.4 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 8 },
  addBtnText: { fontSize: 14, fontFamily: "Inter_600SemiBold", fontWeight: "600" },

  content: { paddingHorizontal: 20, paddingTop: 20, gap: 20 },

  summaryCard: {
    flexDirection: "row", borderRadius: 12,
    borderWidth: StyleSheet.hairlineWidth, overflow: "hidden",
  },
  summaryItem: { flex: 1, alignItems: "center", paddingVertical: 18, gap: 4 },
  summaryNum: { fontSize: 24, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.5 },
  summaryLabel: { fontSize: 11, fontFamily: "Inter_400Regular" },
  summaryDivider: { width: StyleSheet.hairlineWidth },

  list: { borderTopWidth: StyleSheet.hairlineWidth, borderBottomWidth: StyleSheet.hairlineWidth },
  catRow: {
    flexDirection: "row", alignItems: "center", gap: 14,
    paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  catEmojiBubble: {
    width: 46, height: 46, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
  },
  catEmoji: { fontSize: 22 },
  catInfo: { flex: 1, gap: 4 },
  catName: { fontSize: 16, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  catMeta: { flexDirection: "row", alignItems: "center" },
  catCount: { fontSize: 12, fontFamily: "Inter_400Regular" },
  miniBarBg: { height: 3, borderRadius: 2, marginTop: 4, overflow: "hidden" },
  miniBarFill: { height: 3, borderRadius: 2 },

  empty: { alignItems: "center", paddingTop: 60, gap: 8 },
  emptyTitle: { fontSize: 18, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  emptyDesc: { fontSize: 14, fontFamily: "Inter_400Regular", textAlign: "center", maxWidth: 260 },
  emptyBtn: { marginTop: 16, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 10 },
  emptyBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },

  tip: { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center", paddingHorizontal: 20 },

  overlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.35)" },
  sheet: {
    borderTopLeftRadius: 20, borderTopRightRadius: 20,
    borderTopWidth: StyleSheet.hairlineWidth,
    padding: 20, paddingBottom: 44, gap: 16,
  },
  handle: { width: 36, height: 4, borderRadius: 2, alignSelf: "center", marginBottom: 4 },
  sheetHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  sheetEmoji: { fontSize: 28 },
  sheetTitle: { fontSize: 20, fontFamily: "Inter_700Bold", fontWeight: "700", letterSpacing: -0.3 },

  inputWrap: {
    flexDirection: "row", alignItems: "center", gap: 8,
    borderWidth: 1, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 12,
  },
  nameInput: { flex: 1, fontSize: 16, fontFamily: "Inter_400Regular", padding: 0 },

  fieldLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", fontWeight: "600", letterSpacing: 0.6, marginBottom: -8 },
  emojiScroll: { marginHorizontal: -4 },
  emojiRow: { flexDirection: "row", gap: 6, paddingHorizontal: 4 },
  emojiBtn: { width: 42, height: 42, borderRadius: 10, borderWidth: 1.5, alignItems: "center", justifyContent: "center" },
  emojiBtnText: { fontSize: 20 },

  actions: { flexDirection: "row", gap: 8, marginTop: 4 },
  deleteBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    borderWidth: 1, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 13,
  },
  deleteBtnText: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  cancelBtn: { borderWidth: 1, borderRadius: 10, padding: 13, alignItems: "center" },
  cancelText: { fontSize: 15, fontFamily: "Inter_400Regular" },
  saveBtn: { borderRadius: 10, padding: 13, alignItems: "center" },
  saveBtnText: { fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
});
