/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * privacy.tsx
 * Экран политики конфиденциальности.
 * Обязателен для публикации в Google Play и App Store.
 * Описывает какие данные собираются, где хранятся и как защищены.
 */
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTheme } from "@/context/ThemeContext";

const LAST_UPDATED = "10 июля 2025 г.";
const AUTHOR       = "Sulaimon Qurbonov";
const APP_NAME     = "CloNote";
const CONTACT      = "sulaimon.dev@gmail.com";

type Section = { title: string; icon: string; body: string };

const SECTIONS: Section[] = [
  {
    title: "Какие данные мы собираем",
    icon:  "database",
    body:
      "CloNote хранит только те данные, которые ты сам вводишь: задачи, привычки и категории. " +
      "Приложение не собирает личные данные (имя, телефон, геолокация) автоматически. " +
      "При входе через Google / Яндекс / ВКонтакте / Mail.ru мы получаем только публичное имя и аватар — " +
      "они хранятся локально на устройстве.",
  },
  {
    title: "Где хранятся данные",
    icon:  "hard-drive",
    body:
      "Все задачи и привычки хранятся локально на твоём устройстве (AsyncStorage). " +
      "При наличии подключения к интернету задачи синхронизируются с защищённым сервером " +
      "для доступа через ИИ-ассистентов (MCP). " +
      "Данные сервера не передаются третьим лицам.",
  },
  {
    title: "Доступ к функциям устройства",
    icon:  "smartphone",
    body:
      "📷 Камера и галерея — только для прикрепления фотографий к задачам, по запросу пользователя.\n" +
      "🔔 Уведомления — для напоминаний о сроках задач, с разрешения пользователя.\n" +
      "Приложение не запрашивает доступ к контактам, микрофону, местоположению или файловой системе.",
  },
  {
    title: "ИИ-интеграция (MCP)",
    icon:  "cpu",
    body:
      "Если ты подключаешь ИИ-ассистента (Claude, Cursor, Cline) через экран «Подключить ИИ», " +
      "твои задачи становятся доступны этому ассистенту для чтения и редактирования. " +
      "Мы не передаём данные ИИ-сервисам автоматически — только при явном подключении тобой. " +
      "Ты можешь отключить доступ в любой момент.",
  },
  {
    title: "Реклама и аналитика",
    icon:  "bar-chart-2",
    body:
      "CloNote не содержит рекламы. Мы не используем сторонние сервисы аналитики (Google Analytics, Facebook Pixel и т.д.). " +
      "Никакая информация о твоём поведении в приложении не продаётся и не передаётся рекламным платформам.",
  },
  {
    title: "Безопасность",
    icon:  "shield",
    body:
      "Передача данных между приложением и сервером осуществляется по протоколу HTTPS. " +
      "Мы регулярно обновляем зависимости и следим за известными уязвимостями. " +
      "Тем не менее, ни одна система не может гарантировать 100% безопасность — " +
      "не храни в CloNote пароли или банковские данные.",
  },
  {
    title: "Дети",
    icon:  "user",
    body:
      "CloNote не предназначен для детей до 13 лет. " +
      "Мы сознательно не собираем данные несовершеннолетних. " +
      "Если ты считаешь, что ребёнок предоставил нам личные данные — свяжись с нами, " +
      "мы удалим их в течение 72 часов.",
  },
  {
    title: "Твои права",
    icon:  "check-square",
    body:
      "Ты можешь в любой момент:\n" +
      "• Удалить все данные через Настройки → «Очистить все данные»\n" +
      "• Экспортировать задачи в MD или HTML через Дашборд\n" +
      "• Запросить удаление данных с сервера, написав нам на email\n\n" +
      "Удаление аккаунта удаляет все твои данные с наших серверов безвозвратно.",
  },
  {
    title: "Изменения политики",
    icon:  "edit",
    body:
      "Мы можем обновлять эту политику. При существенных изменениях — уведомим через приложение. " +
      "Дата последнего обновления всегда указана вверху этого экрана. " +
      "Продолжение использования приложения после изменений означает согласие с новой политикой.",
  },
];

export default function PrivacyScreen() {
  const { colors } = useTheme();
  const insets   = useSafeAreaInsets();
  const topInset = Platform.OS === "web" ? 0 : insets.top;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topInset + 16, borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.7}>
          <Feather name="chevron-left" size={22} color={colors.foreground} />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Конфиденциальность</Text>
        <View style={{ width: 34 }} />
      </View>

      <ScrollView
        contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 48 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Top card */}
        <View style={[styles.topCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={styles.topEmoji}>🔒</Text>
          <Text style={[styles.topTitle, { color: colors.foreground }]}>
            Политика конфиденциальности
          </Text>
          <Text style={[styles.topMeta, { color: colors.mutedForeground }]}>
            {APP_NAME} · Автор: {AUTHOR}
          </Text>
          <Text style={[styles.topMeta, { color: colors.mutedForeground }]}>
            Последнее обновление: {LAST_UPDATED}
          </Text>
          <View style={[styles.freeBadge, { backgroundColor: "#10B98118" }]}>
            <Text style={[styles.freeBadgeText, { color: "#10B981" }]}>
              ✓ Без рекламы  ·  ✓ Без слежки  ·  ✓ Бесплатно
            </Text>
          </View>
        </View>

        {/* Sections */}
        {SECTIONS.map((sec, idx) => (
          <View key={idx} style={styles.section}>
            <View style={styles.secHeader}>
              <View style={[styles.secIconWrap, { backgroundColor: colors.surface }]}>
                <Feather name={sec.icon as any} size={15} color={colors.foreground} />
              </View>
              <Text style={[styles.secTitle, { color: colors.foreground }]}>{sec.title}</Text>
            </View>
            <View style={[styles.secCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.secBody, { color: colors.foreground }]}>{sec.body}</Text>
            </View>
          </View>
        ))}

        {/* Contact */}
        <View style={[styles.contactCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Feather name="mail" size={18} color={colors.mutedForeground} />
          <View style={{ flex: 1, gap: 3 }}>
            <Text style={[styles.contactLabel, { color: colors.foreground }]}>Вопросы о конфиденциальности</Text>
            <Text style={[styles.contactEmail, { color: colors.primary }]}>{CONTACT}</Text>
          </View>
        </View>

        <Text style={[styles.footer, { color: colors.mutedForeground }]}>
          © 2025 {AUTHOR} · MIT License{"\n"}
          Действует с {LAST_UPDATED}
        </Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 20, paddingBottom: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  backBtn: { padding: 4, marginRight: 8, width: 34 },
  headerTitle: {
    flex: 1, fontSize: 18, fontFamily: "Inter_700Bold",
    fontWeight: "700", letterSpacing: -0.3, textAlign: "center",
  },

  content: { paddingHorizontal: 20, paddingTop: 24, gap: 16 },

  topCard: {
    borderRadius: 16, borderWidth: StyleSheet.hairlineWidth,
    padding: 22, alignItems: "center", gap: 6, marginBottom: 8,
  },
  topEmoji:  { fontSize: 36, marginBottom: 4 },
  topTitle:  { fontSize: 18, fontFamily: "Inter_700Bold", fontWeight: "700", textAlign: "center" },
  topMeta:   { fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "center" },
  freeBadge: { marginTop: 8, paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 },
  freeBadgeText: { fontSize: 13, fontFamily: "Inter_500Medium", fontWeight: "500" },

  section: { gap: 8 },
  secHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  secIconWrap: { width: 30, height: 30, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  secTitle: { flex: 1, fontSize: 15, fontFamily: "Inter_600SemiBold", fontWeight: "600" },
  secCard: {
    borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, padding: 14,
  },
  secBody: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 20 },

  contactCard: {
    flexDirection: "row", alignItems: "center", gap: 12,
    borderRadius: 12, borderWidth: StyleSheet.hairlineWidth, padding: 16, marginTop: 8,
  },
  contactLabel: { fontSize: 14, fontFamily: "Inter_500Medium", fontWeight: "500" },
  contactEmail: { fontSize: 13, fontFamily: "Inter_400Regular" },

  footer: {
    fontSize: 12, fontFamily: "Inter_400Regular",
    textAlign: "center", lineHeight: 18, marginTop: 8,
  },
});
