/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT — https://github.com/clonote/LICENSE
 *
 * TaskContext.tsx
 * Глобальное хранилище задач, привычек и категорий.
 * Обеспечивает синхронизацию с сервером (fire-and-forget),
 * персистентность через AsyncStorage и дерево подзадач.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import {
  pushAllTasks,
  pushTask,
  deleteTaskRemote,
  isApiReachable,
} from "../utils/syncService";

export type Category = string;
export type Priority = "high" | "normal" | "low";

export interface CategoryDef {
  id: string;
  name: string;
  emoji: string;
}

export interface Task {
  id: string;
  title: string;
  category: Category;
  priority: Priority;
  dueDate?: string;
  completed: boolean;
  createdAt: string;
  parentId?: string;
  archived?: boolean;
  archivedAt?: string;
  imageUri?: string;
}

export interface Habit {
  id: string;
  title: string;
  color: string;
  completedDays: string[];
}

interface TaskContextValue {
  tasks: Task[];
  habits: Habit[];
  categories: CategoryDef[];
  addTask: (task: Omit<Task, "id" | "createdAt">) => void;
  updateTask: (id: string, patch: Partial<Omit<Task, "id" | "createdAt">>) => void;
  toggleTask: (id: string) => void;
  deleteTask: (id: string) => void;
  restoreTask: (id: string) => void;
  purgeTask: (id: string) => void;
  purgeAll: () => void;
  addHabit: (habit: Omit<Habit, "id" | "completedDays">) => void;
  toggleHabitDay: (habitId: string, day: string) => void;
  deleteHabit: (id: string) => void;
  getChildren: (parentId: string | undefined) => Task[];
  getRootTasks: () => Task[];
  getArchivedTasks: () => Task[];
  addCategory: (name: string, emoji: string) => void;
  updateCategory: (id: string, name: string, emoji: string) => void;
  deleteCategory: (id: string) => void;
  todayCompleted: number;
  todayTotal: number;
  syncStatus: "idle" | "syncing" | "ok" | "error";
}

const TaskContext = createContext<TaskContextValue | null>(null);

const TASKS_KEY = "clonote_tasks_v2";
const HABITS_KEY = "clonote_habits_v1";
const CATS_KEY   = "clonote_categories_v1";

function genId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

export const DEFAULT_CATEGORIES: CategoryDef[] = [
  { id: "work",     name: "Работа",   emoji: "💼" },
  { id: "home",     name: "Дом",      emoji: "🏠" },
  { id: "habits",   name: "Привычки", emoji: "🌱" },
  { id: "personal", name: "Личное",   emoji: "❤️" },
  { id: "shopping", name: "Покупки",  emoji: "🛒" },
];

export const PRIORITY_CONFIG: Record<Priority, { label: string; color: string }> = {
  high:   { label: "Срочно",  color: "#E03E3E" },
  normal: { label: "Важно",   color: "#D9730D" },
  low:    { label: "Обычно",  color: "#9B9A97" },
};

const DEMO_TASKS: Task[] = [
  { id: "t1",   title: "Подготовить отчёт",  category: "work",     priority: "high",   completed: false, createdAt: new Date().toISOString() },
  { id: "t1a",  title: "Собрать данные",      category: "work",     priority: "normal", completed: false, createdAt: new Date().toISOString(), parentId: "t1"  },
  { id: "t1a1", title: "Запросить у Маши",   category: "work",     priority: "low",    completed: false, createdAt: new Date().toISOString(), parentId: "t1a" },
  { id: "t1a2", title: "Проверить базу",     category: "work",     priority: "low",    completed: true,  createdAt: new Date().toISOString(), parentId: "t1a" },
  { id: "t1b",  title: "Написать выводы",    category: "work",     priority: "normal", completed: false, createdAt: new Date().toISOString(), parentId: "t1"  },
  { id: "t2",   title: "Уборка дома",        category: "home",     priority: "normal", completed: false, createdAt: new Date().toISOString() },
  { id: "t2a",  title: "Кухня",              category: "home",     priority: "low",    completed: true,  createdAt: new Date().toISOString(), parentId: "t2"  },
  { id: "t2b",  title: "Комнаты",            category: "home",     priority: "low",    completed: false, createdAt: new Date().toISOString(), parentId: "t2"  },
  { id: "t3",   title: "Покупки на неделю",  category: "shopping", priority: "normal", completed: false, createdAt: new Date().toISOString() },
  { id: "t3a",  title: "Молоко и хлеб",      category: "shopping", priority: "low",    completed: false, createdAt: new Date().toISOString(), parentId: "t3"  },
];

const DEMO_HABITS: Habit[] = [
  { id: "h1", title: "Зарядка",         color: "#37352F", completedDays: [] },
  { id: "h2", title: "Читать 20 минут", color: "#2383E2", completedDays: [] },
  { id: "h3", title: "Пить воду",       color: "#0F7B6C", completedDays: [] },
];

export function TaskProvider({ children }: { children: React.ReactNode }) {
  const [tasks,      setTasks]      = useState<Task[]>([]);
  const [habits,     setHabits]     = useState<Habit[]>([]);
  const [categories, setCategories] = useState<CategoryDef[]>([]);
  const [syncStatus, setSyncStatus] = useState<"idle" | "syncing" | "ok" | "error">("idle");

  // Initial load + first sync
  useEffect(() => {
    AsyncStorage.getItem(TASKS_KEY).then(d => {
      const loaded = d ? JSON.parse(d) as Task[] : DEMO_TASKS;
      setTasks(loaded);
      if (!d) AsyncStorage.setItem(TASKS_KEY, JSON.stringify(DEMO_TASKS));

      // Fire-and-forget initial sync
      setSyncStatus("syncing");
      isApiReachable().then(reachable => {
        if (!reachable) { setSyncStatus("idle"); return; }
        pushAllTasks(loaded)
          .then(() => setSyncStatus("ok"))
          .catch(() => setSyncStatus("error"));
      });
    });
    AsyncStorage.getItem(HABITS_KEY).then(d => {
      setHabits(d ? JSON.parse(d) : DEMO_HABITS);
      if (!d) AsyncStorage.setItem(HABITS_KEY, JSON.stringify(DEMO_HABITS));
    });
    AsyncStorage.getItem(CATS_KEY).then(d => {
      setCategories(d ? JSON.parse(d) : DEFAULT_CATEGORIES);
      if (!d) AsyncStorage.setItem(CATS_KEY, JSON.stringify(DEFAULT_CATEGORIES));
    });
  }, []);

  const saveTasks = useCallback((u: Task[]) => {
    setTasks(u);
    AsyncStorage.setItem(TASKS_KEY, JSON.stringify(u));
  }, []);

  const saveHabits = useCallback((u: Habit[]) => {
    setHabits(u);
    AsyncStorage.setItem(HABITS_KEY, JSON.stringify(u));
  }, []);

  const saveCats = useCallback((u: CategoryDef[]) => {
    setCategories(u);
    AsyncStorage.setItem(CATS_KEY, JSON.stringify(u));
  }, []);

  const getAllDescendantIds = useCallback((id: string, all: Task[]): string[] => {
    const ch = all.filter(t => t.parentId === id);
    return ch.reduce<string[]>((a, c) => [...a, c.id, ...getAllDescendantIds(c.id, all)], []);
  }, []);

  const addTask = useCallback((task: Omit<Task, "id" | "createdAt">) => {
    const newTask: Task = { ...task, id: genId(), createdAt: new Date().toISOString() };
    saveTasks([...tasks, newTask]);
    pushTask(newTask).catch(() => {});
  }, [tasks, saveTasks]);

  const updateTask = useCallback((id: string, patch: Partial<Omit<Task, "id" | "createdAt">>) => {
    const updated = tasks.map(t => t.id === id ? { ...t, ...patch } : t);
    saveTasks(updated);
    const changed = updated.find(t => t.id === id);
    if (changed) pushTask(changed).catch(() => {});
  }, [tasks, saveTasks]);

  const toggleTask = useCallback((id: string) => {
    const updated = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    saveTasks(updated);
    const changed = updated.find(t => t.id === id);
    if (changed) pushTask(changed).catch(() => {});
  }, [tasks, saveTasks]);

  // Soft delete — moves to archive
  const deleteTask = useCallback((id: string) => {
    const toArchive = new Set([id, ...getAllDescendantIds(id, tasks)]);
    const updated = tasks.map(t =>
      toArchive.has(t.id)
        ? { ...t, archived: true, archivedAt: new Date().toISOString() }
        : t,
    );
    saveTasks(updated);
    updated.filter(t => toArchive.has(t.id)).forEach(t => pushTask(t).catch(() => {}));
  }, [tasks, saveTasks, getAllDescendantIds]);

  // Restore from archive
  const restoreTask = useCallback((id: string) => {
    const updated = tasks.map(t => t.id === id ? { ...t, archived: false, archivedAt: undefined } : t);
    saveTasks(updated);
    const changed = updated.find(t => t.id === id);
    if (changed) pushTask(changed).catch(() => {});
  }, [tasks, saveTasks]);

  // Permanent delete
  const purgeTask = useCallback((id: string) => {
    const toPurge = new Set([id, ...getAllDescendantIds(id, tasks)]);
    saveTasks(tasks.filter(t => !toPurge.has(t.id)));
    toPurge.forEach(tid => deleteTaskRemote(tid).catch(() => {}));
  }, [tasks, saveTasks, getAllDescendantIds]);

  const purgeAll = useCallback(() => {
    const archived = tasks.filter(t => t.archived);
    saveTasks(tasks.filter(t => !t.archived));
    archived.forEach(t => deleteTaskRemote(t.id).catch(() => {}));
  }, [tasks, saveTasks]);

  const getChildren = useCallback((parentId: string | undefined) =>
    tasks.filter(t => t.parentId === parentId && !t.archived), [tasks]);

  const getRootTasks = useCallback(() =>
    tasks.filter(t => !t.parentId && !t.archived), [tasks]);

  const getArchivedTasks = useCallback(() =>
    tasks.filter(t => t.archived && !t.parentId), [tasks]);

  const addHabit = useCallback((habit: Omit<Habit, "id" | "completedDays">) => {
    saveHabits([...habits, { ...habit, id: genId(), completedDays: [] }]);
  }, [habits, saveHabits]);

  const toggleHabitDay = useCallback((habitId: string, day: string) => {
    saveHabits(habits.map(h => {
      if (h.id !== habitId) return h;
      const has = h.completedDays.includes(day);
      return { ...h, completedDays: has ? h.completedDays.filter(d => d !== day) : [...h.completedDays, day] };
    }));
  }, [habits, saveHabits]);

  const deleteHabit = useCallback((id: string) => {
    saveHabits(habits.filter(h => h.id !== id));
  }, [habits, saveHabits]);

  const addCategory = useCallback((name: string, emoji: string) => {
    saveCats([...categories, { id: genId(), name, emoji }]);
  }, [categories, saveCats]);

  const updateCategory = useCallback((id: string, name: string, emoji: string) => {
    saveCats(categories.map(c => c.id === id ? { ...c, name, emoji } : c));
  }, [categories, saveCats]);

  const deleteCategory = useCallback((id: string) => {
    saveCats(categories.filter(c => c.id !== id));
  }, [categories, saveCats]);

  const rootTasks = tasks.filter(t => !t.parentId && !t.archived);

  return (
    <TaskContext.Provider value={{
      tasks, habits, categories,
      addTask, updateTask, toggleTask, deleteTask, restoreTask, purgeTask, purgeAll,
      addHabit, toggleHabitDay, deleteHabit,
      getChildren, getRootTasks, getArchivedTasks,
      addCategory, updateCategory, deleteCategory,
      todayCompleted: rootTasks.filter(t => t.completed).length,
      todayTotal: rootTasks.length,
      syncStatus,
    }}>
      {children}
    </TaskContext.Provider>
  );
}

export function useTasks(): TaskContextValue {
  const ctx = useContext(TaskContext);
  if (!ctx) throw new Error("useTasks must be used inside TaskProvider");
  return ctx;
}
