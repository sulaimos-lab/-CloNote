import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

export type PayType = "hourly" | "fixed";
export type PaymentType = "advance" | "salary";

export interface ShiftTemplate {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  payType: PayType;
  rate: number;
  color: string;
}

export interface DaySchedule {
  date: string;
  templateId?: string;
  rateOverride?: number;
  colorOverride?: string;
  note?: string;
  noteColor?: string;
  isDayOff?: boolean;
  offColor?: string;
}

export interface WagePayment {
  id: string;
  date: string;
  type: PaymentType;
  amount: number;
  note?: string;
  color: string;
}

interface WorkScheduleData {
  templates: ShiftTemplate[];
  days: DaySchedule[];
  payments: WagePayment[];
}

interface WorkScheduleContextValue extends WorkScheduleData {
  isLoading: boolean;
  saveTemplate: (template: Omit<ShiftTemplate, "id">, id?: string) => string;
  deleteTemplate: (id: string) => boolean;
  saveDay: (day: DaySchedule) => void;
  deleteDay: (date: string) => void;
  savePayment: (payment: Omit<WagePayment, "id">, id?: string) => void;
  deletePayment: (id: string) => void;
}

const STORAGE_KEY = "clonote_work_schedule_v1";
const WorkScheduleContext = createContext<WorkScheduleContextValue | null>(null);

function createId() {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 9)}`;
}

export function WorkScheduleProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<WorkScheduleData>({ templates: [], days: [], payments: [] });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let active = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then(raw => {
        if (!active || !raw) return;
        const saved = JSON.parse(raw) as Partial<WorkScheduleData>;
        setData({
          templates: Array.isArray(saved.templates) ? saved.templates : [],
          days: Array.isArray(saved.days) ? saved.days : [],
          payments: Array.isArray(saved.payments) ? saved.payments : [],
        });
      })
      .catch(error => console.error("Unable to load work schedule:", error))
      .finally(() => {
        if (active) setIsLoading(false);
      });
    return () => { active = false; };
  }, []);

  const commit = useCallback((update: (current: WorkScheduleData) => WorkScheduleData) => {
    setData(current => {
      const next = update(current);
      void AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next))
        .catch(error => console.error("Unable to save work schedule:", error));
      return next;
    });
  }, []);

  const saveTemplate = useCallback((template: Omit<ShiftTemplate, "id">, id?: string) => {
    const templateId = id ?? createId();
    commit(current => ({
      ...current,
      templates: id
        ? current.templates.map(item => item.id === id ? { ...template, id } : item)
        : [...current.templates, { ...template, id: templateId }],
    }));
    return templateId;
  }, [commit]);

  const deleteTemplate = useCallback((id: string) => {
    if (data.days.some(day => day.templateId === id)) return false;
    commit(current => ({ ...current, templates: current.templates.filter(item => item.id !== id) }));
    return true;
  }, [commit, data.days]);

  const saveDay = useCallback((day: DaySchedule) => {
    commit(current => ({
      ...current,
      days: current.days.some(item => item.date === day.date)
        ? current.days.map(item => item.date === day.date ? day : item)
        : [...current.days, day],
    }));
  }, [commit]);

  const deleteDay = useCallback((date: string) => {
    commit(current => ({ ...current, days: current.days.filter(item => item.date !== date) }));
  }, [commit]);

  const savePayment = useCallback((payment: Omit<WagePayment, "id">, id?: string) => {
    const paymentId = id ?? createId();
    commit(current => ({
      ...current,
      payments: id
        ? current.payments.map(item => item.id === id ? { ...payment, id } : item)
        : [...current.payments, { ...payment, id: paymentId }],
    }));
  }, [commit]);

  const deletePayment = useCallback((id: string) => {
    commit(current => ({ ...current, payments: current.payments.filter(item => item.id !== id) }));
  }, [commit]);

  const value = useMemo(() => ({
    ...data, isLoading, saveTemplate, deleteTemplate, saveDay, deleteDay, savePayment, deletePayment,
  }), [data, isLoading, saveTemplate, deleteTemplate, saveDay, deleteDay, savePayment, deletePayment]);

  return <WorkScheduleContext.Provider value={value}>{children}</WorkScheduleContext.Provider>;
}

export function useWorkSchedule() {
  const context = useContext(WorkScheduleContext);
  if (!context) throw new Error("useWorkSchedule must be used inside WorkScheduleProvider");
  return context;
}
