import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

export type Provider = "google" | "yandex" | "vk" | "mailru" | "guest";

export interface AuthUser {
  id: string;
  name: string;
  email?: string;
  avatar?: string;
  provider: Provider;
}

interface AuthContextValue {
  user: AuthUser | null;
  isLoading: boolean;
  setUser: (user: AuthUser | null) => void;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  isLoading: true,
  setUser: () => {},
  logout: async () => {},
});

const STORAGE_KEY = "clonote_auth_user_v1";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, _setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(raw => {
      if (raw) {
        try { _setUser(JSON.parse(raw)); } catch {}
      }
      setIsLoading(false);
    });
  }, []);

  const setUser = (u: AuthUser | null) => {
    _setUser(u);
    if (u) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(u));
    else AsyncStorage.removeItem(STORAGE_KEY);
  };

  const logout = async () => {
    await AsyncStorage.removeItem(STORAGE_KEY);
    _setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, setUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

/* ─── Provider meta ─────────────────────────────────────── */
export const PROVIDER_META: Record<Provider, { label: string; color: string; bg: string; emoji: string }> = {
  google:  { label: "Google",       color: "#fff",    bg: "#4285F4", emoji: "🔵" },
  yandex:  { label: "Яндекс ID",    color: "#fff",    bg: "#FC3F1D", emoji: "🔴" },
  vk:      { label: "ВКонтакте",    color: "#fff",    bg: "#0077FF", emoji: "💙" },
  mailru:  { label: "Mail.ru",      color: "#fff",    bg: "#005FF9", emoji: "📧" },
  guest:   { label: "Гость",        color: "#000",    bg: "#F0F0F0", emoji: "👤" },
};

/* ─── OAuth endpoints ────────────────────────────────────── */
export const OAUTH_CONFIG = {
  google: {
    authorizationEndpoint: "https://accounts.google.com/o/oauth2/v2/auth",
    userinfoEndpoint: "https://www.googleapis.com/oauth2/v2/userinfo",
    scopes: "openid email profile",
    clientIdEnv: "EXPO_PUBLIC_GOOGLE_CLIENT_ID",
  },
  yandex: {
    authorizationEndpoint: "https://oauth.yandex.ru/authorize",
    userinfoEndpoint: "https://login.yandex.ru/info?format=json",
    scopes: "login:email login:info login:avatar",
    clientIdEnv: "EXPO_PUBLIC_YANDEX_CLIENT_ID",
  },
  vk: {
    authorizationEndpoint: "https://oauth.vk.com/authorize",
    userinfoEndpoint: "https://api.vk.com/method/users.get?fields=photo_200,screen_name&v=5.131",
    scopes: "email",
    clientIdEnv: "EXPO_PUBLIC_VK_CLIENT_ID",
  },
  mailru: {
    authorizationEndpoint: "https://oauth.mail.ru/login",
    userinfoEndpoint: "https://oauth.mail.ru/userinfo",
    scopes: "userinfo",
    clientIdEnv: "EXPO_PUBLIC_MAILRU_CLIENT_ID",
  },
};

/* ─── Fetch user info from provider ────────────────────── */
export async function fetchProviderUser(provider: Provider, accessToken: string): Promise<AuthUser> {
  const id = Math.random().toString(36).slice(2);

  if (provider === "google") {
    const r = await fetch(OAUTH_CONFIG.google.userinfoEndpoint, {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    const d = await r.json();
    return { id: d.id ?? id, name: d.name ?? "Google User", email: d.email, avatar: d.picture, provider };
  }
  if (provider === "yandex") {
    const r = await fetch(OAUTH_CONFIG.yandex.userinfoEndpoint, {
      headers: { Authorization: `OAuth ${accessToken}` },
    });
    const d = await r.json();
    return { id: d.id ?? id, name: d.real_name ?? d.login ?? "Yandex User", email: d.default_email, avatar: d.default_avatar_id ? `https://avatars.yandex.net/get-yapic/${d.default_avatar_id}/islands-200` : undefined, provider };
  }
  if (provider === "vk") {
    const r = await fetch(`${OAUTH_CONFIG.vk.userinfoEndpoint}&access_token=${accessToken}`);
    const d = await r.json();
    const u = d.response?.[0];
    return { id: String(u?.id ?? id), name: `${u?.first_name ?? ""} ${u?.last_name ?? ""}`.trim() || "VK User", avatar: u?.photo_200, provider };
  }
  if (provider === "mailru") {
    const r = await fetch(`${OAUTH_CONFIG.mailru.userinfoEndpoint}?access_token=${accessToken}`);
    const d = await r.json();
    return { id: d.id ?? id, name: d.name ?? "Mail User", email: d.email, avatar: d.image, provider };
  }
  return { id, name: "Пользователь", provider };
}
