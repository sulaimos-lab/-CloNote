const colors = {
  light: {
    text: "#37352F",
    tint: "#2383E2",

    background: "#FFFFFF",
    foreground: "#37352F",

    card: "#FFFFFF",
    cardForeground: "#37352F",

    surface: "#F7F7F5",
    surfaceForeground: "#37352F",

    primary: "#2383E2",
    primaryForeground: "#FFFFFF",

    secondary: "#F1F1EF",
    secondaryForeground: "#37352F",

    muted: "#F1F1EF",
    mutedForeground: "#787774",

    accent: "#F1F1EF",
    accentForeground: "#37352F",

    destructive: "#EB5757",
    destructiveForeground: "#FFFFFF",

    border: "#E9E9E7",
    input: "#E9E9E7",

    success: "#0F7B6C",
    successLight: "#DBEDDB",

    categoryWork: "#37352F",
    categoryWorkLight: "#F1F1EF",
    categoryHome: "#37352F",
    categoryHomeLight: "#F1F1EF",
    categoryHabits: "#37352F",
    categoryHabitsLight: "#F1F1EF",
    categoryPersonal: "#37352F",
    categoryPersonalLight: "#F1F1EF",
    categoryShopping: "#37352F",
    categoryShoppingLight: "#F1F1EF",

    tabBar: "#FFFFFF",
    tabBarBorder: "#E9E9E7",
  },

  dark: {
    text: "#FFFFFF",
    tint: "#529CCA",

    background: "#191919",
    foreground: "#FFFFFF",

    card: "#191919",
    cardForeground: "#FFFFFF",

    surface: "#2F2F2F",
    surfaceForeground: "#FFFFFF",

    primary: "#529CCA",
    primaryForeground: "#FFFFFF",

    secondary: "#2F2F2F",
    secondaryForeground: "#FFFFFF",

    muted: "#2F2F2F",
    mutedForeground: "#9B9A97",

    accent: "#2F2F2F",
    accentForeground: "#FFFFFF",

    destructive: "#EB5757",
    destructiveForeground: "#FFFFFF",

    border: "#373737",
    input: "#373737",

    success: "#4DAB9A",
    successLight: "#1B3D36",

    categoryWork: "#FFFFFF",
    categoryWorkLight: "#2F2F2F",
    categoryHome: "#FFFFFF",
    categoryHomeLight: "#2F2F2F",
    categoryHabits: "#FFFFFF",
    categoryHabitsLight: "#2F2F2F",
    categoryPersonal: "#FFFFFF",
    categoryPersonalLight: "#2F2F2F",
    categoryShopping: "#FFFFFF",
    categoryShoppingLight: "#2F2F2F",

    tabBar: "#191919",
    tabBarBorder: "#373737",
  },

  radius: 8,
};

export default colors;
