import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

const NOTIF_ENABLED_KEY = "clonote_notif_enabled_v1";

/* ─── Configure how notifications look when app is open ── */
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldShowBanner: true,
    shouldShowList: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

/* ─── Permission request ─────────────────────────────── */
export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS === "web") return false;
  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === "granted") return true;
  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

/* ─── Check current permission ───────────────────────── */
export async function getNotificationPermission(): Promise<string> {
  if (Platform.OS === "web") return "unavailable";
  const { status } = await Notifications.getPermissionsAsync();
  return status;
}

/* ─── User preference (enabled / disabled in settings) ── */
export async function getNotifEnabled(): Promise<boolean> {
  const v = await AsyncStorage.getItem(NOTIF_ENABLED_KEY);
  return v !== "false"; // default: enabled
}

export async function setNotifEnabled(val: boolean): Promise<void> {
  await AsyncStorage.setItem(NOTIF_ENABLED_KEY, val ? "true" : "false");
}

/* ─── Schedule reminder for a task ──────────────────── */
export async function scheduleTaskReminder(opts: {
  taskId: string;
  title: string;
  dueDate: string;        // ISO
}): Promise<void> {
  if (Platform.OS === "web") return;

  const enabled = await getNotifEnabled();
  if (!enabled) return;

  const granted = await requestNotificationPermission();
  if (!granted) return;

  // Cancel any existing reminder for this task
  await cancelTaskReminder(opts.taskId);

  const due = new Date(opts.dueDate);
  const now = new Date();

  // Schedule: 1 day before (if >1 day away) AND 1 hour before (if >1 hour away)
  const oneDayBefore  = new Date(due.getTime() - 24 * 60 * 60 * 1000);
  const oneHourBefore = new Date(due.getTime() - 60 * 60 * 1000);

  const formatTime = (d: Date) =>
    d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  const formatDate = (d: Date) =>
    d.toLocaleDateString("ru-RU", { day: "numeric", month: "long" });

  if (oneDayBefore > now) {
    await Notifications.scheduleNotificationAsync({
      identifier: `task_day_${opts.taskId}`,
      content: {
        title: "⏰ Задача завтра",
        body: `«${opts.title}» — срок ${formatDate(due)}`,
        data: { taskId: opts.taskId },
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: oneDayBefore },
    });
  }

  if (oneHourBefore > now) {
    await Notifications.scheduleNotificationAsync({
      identifier: `task_hour_${opts.taskId}`,
      content: {
        title: "🔔 Срок через час!",
        body: `«${opts.title}» — в ${formatTime(due)}`,
        data: { taskId: opts.taskId },
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: oneHourBefore },
    });
  }

  // Also notify exactly at deadline if in the future
  if (due > now) {
    await Notifications.scheduleNotificationAsync({
      identifier: `task_due_${opts.taskId}`,
      content: {
        title: "🚨 Срок наступил!",
        body: `«${opts.title}» — время вышло`,
        data: { taskId: opts.taskId },
      },
      trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: due },
    });
  }
}

/* ─── Cancel reminders for a task ───────────────────── */
export async function cancelTaskReminder(taskId: string): Promise<void> {
  if (Platform.OS === "web") return;
  await Promise.all([
    Notifications.cancelScheduledNotificationAsync(`task_day_${taskId}`),
    Notifications.cancelScheduledNotificationAsync(`task_hour_${taskId}`),
    Notifications.cancelScheduledNotificationAsync(`task_due_${taskId}`),
  ]);
}

/* ─── Cancel all reminders ───────────────────────────── */
export async function cancelAllReminders(): Promise<void> {
  if (Platform.OS === "web") return;
  await Notifications.cancelAllScheduledNotificationsAsync();
}

/* ─── List scheduled count ───────────────────────────── */
export async function getScheduledCount(): Promise<number> {
  if (Platform.OS === "web") return 0;
  const all = await Notifications.getAllScheduledNotificationsAsync();
  return all.length;
}
