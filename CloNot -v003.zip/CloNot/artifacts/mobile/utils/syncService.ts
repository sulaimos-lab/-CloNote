/**
 * CloNote Sync Service
 * Syncs local AsyncStorage tasks with the API server.
 * Mobile is the source of truth; API acts as a shared backend.
 */

import type { Task } from "../context/TaskContext";

const API_BASE = (() => {
  if (typeof __DEV__ !== "undefined" && __DEV__) {
    return "http://localhost:8080/api";
  }
  return "/api";
})();

const SYNC_KEY = "clonote_last_sync_v1";

export type SyncStatus = "idle" | "syncing" | "error" | "ok";

async function post(path: string, body: unknown): Promise<unknown> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`POST ${path} → ${res.status}`);
  return res.json();
}

async function patch(path: string, body: unknown): Promise<unknown> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`PATCH ${path} → ${res.status}`);
  return res.json();
}

async function del(path: string): Promise<void> {
  const res = await fetch(`${API_BASE}${path}`, { method: "DELETE" });
  if (!res.ok && res.status !== 404) throw new Error(`DELETE ${path} → ${res.status}`);
}

function toApiTask(t: Task) {
  return {
    id: t.id,
    title: t.title,
    category: t.category,
    priority: t.priority,
    completed: t.completed,
    archived: t.archived ?? false,
    createdAt: t.createdAt,
    updatedAt: new Date().toISOString(),
    dueDate: t.dueDate ?? null,
    parentId: t.parentId ?? null,
    imageUri: t.imageUri ?? null,
    notes: "",
  };
}

/** Bulk-push all local tasks to the server (upsert). */
export async function pushAllTasks(tasks: Task[]): Promise<void> {
  if (tasks.length === 0) return;
  await post("/tasks/sync", { tasks: tasks.map(toApiTask) });
}

/** Push a single task change (create or update) to the server. */
export async function pushTask(task: Task): Promise<void> {
  await post("/tasks/sync", { tasks: [toApiTask(task)] });
}

/** Delete a task on the server. */
export async function deleteTaskRemote(taskId: string): Promise<void> {
  await del(`/tasks/${taskId}`);
}

/** Check if the API server is reachable. */
export async function isApiReachable(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/healthz`, { signal: AbortSignal.timeout(3000) });
    return res.ok;
  } catch {
    return false;
  }
}
