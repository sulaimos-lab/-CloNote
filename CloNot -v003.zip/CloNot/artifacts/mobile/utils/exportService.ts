/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * exportService.ts
 * Утилиты для экспорта задач в форматы Markdown и HTML.
 *   • exportMarkdown — для Obsidian, Notion, Claude, ChatGPT
 *   • exportHTML     — красивый отчёт для браузера
 * Поддерживает вложенные подзадачи, категории и приоритеты.
 */
import type { Task } from "@/context/TaskContext";
import type { CategoryDef } from "@/context/TaskContext";

function pad(n: number) { return String(n).padStart(2, "0"); }
function fmtDate(iso: string) {
  const d = new Date(iso);
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}

function priorityLabel(p: string) {
  if (p === "high")   return "🔴 Срочно";
  if (p === "normal") return "🟡 Важно";
  return "⚪ Обычно";
}

function renderTasksMd(tasks: Task[], allTasks: Task[], depth = 0): string {
  const indent = "  ".repeat(depth);
  return tasks.map(t => {
    const check  = t.completed ? "[x]" : "[ ]";
    const due    = t.dueDate ? ` 📅 ${fmtDate(t.dueDate)}` : "";
    const pri    = priorityLabel(t.priority);
    const line   = `${indent}- ${check} **${t.title}** ${pri}${due}`;
    const kids   = allTasks.filter(c => c.parentId === t.id);
    return kids.length ? `${line}\n${renderTasksMd(kids, allTasks, depth + 1)}` : line;
  }).join("\n");
}

export function exportMarkdown(tasks: Task[], categories: CategoryDef[]): string {
  const now    = new Date();
  const today  = fmtDate(now.toISOString());
  const active = tasks.filter(t => !t.archived);
  const roots  = active.filter(t => !t.parentId);
  const done   = active.filter(t => t.completed).length;
  const pct    = active.length ? Math.round((done / active.length) * 100) : 0;

  const lines: string[] = [
    `# CloNote — Экспорт задач`,
    ``,
    `> Дата: ${today} | Выполнено: ${done}/${active.length} (${pct}%)`,
    ``,
  ];

  for (const cat of categories) {
    const catTasks = roots.filter(t => t.category === cat.id);
    if (!catTasks.length) continue;
    lines.push(`## ${cat.emoji} ${cat.name}`);
    lines.push(``);
    lines.push(renderTasksMd(catTasks, active));
    lines.push(``);
  }

  const archived = tasks.filter(t => t.archived);
  if (archived.length) {
    lines.push(`## 🗄️ Архив`);
    lines.push(``);
    lines.push(renderTasksMd(archived, tasks));
    lines.push(``);
  }

  lines.push(`---`);
  lines.push(`*Экспорт из CloNote*`);
  return lines.join("\n");
}

export function exportHTML(tasks: Task[], categories: CategoryDef[]): string {
  const now   = new Date();
  const today = fmtDate(now.toISOString());
  const active = tasks.filter(t => !t.archived);
  const done   = active.filter(t => t.completed).length;
  const pct    = active.length ? Math.round((done / active.length) * 100) : 0;

  function taskHtml(t: Task, all: Task[], depth: number): string {
    const check = t.completed
      ? `<span style="color:#10B981">✓</span>`
      : `<span style="color:#ccc">○</span>`;
    const pri = t.priority === "high" ? "#E03E3E" : t.priority === "normal" ? "#D9730D" : "#9B9A97";
    const due = t.dueDate ? ` <small style="color:#9B9A97">📅 ${fmtDate(t.dueDate)}</small>` : "";
    const ml = depth * 20;
    const kids = all.filter(c => c.parentId === t.id);
    return `
      <div style="margin-left:${ml}px;padding:4px 0;border-bottom:1px solid #f0f0f0">
        ${check}
        <span style="color:${pri};font-size:11px;margin:0 6px">●</span>
        <span style="${t.completed ? "text-decoration:line-through;color:#aaa" : ""}">${t.title}</span>
        ${due}
      </div>
      ${kids.map(k => taskHtml(k, all, depth + 1)).join("")}
    `;
  }

  const catSections = categories.map(cat => {
    const roots = active.filter(t => t.category === cat.id && !t.parentId);
    if (!roots.length) return "";
    return `
      <section style="margin-bottom:28px">
        <h2 style="font-size:16px;color:#333;border-bottom:2px solid #eee;padding-bottom:6px">
          ${cat.emoji} ${cat.name}
        </h2>
        ${roots.map(t => taskHtml(t, active, 0)).join("")}
      </section>
    `;
  }).join("");

  return `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>CloNote — Задачи ${today}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
           max-width: 720px; margin: 40px auto; padding: 0 20px; color: #333; }
    h1   { font-size: 24px; font-weight: 700; }
    .meta { color: #888; font-size: 13px; margin-bottom: 32px; }
    .bar  { height: 6px; background: #eee; border-radius: 3px; margin: 8px 0 24px; }
    .fill { height: 6px; background: #10B981; border-radius: 3px; width: ${pct}%; }
    footer { margin-top: 40px; color: #ccc; font-size: 12px; }
  </style>
</head>
<body>
  <h1>📋 CloNote — Задачи</h1>
  <div class="meta">Дата: ${today} · Выполнено: ${done}/${active.length} (${pct}%)</div>
  <div class="bar"><div class="fill"></div></div>
  ${catSections}
  <footer>Экспорт из CloNote · ${today}</footer>
</body>
</html>`;
}
