import { DaySchedule, ShiftTemplate } from "@/context/WorkScheduleContext";

export const SHIFT_COLORS = ["#2383E2", "#0F7B6C", "#9065B0", "#D44C47", "#E07B39", "#CB912F", "#4C6B5A", "#5B5BD6"];
export const WEEKDAYS_RU = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

const pad = (value: number) => String(value).padStart(2, "0");

export function dateKey(date: Date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function parseDateKey(key: string) {
  const [year, month, day] = key.split("-").map(Number);
  return new Date(year, month - 1, day);
}

export function monthTitle(date: Date) {
  const value = date.toLocaleDateString("ru-RU", { month: "long", year: "numeric" });
  return value.charAt(0).toLocaleUpperCase("ru-RU") + value.slice(1);
}

export function monthDays(date: Date) {
  const first = new Date(date.getFullYear(), date.getMonth(), 1);
  const mondayOffset = (first.getDay() + 6) % 7;
  const start = new Date(first);
  start.setDate(first.getDate() - mondayOffset);
  return Array.from({ length: 42 }, (_, index) => {
    const day = new Date(start);
    day.setDate(start.getDate() + index);
    return day;
  });
}

export function weekDays(date: Date) {
  const start = new Date(date);
  start.setDate(date.getDate() - ((date.getDay() + 6) % 7));
  return Array.from({ length: 7 }, (_, index) => {
    const day = new Date(start);
    day.setDate(start.getDate() + index);
    return day;
  });
}

export function shiftHours(template: ShiftTemplate) {
  const [startHour, startMinute] = template.startTime.split(":").map(Number);
  const [endHour, endMinute] = template.endTime.split(":").map(Number);
  let minutes = endHour * 60 + endMinute - (startHour * 60 + startMinute);
  if (minutes <= 0) minutes += 24 * 60;
  return minutes / 60;
}

export function earnedForDay(day: DaySchedule, template?: ShiftTemplate) {
  if (!template || day.isDayOff) return 0;
  const rate = day.rateOverride ?? template.rate;
  return template.payType === "hourly" ? rate * shiftHours(template) : rate;
}

export function hoursForDay(day: DaySchedule, template?: ShiftTemplate) {
  return template && !day.isDayOff ? shiftHours(template) : 0;
}

export function formatMoney(value: number) {
  return `${Math.round(value).toLocaleString("ru-RU")} ₽`;
}

export function blendWithWhite(hex: string, strength: number) {
  const normalized = hex.replace("#", "");
  if (normalized.length !== 6) return hex;
  const amount = Math.max(0.2, Math.min(1, strength));
  const channels = [0, 2, 4].map(index => {
    const base = parseInt(normalized.slice(index, index + 2), 16);
    return Math.round(255 - (255 - base) * amount).toString(16).padStart(2, "0");
  });
  return `#${channels.join("")}`;
}
