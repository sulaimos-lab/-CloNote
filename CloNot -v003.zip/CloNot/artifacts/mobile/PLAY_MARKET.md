# CloNote — Публикация в Google Play

**Автор:** Sulaimon Qurbonov  
**Package:** `com.sulaimon.clonote`  
**Версия:** 1.0.0 (versionCode: 1)

---

## Шаг 1 — Установить EAS CLI на своём компьютере

```bash
npm install -g eas-cli
eas login
```

Войди в аккаунт Expo (зарегистрируйся на expo.dev если нет).

---

## Шаг 2 — Привязать проект

В папке `artifacts/mobile`:

```bash
eas init
```

Скопируй полученный `projectId` и вставь в `app.json` → `extra.eas.projectId`.

---

## Шаг 3 — Собрать APK для теста (бесплатно)

```bash
cd artifacts/mobile
eas build --platform android --profile preview
```

Через ~10 минут получишь ссылку на скачивание `.apk` — установи на телефон и протестируй.

---

## Шаг 4 — Собрать AAB для Play Market

```bash
eas build --platform android --profile production
```

Получишь `.aab` файл — именно он загружается в Play Console.

---

## Шаг 5 — Загрузить в Google Play Console

1. Открой [play.google.com/console](https://play.google.com/console)
2. Создай приложение → **CloNote**
3. Заполни:
   - Описание (см. ниже)
   - Скриншоты (минимум 2 штуки, 16:9 или 9:16)
   - Иконка 512×512 px
   - Политика конфиденциальности (обязательно)
4. Загрузи `.aab` в **Внутреннее тестирование**
5. Отправь на проверку Google (2–7 дней)

---

## Описание для Play Market (готовое)

**Краткое (80 символов):**
```
CloNote — умный менеджер задач с поддержкой ИИ
```

**Полное:**
```
CloNote — минималистичный менеджер задач для людей, которые ценят порядок.

✅ Задачи с подзадачами, категориями и приоритетами
🌱 Трекер привычек со стриком
📊 Дашборд со статистикой и heatmap активности
🕸️ Граф связей задач
📤 Экспорт в Markdown и HTML (для Obsidian, ChatGPT)
🤖 Подключение ИИ-ассистентов (Claude, Cursor) через MCP

Бесплатно. Без рекламы. Без подписок.
```

---

## Команды для обновления версии

При каждом обновлении меняй в `app.json`:
- `version`: "1.0.1", "1.1.0" и т.д.
- `versionCode`: 2, 3, 4... (только вверх, никогда не уменьшать!)

```bash
eas build --platform android --profile production
```

---

## Структура файлов

```
artifacts/mobile/
├── app.json          ← конфиг приложения (package, version)
├── eas.json          ← конфиг сборки EAS
├── google-services.json  ← (нужен если добавишь Firebase — пока не нужен)
└── PLAY_MARKET.md    ← этот файл
```
