/**
 * Task store backed by the CloNote API Server.
 */

const API_BASE = process.env.API_BASE_URL || "http://localhost:8080/api";

const categories = [
  { id: "cat_work",     name: "Работа",   color: "#3B82F6", emoji: "💼" },
  { id: "cat_personal", name: "Личное",   color: "#10B981", emoji: "🏠" },
  { id: "cat_study",    name: "Учёба",    color: "#8B5CF6", emoji: "📚" },
  { id: "cat_health",   name: "Здоровье", color: "#EF4444", emoji: "❤️" },
];

async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`API GET ${path} → ${res.status}`);
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API POST ${path} → ${res.status}`);
  return res.status === 204 ? null : res.json();
}

async function apiPatch(path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`API PATCH ${path} → ${res.status}`);
  return res.json();
}

async function apiDelete(path) {
  const res = await fetch(`${API_BASE}${path}`, { method: "DELETE" });
  if (!res.ok) throw new Error(`API DELETE ${path} → ${res.status}`);
}

export async function listTasks({ includeCompleted = true, includeArchived = false, category = null } = {}) {
  const params = new URLSearchParams();
  params.set("includeCompleted", String(includeCompleted));
  params.set("includeArchived", String(includeArchived));
  if (category) params.set("category", category);
  return apiGet(`/tasks?${params}`);
}

export async function getTask(id) {
  try { return await apiGet(`/tasks/${id}`); } catch { return null; }
}

export async function createTask({ title, category = "cat_personal", priority = "normal", dueDate = null, parentId = null, notes = "" }) {
  return apiPost("/tasks", { title, category, priority, dueDate, parentId, notes });
}

export async function updateTask(id, patch) {
  try { return await apiPatch(`/tasks/${id}`, patch); } catch { return null; }
}

export async function completeTask(id) {
  try { return await apiPost(`/tasks/${id}/complete`, {}); } catch { return null; }
}

export async function reopenTask(id) {
  try { return await apiPost(`/tasks/${id}/reopen`, {}); } catch { return null; }
}

export async function archiveTask(id) {
  try { return await apiPost(`/tasks/${id}/archive`, {}); } catch { return null; }
}

export async function deleteTask(id) {
  try { await apiDelete(`/tasks/${id}`); return true; } catch { return false; }
}

export async function getStats() {
  return apiGet("/tasks/stats");
}

export function listCategories() {
  return categories;
}
