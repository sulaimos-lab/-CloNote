/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * mcp-server/index.js
 * MCP-сервер (Model Context Protocol) для интеграции с ИИ-ассистентами.
 * Транспорт: StreamableHTTP (порт 8000) + Stdio.
 * Инструменты: list_tasks, create_task, complete_task, update_task,
 *              delete_task, reopen_task, archive_task, get_task,
 *              list_categories, get_stats (всего 10 инструментов).
 * Данные хранятся в PostgreSQL через API-сервер (localhost:8080/api).
 */
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import http from "http";
import {
  listTasks, getTask, createTask, updateTask,
  completeTask, reopenTask, archiveTask, deleteTask,
  getStats, listCategories,
} from "./store.js";

/* ─── MCP Server ──────────────────────────────────────── */
const server = new McpServer({
  name:    "CloNote",
  version: "1.0.0",
});

/* ──────────────────────────────────────────────────────
   RESOURCES — readable context blocks
   ────────────────────────────────────────────────────── */

server.resource("tasks://all", "clonote://tasks/all", { mimeType: "application/json" }, async () => {
  const tasks = listTasks({ includeCompleted: true, includeArchived: false });
  return { contents: [{ uri: "clonote://tasks/all", mimeType: "application/json", text: JSON.stringify(tasks, null, 2) }] };
});

server.resource("tasks://pending", "clonote://tasks/pending", { mimeType: "application/json" }, async () => {
  const tasks = listTasks({ includeCompleted: false, includeArchived: false });
  return { contents: [{ uri: "clonote://tasks/pending", mimeType: "application/json", text: JSON.stringify(tasks, null, 2) }] };
});

server.resource("tasks://stats", "clonote://tasks/stats", { mimeType: "application/json" }, async () => {
  const stats = getStats();
  return { contents: [{ uri: "clonote://tasks/stats", mimeType: "application/json", text: JSON.stringify(stats, null, 2) }] };
});

server.resource("tasks://categories", "clonote://tasks/categories", { mimeType: "application/json" }, async () => {
  const cats = listCategories();
  return { contents: [{ uri: "clonote://tasks/categories", mimeType: "application/json", text: JSON.stringify(cats, null, 2) }] };
});

/* ──────────────────────────────────────────────────────
   TOOLS — actions the AI can call
   ────────────────────────────────────────────────────── */

server.tool(
  "list_tasks",
  "Получить список задач CloNote. Можно фильтровать по статусу и категории.",
  {
    include_completed: z.boolean().optional().default(true).describe("Включить выполненные задачи"),
    include_archived:  z.boolean().optional().default(false).describe("Включить архивированные"),
    category:          z.string().optional().describe("ID категории для фильтрации (cat_work, cat_personal, cat_study, cat_health)"),
  },
  async ({ include_completed, include_archived, category }) => {
    const tasks = listTasks({ includeCompleted: include_completed, includeArchived: include_archived, category });
    const summary = tasks.map(t =>
      `[${t.completed ? "✓" : " "}] ${t.id} — ${t.title} (${t.priority}${t.dueDate ? ", срок: " + new Date(t.dueDate).toLocaleDateString("ru-RU") : ""})`
    ).join("\n");
    return {
      content: [{
        type: "text",
        text: tasks.length === 0
          ? "Задач не найдено."
          : `Найдено задач: ${tasks.length}\n\n${summary}\n\n${JSON.stringify(tasks, null, 2)}`,
      }],
    };
  }
);

server.tool(
  "get_task",
  "Получить полную информацию об одной задаче по её ID.",
  { task_id: z.string().describe("ID задачи, например task_1") },
  async ({ task_id }) => {
    const task = getTask(task_id);
    if (!task) return { content: [{ type: "text", text: `Задача с ID "${task_id}" не найдена.` }], isError: true };
    return { content: [{ type: "text", text: JSON.stringify(task, null, 2) }] };
  }
);

server.tool(
  "create_task",
  "Создать новую задачу в CloNote.",
  {
    title:     z.string().min(1).describe("Название задачи"),
    category:  z.enum(["cat_work", "cat_personal", "cat_study", "cat_health"]).optional().default("cat_personal").describe("Категория"),
    priority:  z.enum(["urgent", "high", "normal"]).optional().default("normal").describe("Приоритет: urgent (срочно), high (важно), normal (обычно)"),
    due_date:  z.string().optional().describe("Срок в формате ISO 8601, например 2025-06-25T18:00:00.000Z"),
    parent_id: z.string().optional().describe("ID родительской задачи для создания подзадачи"),
    notes:     z.string().optional().default("").describe("Дополнительные заметки"),
  },
  async ({ title, category, priority, due_date, parent_id, notes }) => {
    const task = createTask({ title, category, priority, dueDate: due_date ?? null, parentId: parent_id ?? null, notes });
    return {
      content: [{
        type: "text",
        text: `✅ Задача создана!\nID: ${task.id}\nНазвание: ${task.title}\nКатегория: ${task.category}\nПриоритет: ${task.priority}\n\n${JSON.stringify(task, null, 2)}`,
      }],
    };
  }
);

server.tool(
  "complete_task",
  "Отметить задачу как выполненную.",
  { task_id: z.string().describe("ID задачи") },
  async ({ task_id }) => {
    const task = completeTask(task_id);
    if (!task) return { content: [{ type: "text", text: `Задача "${task_id}" не найдена.` }], isError: true };
    return { content: [{ type: "text", text: `✓ Задача «${task.title}» отмечена выполненной.` }] };
  }
);

server.tool(
  "reopen_task",
  "Снять отметку выполнения с задачи (вернуть в незавершённые).",
  { task_id: z.string().describe("ID задачи") },
  async ({ task_id }) => {
    const task = reopenTask(task_id);
    if (!task) return { content: [{ type: "text", text: `Задача "${task_id}" не найдена.` }], isError: true };
    return { content: [{ type: "text", text: `↩ Задача «${task.title}» снова открыта.` }] };
  }
);

server.tool(
  "update_task",
  "Изменить параметры существующей задачи.",
  {
    task_id:   z.string().describe("ID задачи"),
    title:     z.string().optional().describe("Новое название"),
    priority:  z.enum(["urgent", "high", "normal"]).optional().describe("Новый приоритет"),
    category:  z.enum(["cat_work", "cat_personal", "cat_study", "cat_health"]).optional().describe("Новая категория"),
    due_date:  z.string().nullable().optional().describe("Новый срок (ISO) или null для удаления"),
    notes:     z.string().optional().describe("Новые заметки"),
  },
  async ({ task_id, title, priority, category, due_date, notes }) => {
    const patch = {};
    if (title    !== undefined) patch.title    = title;
    if (priority !== undefined) patch.priority = priority;
    if (category !== undefined) patch.category = category;
    if (due_date !== undefined) patch.dueDate  = due_date;
    if (notes    !== undefined) patch.notes    = notes;
    const task = updateTask(task_id, patch);
    if (!task) return { content: [{ type: "text", text: `Задача "${task_id}" не найдена.` }], isError: true };
    return { content: [{ type: "text", text: `✏️ Задача «${task.title}» обновлена.\n\n${JSON.stringify(task, null, 2)}` }] };
  }
);

server.tool(
  "archive_task",
  "Архивировать задачу (скрыть без удаления).",
  { task_id: z.string().describe("ID задачи") },
  async ({ task_id }) => {
    const task = archiveTask(task_id);
    if (!task) return { content: [{ type: "text", text: `Задача "${task_id}" не найдена.` }], isError: true };
    return { content: [{ type: "text", text: `🗄 Задача «${task.title}» архивирована.` }] };
  }
);

server.tool(
  "delete_task",
  "Удалить задачу и все её подзадачи. Необратимо.",
  { task_id: z.string().describe("ID задачи") },
  async ({ task_id }) => {
    const task = getTask(task_id);
    if (!task) return { content: [{ type: "text", text: `Задача "${task_id}" не найдена.` }], isError: true };
    deleteTask(task_id);
    return { content: [{ type: "text", text: `🗑 Задача «${task.title}» удалена.` }] };
  }
);

server.tool(
  "get_stats",
  "Получить сводную статистику по всем задачам CloNote.",
  {},
  async () => {
    const s = getStats();
    return {
      content: [{
        type: "text",
        text: [
          `📊 Статистика CloNote`,
          `──────────────────`,
          `Всего задач:       ${s.total}`,
          `Выполнено:         ${s.completed} (${s.completionRate}%)`,
          `В процессе:        ${s.pending}`,
          `Просроченные:      ${s.overdue}`,
          `Срочные (urgent):  ${s.urgent}`,
        ].join("\n"),
      }],
    };
  }
);

server.tool(
  "list_categories",
  "Получить список доступных категорий задач CloNote.",
  {},
  async () => {
    const cats = listCategories();
    const text = cats.map(c => `${c.emoji} ${c.name} (id: ${c.id})`).join("\n");
    return { content: [{ type: "text", text: `Категории CloNote:\n\n${text}` }] };
  }
);

/* ──────────────────────────────────────────────────────
   PROMPTS — ready-made prompts for common tasks
   ────────────────────────────────────────────────────── */

server.prompt(
  "daily_review",
  "Ежедневный обзор задач CloNote",
  {},
  async () => {
    const pending  = listTasks({ includeCompleted: false });
    const stats    = getStats();
    const overdue  = pending.filter(t => t.dueDate && new Date(t.dueDate) < new Date());
    const today    = pending.filter(t => {
      if (!t.dueDate) return false;
      const d = new Date(t.dueDate);
      const now = new Date();
      return d.toDateString() === now.toDateString();
    });

    return {
      messages: [{
        role: "user",
        content: {
          type: "text",
          text: [
            `Сделай ежедневный обзор моих задач в CloNote.`,
            ``,
            `Статистика: ${stats.pending} незавершённых задач, ${stats.overdue} просроченных, ${stats.completed} выполнено.`,
            ``,
            overdue.length > 0
              ? `Просроченные (${overdue.length}):\n${overdue.map(t => `- ${t.title}`).join("\n")}`
              : "Просроченных задач нет! 🎉",
            ``,
            today.length > 0
              ? `На сегодня (${today.length}):\n${today.map(t => `- ${t.title}`).join("\n")}`
              : "Задач на сегодня не запланировано.",
            ``,
            `Помоги мне приоритизировать задачи на день и предложи с чего начать.`,
          ].join("\n"),
        },
      }],
    };
  }
);

server.prompt(
  "task_breakdown",
  "Разбить большую задачу на подзадачи",
  { task_id: z.string().describe("ID задачи для декомпозиции") },
  async ({ task_id }) => {
    const task = getTask(task_id);
    if (!task) throw new Error(`Задача ${task_id} не найдена`);
    return {
      messages: [{
        role: "user",
        content: {
          type: "text",
          text: [
            `Разбей эту задачу на конкретные подзадачи и создай их через инструмент create_task с parent_id="${task.id}":`,
            ``,
            `Задача: ${task.title}`,
            `Приоритет: ${task.priority}`,
            task.notes ? `Заметки: ${task.notes}` : "",
            task.dueDate ? `Срок: ${new Date(task.dueDate).toLocaleDateString("ru-RU")}` : "",
            ``,
            `Создай 3-7 конкретных подзадач которые вместе составляют выполнение этой задачи.`,
          ].filter(Boolean).join("\n"),
        },
      }],
    };
  }
);

/* ──────────────────────────────────────────────────────
   TRANSPORT — HTTP (Streamable) for Claude Desktop / web clients
             + STDIO for CLI-based clients
   ────────────────────────────────────────────────────── */

const PORT = process.env.PORT || 8000;

const httpServer = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({
      name: "CloNote MCP Server",
      version: "1.0.0",
      description: "MCP-сервер для управления задачами CloNote",
      tools: [
        "list_tasks", "get_task", "create_task", "complete_task",
        "reopen_task", "update_task", "archive_task", "delete_task",
        "get_stats", "list_categories",
      ],
      resources: [
        "clonote://tasks/all",
        "clonote://tasks/pending",
        "clonote://tasks/stats",
        "clonote://tasks/categories",
      ],
      prompts: ["daily_review", "task_breakdown"],
      mcp_endpoint: "/mcp",
      connect: {
        type: "streamable-http",
        url: `${process.env.EXPO_PUBLIC_DOMAIN || "http://localhost"}:${PORT}/mcp`,
      },
    }));
    return;
  }

  if (req.url === "/mcp") {
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
    res.on("close", () => transport.close());
    await server.connect(transport);
    await transport.handleRequest(req, res, await readBody(req));
    return;
  }

  res.writeHead(404);
  res.end("Not found");
});

function readBody(req) {
  return new Promise((resolve) => {
    const chunks = [];
    req.on("data", c => chunks.push(c));
    req.on("end", () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
  });
}

httpServer.listen(PORT, () => {
  console.error(`[CloNote MCP] HTTP сервер запущен на порту ${PORT}`);
  console.error(`[CloNote MCP] Endpoint: http://localhost:${PORT}/mcp`);
  console.error(`[CloNote MCP] Info:     http://localhost:${PORT}/`);
});

// Also support stdio mode: node src/index.js --stdio
if (process.argv.includes("--stdio")) {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}
