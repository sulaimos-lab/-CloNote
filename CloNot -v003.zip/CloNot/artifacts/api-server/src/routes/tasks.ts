/**
 * CloNote — Менеджер задач
 * Copyright (c) 2025 Sulaimon Qurbonov. Все права защищены.
 * Лицензия: MIT
 *
 * routes/tasks.ts
 * REST API для управления задачами в PostgreSQL.
 * Эндпоинты: GET/POST/PUT/DELETE /api/tasks
 * Также: POST /api/tasks/sync — массовая синхронизация с мобильным приложением.
 * Используется MCP-сервером и мобильным клиентом.
 */
import { Router, type IRouter } from "express";
import { db, tasksTable } from "@workspace/db";
import { eq, and, or, isNull, gt, sql } from "drizzle-orm";

const router: IRouter = Router();

const generateId = () =>
  `task_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;

const now = () => new Date().toISOString();

/* ─── LIST ─────────────────────────────────────────────── */
router.get("/tasks", async (req, res) => {
  const includeArchived = req.query["includeArchived"] !== "false";
  const includeCompleted = req.query["includeCompleted"] !== "false";
  const category = req.query["category"] as string | undefined;
  const updatedAfter = req.query["updatedAfter"] as string | undefined;

  const conditions = [];
  if (!includeArchived) conditions.push(eq(tasksTable.archived, false));
  if (!includeCompleted) conditions.push(eq(tasksTable.completed, false));
  if (category) conditions.push(eq(tasksTable.category, category as any));
  if (updatedAfter) conditions.push(gt(tasksTable.updatedAt, updatedAfter));

  const tasks =
    conditions.length > 0
      ? await db.select().from(tasksTable).where(and(...conditions))
      : await db.select().from(tasksTable);

  res.json(tasks);
});

/* ─── STATS ─────────────────────────────────────────────── */
router.get("/tasks/stats", async (_req, res) => {
  const all = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.archived, false));

  const total = all.length;
  const completed = all.filter((t) => t.completed).length;
  const pending = total - completed;
  const overdue = all.filter(
    (t) => !t.completed && t.dueDate && new Date(t.dueDate) < new Date(),
  ).length;
  const urgent = all.filter(
    (t) => !t.completed && t.priority === "urgent",
  ).length;

  res.json({
    total,
    completed,
    pending,
    overdue,
    urgent,
    completionRate: total > 0 ? Math.round((completed / total) * 100) : 0,
  });
});

/* ─── BULK SYNC ─────────────────────────────────────────── */
router.post("/tasks/sync", async (req, res) => {
  const { tasks } = req.body as { tasks: any[] };
  if (!Array.isArray(tasks) || tasks.length === 0) {
    res.json([]);
    return;
  }

  const upserted = await db
    .insert(tasksTable)
    .values(
      tasks.map((t) => ({
        id: t.id ?? generateId(),
        title: t.title,
        category: t.category ?? "cat_personal",
        priority: t.priority ?? "normal",
        completed: t.completed ?? false,
        archived: t.archived ?? false,
        createdAt: t.createdAt ?? now(),
        updatedAt: t.updatedAt ?? now(),
        dueDate: t.dueDate ?? null,
        parentId: t.parentId ?? null,
        imageUri: t.imageUri ?? null,
        notes: t.notes ?? "",
      })),
    )
    .onConflictDoUpdate({
      target: tasksTable.id,
      set: {
        title: sql`excluded.title`,
        category: sql`excluded.category`,
        priority: sql`excluded.priority`,
        completed: sql`excluded.completed`,
        archived: sql`excluded.archived`,
        updatedAt: sql`excluded.updated_at`,
        dueDate: sql`excluded.due_date`,
        parentId: sql`excluded.parent_id`,
        imageUri: sql`excluded.image_uri`,
        notes: sql`excluded.notes`,
      },
    })
    .returning();

  res.json(upserted);
});

/* ─── GET ONE ─────────────────────────────────────────────── */
router.get("/tasks/:taskId", async (req, res) => {
  const [task] = await db
    .select()
    .from(tasksTable)
    .where(eq(tasksTable.id, req.params["taskId"]!));

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  res.json(task);
});

/* ─── CREATE ─────────────────────────────────────────────── */
router.post("/tasks", async (req, res) => {
  const body = req.body;
  const [task] = await db
    .insert(tasksTable)
    .values({
      id: body.id ?? generateId(),
      title: body.title,
      category: body.category ?? "cat_personal",
      priority: body.priority ?? "normal",
      completed: false,
      archived: false,
      createdAt: body.createdAt ?? now(),
      updatedAt: now(),
      dueDate: body.dueDate ?? null,
      parentId: body.parentId ?? null,
      imageUri: body.imageUri ?? null,
      notes: body.notes ?? "",
    })
    .returning();

  res.status(201).json(task);
});

/* ─── UPDATE ─────────────────────────────────────────────── */
router.patch("/tasks/:taskId", async (req, res) => {
  const body = req.body;
  const patch: Record<string, any> = { updatedAt: now() };
  if (body.title !== undefined) patch["title"] = body.title;
  if (body.category !== undefined) patch["category"] = body.category;
  if (body.priority !== undefined) patch["priority"] = body.priority;
  if (body.completed !== undefined) patch["completed"] = body.completed;
  if (body.archived !== undefined) patch["archived"] = body.archived;
  if (body.dueDate !== undefined) patch["dueDate"] = body.dueDate;
  if (body.parentId !== undefined) patch["parentId"] = body.parentId;
  if (body.imageUri !== undefined) patch["imageUri"] = body.imageUri;
  if (body.notes !== undefined) patch["notes"] = body.notes;

  const [task] = await db
    .update(tasksTable)
    .set(patch)
    .where(eq(tasksTable.id, req.params["taskId"]!))
    .returning();

  if (!task) {
    res.status(404).json({ error: "Task not found" });
    return;
  }
  res.json(task);
});

/* ─── COMPLETE / REOPEN / ARCHIVE ──────────────────────── */
router.post("/tasks/:taskId/complete", async (req, res) => {
  const [task] = await db
    .update(tasksTable)
    .set({ completed: true, updatedAt: now() })
    .where(eq(tasksTable.id, req.params["taskId"]!))
    .returning();
  if (!task) { res.status(404).json({ error: "Task not found" }); return; }
  res.json(task);
});

router.post("/tasks/:taskId/reopen", async (req, res) => {
  const [task] = await db
    .update(tasksTable)
    .set({ completed: false, updatedAt: now() })
    .where(eq(tasksTable.id, req.params["taskId"]!))
    .returning();
  if (!task) { res.status(404).json({ error: "Task not found" }); return; }
  res.json(task);
});

router.post("/tasks/:taskId/archive", async (req, res) => {
  const [task] = await db
    .update(tasksTable)
    .set({ archived: true, updatedAt: now() })
    .where(eq(tasksTable.id, req.params["taskId"]!))
    .returning();
  if (!task) { res.status(404).json({ error: "Task not found" }); return; }
  res.json(task);
});

/* ─── DELETE ─────────────────────────────────────────────── */
router.delete("/tasks/:taskId", async (req, res) => {
  const taskId = req.params["taskId"]!;

  const deleteChildren = async (parentId: string) => {
    const children = await db
      .select({ id: tasksTable.id })
      .from(tasksTable)
      .where(eq(tasksTable.parentId, parentId));
    for (const child of children) await deleteChildren(child.id);
    await db.delete(tasksTable).where(eq(tasksTable.parentId, parentId));
  };

  await deleteChildren(taskId);
  await db.delete(tasksTable).where(eq(tasksTable.id, taskId));
  res.status(204).end();
});

export default router;
