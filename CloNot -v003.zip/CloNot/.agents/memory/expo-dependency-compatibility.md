---
name: Expo dependency compatibility
description: Expo Go startup depends on keeping every Expo package on the same SDK major/minor line; security overrides must be verified against Metro.
---

Keep Expo SDK packages aligned with the app's declared Expo SDK before troubleshooting a blank or unopened mobile preview. Security fixes should prefer patched direct parents and narrowly scoped overrides, then be verified by restarting Metro and loading the preview.

**Why:** Mixed Expo 54/56/57 package versions caused compatibility warnings and can prevent Expo Go from opening; broad overrides can also break Metro's native toolchain.

**How to apply:** After dependency changes, run the mobile typecheck, restart the managed Expo workflow, capture the preview, and inspect `pnpm audit` leftovers for upstream-only advisories before forcing replacements. In particular, do not override Metro's `image-size` dependency blindly: newer releases can break Metro asset processing even when they appear safer to audit.