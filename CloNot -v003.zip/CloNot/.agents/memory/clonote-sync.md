---
name: CloNote sync architecture
description: How mobile, API server, MCP server, and DB are connected
---

Mobile app (Expo) → AsyncStorage (primary) + fire-and-forget push to API
API server (port 8080) → PostgreSQL via Drizzle
MCP server (port 8000) → calls API server at localhost:8080/api

Key endpoints:
- POST /api/tasks/sync — bulk upsert (mobile uses this on startup)
- POST /api/tasks — create single task
- PATCH /api/tasks/:id — update
- DELETE /api/tasks/:id — hard delete (cascades children)
- POST /api/tasks/:id/complete|reopen|archive

**Why:** MCP calls API (not DB directly) to avoid TypeScript build complexity in plain-JS MCP server.
**How to apply:** When adding new task fields, update DB schema, API routes, OpenAPI spec, run codegen, update syncService.toApiTask().
