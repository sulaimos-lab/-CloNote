---
name: DB schema — text not enum
description: Why tasks table uses text for category/priority instead of pgEnum
---

Mobile app has custom category IDs (work, home, habits, personal, shopping).
MCP server uses different category IDs (cat_work, cat_personal, cat_study, cat_health).
Using pgEnum would reject any value not in the enum list.

**Why:** Flexibility for user-defined categories; mobile can create categories with any string ID.
**How to apply:** Never add pgEnum constraints to category or priority columns in tasks table.
