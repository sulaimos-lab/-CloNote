import { pgTable, text, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const tasksTable = pgTable("tasks", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull().default("personal"),
  priority: text("priority").notNull().default("normal"),
  completed: boolean("completed").notNull().default(false),
  archived: boolean("archived").notNull().default(false),
  createdAt: timestamp("created_at", { mode: "string" }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { mode: "string" }).notNull().defaultNow(),
  dueDate: timestamp("due_date", { mode: "string" }),
  parentId: text("parent_id"),
  imageUri: text("image_uri"),
  notes: text("notes").notNull().default(""),
});

export const insertTaskSchema = createInsertSchema(tasksTable).omit({
  createdAt: true,
  updatedAt: true,
});

export const patchTaskSchema = insertTaskSchema.partial().required({ id: true });

export type Task = typeof tasksTable.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type PatchTask = z.infer<typeof patchTaskSchema>;
